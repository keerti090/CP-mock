import * as i0 from '@angular/core';
import { Injectable, Component, Input, EventEmitter, ElementRef, Output, ContentChild, ViewChild, HostListener } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i2$2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i1$1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i2$1 from '@angular/cdk/drag-drop';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import { FlatTreeControl } from '@angular/cdk/tree';
import * as i1$2 from '@angular/material/tree';
import { MatTreeFlattener, MatTreeFlatDataSource, MatTreeModule } from '@angular/material/tree';

class UilibService {
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UilibService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UilibService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UilibService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class UilibComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UilibComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: UilibComponent, isStandalone: true, selector: "lib-uilib", ngImport: i0, template: `
    <p>
      uilib works!
    </p>
  `, isInline: true, styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UilibComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-uilib', standalone: true, imports: [], template: `
    <p>
      uilib works!
    </p>
  ` }]
        }] });

class IconComponent {
    constructor() {
        /**
         * 'material' = Material Symbols Rounded (default); 'asset' = SVG from assets/icons/
         * When using iconSet="material", the host app must load the font, e.g. in index.html:
         * <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
         */
        this.iconSet = 'material';
        this.size = 'md';
        this.color = 'default';
        this.background = 'default';
    }
    /** Material Symbol name: strip "icon-" prefix so "icon-add" and "add" both work */
    get materialIconName() {
        return this.icon?.replace(/^icon-/, '') ?? '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.14", type: IconComponent, isStandalone: true, selector: "app-icon", inputs: { icon: "icon", src: "src", iconSet: "iconSet", size: "size", alt: "alt", color: "color", background: "background" }, ngImport: i0, template: `
    @if (src) {
      <img
        class="icon"
        [ngClass]="[size, color ?? 'default', background ?? 'default']"
        [src]="src"
        [alt]="alt || icon || 'icon'"
      />
    } @else if (iconSet === 'material') {
      <span
        class="material-symbols-rounded icon"
        [ngClass]="[size, color ?? 'default', background ?? 'default']"
        [attr.aria-label]="alt || materialIconName"
      >{{ materialIconName }}</span>
    } @else if (icon) {
      <img
        class="icon"
        [ngClass]="[size, color ?? 'default', background ?? 'default']"
        [src]="'assets/icons/' + icon + '.svg'"
        [alt]="alt || icon"
      />
    }
  `, isInline: true, styles: ["@charset \"UTF-8\";.icon{width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center}.icon.sm{width:.75rem;height:.75rem}.icon.md{width:1rem;height:1rem}.icon.lg{width:1.5rem;height:1.5rem}.icon.primary{color:#0c558c}.icon.neutral{color:#525252}.icon.default{color:#3d3d3d}.icon.material-symbols-rounded{font-family:Material Symbols Rounded,sans-serif!important;font-weight:400;font-style:normal;font-variation-settings:\"FILL\" 0,\"wght\" 400,\"GRAD\" 0,\"opsz\" 24;line-height:1;letter-spacing:normal;text-transform:none;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-smoothing:antialiased}.icon.material-symbols-rounded.sm{font-size:.75rem!important;width:.75rem;height:.75rem}.icon.material-symbols-rounded.md{font-size:1rem!important;width:1rem;height:1rem}.icon.material-symbols-rounded.lg{font-size:1.5rem!important;width:1.5rem;height:1.5rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-icon', standalone: true, imports: [CommonModule], template: `
    @if (src) {
      <img
        class="icon"
        [ngClass]="[size, color ?? 'default', background ?? 'default']"
        [src]="src"
        [alt]="alt || icon || 'icon'"
      />
    } @else if (iconSet === 'material') {
      <span
        class="material-symbols-rounded icon"
        [ngClass]="[size, color ?? 'default', background ?? 'default']"
        [attr.aria-label]="alt || materialIconName"
      >{{ materialIconName }}</span>
    } @else if (icon) {
      <img
        class="icon"
        [ngClass]="[size, color ?? 'default', background ?? 'default']"
        [src]="'assets/icons/' + icon + '.svg'"
        [alt]="alt || icon"
      />
    }
  `, styles: ["@charset \"UTF-8\";.icon{width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center}.icon.sm{width:.75rem;height:.75rem}.icon.md{width:1rem;height:1rem}.icon.lg{width:1.5rem;height:1.5rem}.icon.primary{color:#0c558c}.icon.neutral{color:#525252}.icon.default{color:#3d3d3d}.icon.material-symbols-rounded{font-family:Material Symbols Rounded,sans-serif!important;font-weight:400;font-style:normal;font-variation-settings:\"FILL\" 0,\"wght\" 400,\"GRAD\" 0,\"opsz\" 24;line-height:1;letter-spacing:normal;text-transform:none;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-smoothing:antialiased}.icon.material-symbols-rounded.sm{font-size:.75rem!important;width:.75rem;height:.75rem}.icon.material-symbols-rounded.md{font-size:1rem!important;width:1rem;height:1rem}.icon.material-symbols-rounded.lg{font-size:1.5rem!important;width:1.5rem;height:1.5rem}\n"] }]
        }], propDecorators: { icon: [{
                type: Input
            }], src: [{
                type: Input
            }], iconSet: [{
                type: Input
            }], size: [{
                type: Input
            }], alt: [{
                type: Input
            }], color: [{
                type: Input
            }], background: [{
                type: Input
            }] } });

class ButtonComponent {
    constructor() {
        this.buttonText = true;
        this.label = 'Button';
        this.size = 'large';
        this.state = 'default';
        this.type = 'primary';
        this.nativeType = 'button';
        this.buttonClick = new EventEmitter();
        this.showLeftIcon = false;
        this.showRightIcon = false;
        this.leftIconName = 'add';
        this.rightIconName = 'add';
        /** Icon set for left icon: 'material' (default) or 'asset' (assets/icons/<leftIconName>.svg). */
        this.leftIconSet = 'material';
        /** Icon set for right icon: 'material' (default) or 'asset'. */
        this.rightIconSet = 'material';
        this.hasLeftIcon = false;
        this.hasRightIcon = false;
    }
    ngAfterContentInit() {
        this.hasLeftIcon = !!this.leftIcon;
        this.hasRightIcon = !!this.rightIcon;
    }
    onHover() {
        if (this.state !== 'disabled')
            this.state = 'hover';
    }
    onLeave() {
        if (this.state !== 'disabled')
            this.state = 'default';
    }
    onPressed() {
        if (this.state !== 'disabled')
            this.state = 'pressed';
    }
    onReleased() {
        if (this.state !== 'disabled')
            this.state = 'default';
    }
    onClick() {
        if (this.state !== 'disabled')
            this.buttonClick.emit();
        ;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: ButtonComponent, isStandalone: true, selector: "appcore-button", inputs: { buttonText: "buttonText", label: "label", size: "size", state: "state", type: "type", nativeType: "nativeType", showLeftIcon: "showLeftIcon", showRightIcon: "showRightIcon", leftIconName: "leftIconName", rightIconName: "rightIconName", leftIconSet: "leftIconSet", rightIconSet: "rightIconSet", leftIconSrc: "leftIconSrc", rightIconSrc: "rightIconSrc" }, outputs: { buttonClick: "buttonClick" }, queries: [{ propertyName: "leftIcon", first: true, predicate: ["[leftIconSwap]"], descendants: true, read: ElementRef }, { propertyName: "rightIcon", first: true, predicate: ["[rightIconSwap]"], descendants: true, read: ElementRef }], ngImport: i0, template: `
    <button
      mat-button
      class="appcore-button"
      [ngClass]="[
  'appcore-button--' + type,
  'appcore-button--' + state,
  'appcore-button--' + size
]"
      [disabled]="state === 'disabled'"
      (mouseenter)="onHover()"
      (mouseleave)="onLeave()"
      (mousedown)="onPressed()"
      (mouseup)="onReleased()"
      (click)="onClick()"
    >
      <span class="appcore-button__inner">
        <!-- Left Icon -->
        <ng-container *ngIf="showLeftIcon">
          <ng-content select="[leftIconSwap]"></ng-content>
          <app-icon
            *ngIf="!hasLeftIcon"
            [icon]="leftIconName"
            [iconSet]="leftIconSet"
            [src]="leftIconSrc"
            size="sm"
          ></app-icon>
        </ng-container>

        <!-- Label -->
        <span *ngIf="buttonText" class="appcore-button__label">
          <ng-container [ngSwitch]="state">
            <span *ngSwitchCase="'loading'">⏳</span>
            <span *ngSwitchDefault>{{ label }}</span>
          </ng-container>
        </span>

        <!-- Right Icon -->
        <ng-container *ngIf="showRightIcon">
          <ng-content select="[rightIconSwap]"></ng-content>
          <app-icon
            *ngIf="!hasRightIcon"
            [icon]="rightIconName"
            [iconSet]="rightIconSet"
            [src]="rightIconSrc"
            size="sm"
          ></app-icon>
        </ng-container>
      </span>
    </button>
  `, isInline: true, styles: ["@charset \"UTF-8\";.appcore-button{display:inline-flex!important;align-items:center!important;justify-content:center!important;padding:.625rem .5rem!important;border-radius:.5rem!important;position:relative;cursor:pointer;border:none;transition:background-color .2s ease,color .2s ease,box-shadow .2s ease!important;min-width:auto!important;line-height:inherit!important;letter-spacing:inherit!important;text-transform:none!important}.appcore-button__inner{display:inline-flex!important;align-items:center!important;flex-direction:row!important;gap:.5rem!important}.appcore-button .mdc-button__label{display:inline-flex!important;align-items:center!important;gap:.5rem!important}.appcore-button__label{display:inline;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:inherit}.appcore-button__icon{height:1.25rem;width:1.25rem}.appcore-button ::ng-deep .icon,.appcore-button ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-button ::ng-deep .icon img{color:inherit!important}.appcore-button mat-icon.material-symbols-rounded{font-family:Material Symbols Rounded!important;font-weight:400;font-style:normal;font-size:1.25rem!important;line-height:1!important;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-smoothing:antialiased;height:1.25rem!important;width:1.25rem!important}.appcore-button--primary{background-color:#0c558c!important;color:#fff!important}.appcore-button--secondary{background-color:#fff!important;color:#0c558c!important;border:1px solid!important;border-color:#0c558c!important}.appcore-button--tertiary{background-color:transparent!important;color:#0c558c!important}.appcore-button--toned{background-color:#e7eef3!important;color:#0c558c!important}.appcore-button--link{background-color:transparent!important;color:#0c558c!important;border:none!important}.appcore-button--link .appcore-button__label,.appcore-button--link .mdc-button__label{text-decoration:underline!important}.appcore-button--hover:hover{background-color:#0c5082!important}.appcore-button--secondary.appcore-button--hover:hover{background-color:#fff!important;border-color:#0c558c!important;color:#0c558c!important}.appcore-button--tertiary.appcore-button--hover:hover,.appcore-button--tertiary.appcore-button--pressed{background-color:transparent!important}.appcore-button--toned.appcore-button--hover:hover{background-color:#e7eef3!important;color:#0c558c!important}.appcore-button--link.appcore-button--hover:hover{background-color:#fff!important;border-color:#0c558c!important;color:#0c558c!important}.appcore-button--pressed{background-color:#0e3f65!important}.appcore-button--disabled{background-color:#f5f5f5!important;color:#a3a3a3!important;cursor:not-allowed!important;pointer-events:none!important}.appcore-button--loading{background-color:#0c558c!important;color:#fff!important}.appcore-button--success{background-color:#238823!important;color:#fff!important}.appcore-button--error{background-color:#d2222d!important;color:#fff!important}.appcore-button--small{padding:.25rem!important;font-size:12px!important}.appcore-button--medium{padding:.5rem!important;font-size:16px!important}.appcore-button--large{padding:.75rem!important;font-size:16px!important}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: i1.NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: i1.NgSwitchDefault, selector: "[ngSwitchDefault]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-button', standalone: true, imports: [CommonModule, MatButtonModule, MatIconModule, IconComponent], template: `
    <button
      mat-button
      class="appcore-button"
      [ngClass]="[
  'appcore-button--' + type,
  'appcore-button--' + state,
  'appcore-button--' + size
]"
      [disabled]="state === 'disabled'"
      (mouseenter)="onHover()"
      (mouseleave)="onLeave()"
      (mousedown)="onPressed()"
      (mouseup)="onReleased()"
      (click)="onClick()"
    >
      <span class="appcore-button__inner">
        <!-- Left Icon -->
        <ng-container *ngIf="showLeftIcon">
          <ng-content select="[leftIconSwap]"></ng-content>
          <app-icon
            *ngIf="!hasLeftIcon"
            [icon]="leftIconName"
            [iconSet]="leftIconSet"
            [src]="leftIconSrc"
            size="sm"
          ></app-icon>
        </ng-container>

        <!-- Label -->
        <span *ngIf="buttonText" class="appcore-button__label">
          <ng-container [ngSwitch]="state">
            <span *ngSwitchCase="'loading'">⏳</span>
            <span *ngSwitchDefault>{{ label }}</span>
          </ng-container>
        </span>

        <!-- Right Icon -->
        <ng-container *ngIf="showRightIcon">
          <ng-content select="[rightIconSwap]"></ng-content>
          <app-icon
            *ngIf="!hasRightIcon"
            [icon]="rightIconName"
            [iconSet]="rightIconSet"
            [src]="rightIconSrc"
            size="sm"
          ></app-icon>
        </ng-container>
      </span>
    </button>
  `, styles: ["@charset \"UTF-8\";.appcore-button{display:inline-flex!important;align-items:center!important;justify-content:center!important;padding:.625rem .5rem!important;border-radius:.5rem!important;position:relative;cursor:pointer;border:none;transition:background-color .2s ease,color .2s ease,box-shadow .2s ease!important;min-width:auto!important;line-height:inherit!important;letter-spacing:inherit!important;text-transform:none!important}.appcore-button__inner{display:inline-flex!important;align-items:center!important;flex-direction:row!important;gap:.5rem!important}.appcore-button .mdc-button__label{display:inline-flex!important;align-items:center!important;gap:.5rem!important}.appcore-button__label{display:inline;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:inherit}.appcore-button__icon{height:1.25rem;width:1.25rem}.appcore-button ::ng-deep .icon,.appcore-button ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-button ::ng-deep .icon img{color:inherit!important}.appcore-button mat-icon.material-symbols-rounded{font-family:Material Symbols Rounded!important;font-weight:400;font-style:normal;font-size:1.25rem!important;line-height:1!important;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-smoothing:antialiased;height:1.25rem!important;width:1.25rem!important}.appcore-button--primary{background-color:#0c558c!important;color:#fff!important}.appcore-button--secondary{background-color:#fff!important;color:#0c558c!important;border:1px solid!important;border-color:#0c558c!important}.appcore-button--tertiary{background-color:transparent!important;color:#0c558c!important}.appcore-button--toned{background-color:#e7eef3!important;color:#0c558c!important}.appcore-button--link{background-color:transparent!important;color:#0c558c!important;border:none!important}.appcore-button--link .appcore-button__label,.appcore-button--link .mdc-button__label{text-decoration:underline!important}.appcore-button--hover:hover{background-color:#0c5082!important}.appcore-button--secondary.appcore-button--hover:hover{background-color:#fff!important;border-color:#0c558c!important;color:#0c558c!important}.appcore-button--tertiary.appcore-button--hover:hover,.appcore-button--tertiary.appcore-button--pressed{background-color:transparent!important}.appcore-button--toned.appcore-button--hover:hover{background-color:#e7eef3!important;color:#0c558c!important}.appcore-button--link.appcore-button--hover:hover{background-color:#fff!important;border-color:#0c558c!important;color:#0c558c!important}.appcore-button--pressed{background-color:#0e3f65!important}.appcore-button--disabled{background-color:#f5f5f5!important;color:#a3a3a3!important;cursor:not-allowed!important;pointer-events:none!important}.appcore-button--loading{background-color:#0c558c!important;color:#fff!important}.appcore-button--success{background-color:#238823!important;color:#fff!important}.appcore-button--error{background-color:#d2222d!important;color:#fff!important}.appcore-button--small{padding:.25rem!important;font-size:12px!important}.appcore-button--medium{padding:.5rem!important;font-size:16px!important}.appcore-button--large{padding:.75rem!important;font-size:16px!important}\n"] }]
        }], propDecorators: { buttonText: [{
                type: Input
            }], label: [{
                type: Input
            }], size: [{
                type: Input
            }], state: [{
                type: Input
            }], type: [{
                type: Input
            }], nativeType: [{
                type: Input
            }], buttonClick: [{
                type: Output
            }], showLeftIcon: [{
                type: Input
            }], showRightIcon: [{
                type: Input
            }], leftIconName: [{
                type: Input
            }], rightIconName: [{
                type: Input
            }], leftIconSet: [{
                type: Input
            }], rightIconSet: [{
                type: Input
            }], leftIconSrc: [{
                type: Input
            }], rightIconSrc: [{
                type: Input
            }], leftIcon: [{
                type: ContentChild,
                args: ['[leftIconSwap]', { read: ElementRef }]
            }], rightIcon: [{
                type: ContentChild,
                args: ['[rightIconSwap]', { read: ElementRef }]
            }] } });

const DEFAULT_NAV_ITEMS = [
    'Dashboard', 'Marketplace', 'Subscription', 'Orders', 'Quotes',
    'Support', 'Billing', 'Reports', 'Customers', 'Partners', 'Products'
];
class NavBarComponent {
    constructor() {
        this.platform = 'CCP';
        this.navItems = [...DEFAULT_NAV_ITEMS];
        this.activeItem = 'Dashboard';
        this.cartCount = 0;
        this.userName = 'SMP RESELLER';
        this.marketplaceName = 'Marketplace';
        this.loggedInUser = 'John Doe';
        this.navItemClick = new EventEmitter();
    }
    onNavItemClick(item) {
        this.activeItem = item;
        this.navItemClick.emit(item);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: NavBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: NavBarComponent, isStandalone: true, selector: "app-nav-bar", inputs: { platform: "platform", navItems: "navItems", activeItem: "activeItem", cartCount: "cartCount", userName: "userName", marketplaceName: "marketplaceName", loggedInUser: "loggedInUser" }, outputs: { navItemClick: "navItemClick" }, ngImport: i0, template: `
    <!-- ===== CCP PLATFORM ===== -->
    <nav *ngIf="platform === 'CCP'" class="nav-bar nav-bar--ccp">
      <div class="nav-bar__top nav-bar__top--blue">
        <div class="nav-bar__logo nav-bar__logo--white">
          <span class="nav-bar__logo-wordmark">StreamOne Ion</span>
        </div>
        <div class="nav-bar__actions">
          <div class="nav-bar__search nav-bar__search--filled">
            <span class="material-symbols-rounded nav-bar__search-icon">search</span>
            <span class="nav-bar__search-label">Global Search</span>
          </div>
          <button class="nav-bar__icon-btn" aria-label="Notifications">
            <span class="material-symbols-rounded">notifications</span>
          </button>
          <button class="nav-bar__icon-btn" aria-label="Apps">
            <span class="material-symbols-rounded">apps</span>
          </button>
          <button class="nav-bar__icon-btn nav-bar__flag-btn" aria-label="Region">
            <span class="nav-bar__flag-emoji">🇺🇸</span>
          </button>
          <button class="nav-bar__icon-btn" aria-label="Menu">
            <span class="material-symbols-rounded">menu</span>
          </button>
        </div>
      </div>
      <div class="nav-bar__bottom nav-bar__bottom--white">
        <ng-container *ngFor="let item of navItems">
          <button
            class="nav-bar__nav-item"
            [class.nav-bar__nav-item--active]="item === activeItem"
            (click)="onNavItemClick(item)"
          >{{ item }}</button>
        </ng-container>
      </div>
    </nav>

    <!-- ===== WLMP PLATFORM ===== -->
    <nav *ngIf="platform === 'WLMP'" class="nav-bar nav-bar--wlmp">
      <div class="nav-bar__top nav-bar__top--white">
        <div class="nav-bar__left">
          <div class="nav-bar__logo nav-bar__logo--color">
            <span class="nav-bar__logo-wordmark nav-bar__logo-wordmark--color">StreamOne Ion</span>
          </div>
          <div class="nav-bar__divider"></div>
          <span class="nav-bar__mp-name">{{ marketplaceName }}</span>
        </div>
        <div class="nav-bar__actions nav-bar__actions--wide">
          <div class="nav-bar__search nav-bar__search--outlined">
            <span class="material-symbols-rounded nav-bar__search-icon nav-bar__search-icon--dark">search</span>
            <span class="nav-bar__search-label nav-bar__search-label--dark">Global Search</span>
          </div>
          <button class="nav-bar__icon-btn nav-bar__icon-btn--dark" aria-label="Notifications">
            <span class="material-symbols-rounded">notifications</span>
          </button>
          <button class="nav-bar__dropdown-btn" aria-label="User menu">
            <span class="nav-bar__dropdown-label">{{ userName }}</span>
            <span class="material-symbols-rounded nav-bar__chevron">expand_more</span>
          </button>
          <div class="nav-bar__country">
            <span class="nav-bar__flag-emoji">🇺🇸</span>
            <button class="nav-bar__dropdown-btn nav-bar__dropdown-btn--compact">
              <span class="nav-bar__dropdown-label">EN</span>
              <span class="material-symbols-rounded nav-bar__chevron">expand_more</span>
            </button>
          </div>
        </div>
      </div>
      <div class="nav-bar__bottom nav-bar__bottom--dark">
        <div class="nav-bar__bottom-left">
          <ng-container *ngFor="let item of navItems">
            <button
              class="nav-bar__nav-item nav-bar__nav-item--light"
              [class.nav-bar__nav-item--active-light]="item === activeItem"
              (click)="onNavItemClick(item)"
            >{{ item }}</button>
          </ng-container>
        </div>
        <button class="nav-bar__cart-btn">
          <span class="material-symbols-rounded nav-bar__cart-icon">shopping_cart</span>
          <span class="nav-bar__cart-label">View Cart ({{ cartCount }})</span>
          <span class="material-symbols-rounded nav-bar__chevron">expand_more</span>
        </button>
      </div>
    </nav>

    <!-- ===== CBOT PLATFORM ===== -->
    <nav *ngIf="platform === 'CBOT'" class="nav-bar nav-bar--cbot">
      <div class="nav-bar__top nav-bar__top--blue nav-bar__top--compact">
        <div class="nav-bar__cbot-logo">
          <span class="material-symbols-rounded nav-bar__cbot-icon">smart_toy</span>
          <span class="nav-bar__cbot-wordmark">CBOT</span>
        </div>
        <div class="nav-bar__user">
          <span class="material-symbols-rounded nav-bar__user-icon">account_circle</span>
          <span class="nav-bar__user-name">{{ loggedInUser }}</span>
        </div>
      </div>
    </nav>
  `, isInline: true, styles: [".nav-bar{font-family:Inter,sans-serif;width:100%;box-shadow:0 8px 24px 2px #00000014}.nav-bar__top{display:flex;flex-direction:row;justify-content:space-between;align-items:center;gap:90px;padding:16px 24px;width:100%;box-sizing:border-box}.nav-bar__top--blue{background-color:#0c558c;color:#fff}.nav-bar__top--white{background-color:#fff;color:#3d3d3d}.nav-bar__top--compact{padding:4px 24px;gap:90px}.nav-bar__logo{display:flex;align-items:center;flex-shrink:0}.nav-bar__logo-wordmark{font-family:Inter,sans-serif;font-weight:700;font-size:18px;letter-spacing:-.5px;white-space:nowrap}.nav-bar__logo-wordmark--color{background:linear-gradient(135deg,#0c558c,#3674b2);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}.nav-bar__left{display:flex;align-items:center;gap:10px;flex-shrink:0}.nav-bar__divider{width:1px;height:32px;background-color:#7a7a7a;flex-shrink:0}.nav-bar__mp-name{font-family:Roboto,Inter,sans-serif;font-weight:400;font-size:18px;color:#111;white-space:nowrap}.nav-bar__actions{display:flex;flex-direction:row;align-items:center;gap:16px}.nav-bar__actions--wide{gap:24px}.nav-bar__search{display:flex;flex-direction:row;align-items:center;gap:4px;padding:4px 8px;width:400px;height:32px;border-radius:4px;box-sizing:border-box;cursor:pointer}.nav-bar__search--filled{background-color:#e7eef3}.nav-bar__search--outlined{background-color:#fff;border:1px solid #7A7A7A}.nav-bar__search-icon{font-size:16px;color:#a3a3a3;flex-shrink:0}.nav-bar__search-icon--dark{color:#3d3d3d}.nav-bar__search-label{font-size:14px;font-weight:400;color:#a3a3a3;flex:1}.nav-bar__search-label--dark{color:#3d3d3d}.nav-bar__icon-btn{display:flex;align-items:center;justify-content:center;width:24px;height:24px;background:none;border:none;cursor:pointer;color:#fff;padding:0}.nav-bar__icon-btn--dark{color:#3d3d3d}.nav-bar__icon-btn .material-symbols-rounded{font-size:24px}.nav-bar__flag-btn{width:24px;height:24px}.nav-bar__flag-emoji{font-size:18px;line-height:1}.nav-bar__dropdown-btn{display:flex;flex-direction:row;align-items:center;gap:8px;background:none;border:none;cursor:pointer;padding:0}.nav-bar__dropdown-btn--compact{gap:4px}.nav-bar__dropdown-label{font-family:Inter,sans-serif;font-size:14px;font-weight:400;color:#3d3d3d;white-space:nowrap}.nav-bar__chevron{font-size:18px;color:#3d3d3d}.nav-bar__country{display:flex;flex-direction:row;align-items:center;gap:15px}.nav-bar__bottom{display:flex;flex-direction:row;align-items:center;padding:15px 24px;box-sizing:border-box;width:100%}.nav-bar__bottom--white{background-color:#fff;gap:64px}.nav-bar__bottom--dark{background-color:#252525;justify-content:space-between}.nav-bar__bottom-left{display:flex;flex-direction:row;align-items:center;gap:64px}.nav-bar__nav-item{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.286em;white-space:nowrap;background:none;border:none;cursor:pointer;padding:0 0 2px;color:#3d3d3d;border-bottom:2px solid transparent;transition:color .15s,border-color .15s}.nav-bar__nav-item:hover{color:#0c558c;border-bottom-color:#0c558c}.nav-bar__nav-item--active{color:#0c558c;font-weight:600;border-bottom-color:#0c558c}.nav-bar__nav-item--light{color:#fff}.nav-bar__nav-item--light:hover{color:#fffc;border-bottom-color:#fffc}.nav-bar__nav-item--active-light{color:#fff;font-weight:600;border-bottom-color:#fff}.nav-bar__cart-btn{display:flex;flex-direction:row;align-items:center;justify-content:center;gap:8px;padding:10px 12px 10px 16px;background-color:#0c558c;color:#fff;border:none;border-radius:4px;cursor:pointer;white-space:nowrap;font-family:Inter,sans-serif;flex-shrink:0}.nav-bar__cart-btn:hover{background-color:#093e66}.nav-bar__cart-icon{font-size:20px}.nav-bar__cart-label{font-size:14px;font-weight:400;line-height:1.286em}.nav-bar__cbot-logo{display:flex;align-items:center;gap:8px}.nav-bar__cbot-icon{font-size:28px;color:#fff}.nav-bar__cbot-wordmark{font-family:Inter,sans-serif;font-size:20px;font-weight:700;color:#fff;letter-spacing:2px}.nav-bar__user{display:flex;flex-direction:row;align-items:center;gap:4px}.nav-bar__user-icon{font-size:24px;color:#fff}.nav-bar__user-name{font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:#fff;line-height:1.286em}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatIconModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: NavBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-nav-bar', standalone: true, imports: [CommonModule, MatIconModule], template: `
    <!-- ===== CCP PLATFORM ===== -->
    <nav *ngIf="platform === 'CCP'" class="nav-bar nav-bar--ccp">
      <div class="nav-bar__top nav-bar__top--blue">
        <div class="nav-bar__logo nav-bar__logo--white">
          <span class="nav-bar__logo-wordmark">StreamOne Ion</span>
        </div>
        <div class="nav-bar__actions">
          <div class="nav-bar__search nav-bar__search--filled">
            <span class="material-symbols-rounded nav-bar__search-icon">search</span>
            <span class="nav-bar__search-label">Global Search</span>
          </div>
          <button class="nav-bar__icon-btn" aria-label="Notifications">
            <span class="material-symbols-rounded">notifications</span>
          </button>
          <button class="nav-bar__icon-btn" aria-label="Apps">
            <span class="material-symbols-rounded">apps</span>
          </button>
          <button class="nav-bar__icon-btn nav-bar__flag-btn" aria-label="Region">
            <span class="nav-bar__flag-emoji">🇺🇸</span>
          </button>
          <button class="nav-bar__icon-btn" aria-label="Menu">
            <span class="material-symbols-rounded">menu</span>
          </button>
        </div>
      </div>
      <div class="nav-bar__bottom nav-bar__bottom--white">
        <ng-container *ngFor="let item of navItems">
          <button
            class="nav-bar__nav-item"
            [class.nav-bar__nav-item--active]="item === activeItem"
            (click)="onNavItemClick(item)"
          >{{ item }}</button>
        </ng-container>
      </div>
    </nav>

    <!-- ===== WLMP PLATFORM ===== -->
    <nav *ngIf="platform === 'WLMP'" class="nav-bar nav-bar--wlmp">
      <div class="nav-bar__top nav-bar__top--white">
        <div class="nav-bar__left">
          <div class="nav-bar__logo nav-bar__logo--color">
            <span class="nav-bar__logo-wordmark nav-bar__logo-wordmark--color">StreamOne Ion</span>
          </div>
          <div class="nav-bar__divider"></div>
          <span class="nav-bar__mp-name">{{ marketplaceName }}</span>
        </div>
        <div class="nav-bar__actions nav-bar__actions--wide">
          <div class="nav-bar__search nav-bar__search--outlined">
            <span class="material-symbols-rounded nav-bar__search-icon nav-bar__search-icon--dark">search</span>
            <span class="nav-bar__search-label nav-bar__search-label--dark">Global Search</span>
          </div>
          <button class="nav-bar__icon-btn nav-bar__icon-btn--dark" aria-label="Notifications">
            <span class="material-symbols-rounded">notifications</span>
          </button>
          <button class="nav-bar__dropdown-btn" aria-label="User menu">
            <span class="nav-bar__dropdown-label">{{ userName }}</span>
            <span class="material-symbols-rounded nav-bar__chevron">expand_more</span>
          </button>
          <div class="nav-bar__country">
            <span class="nav-bar__flag-emoji">🇺🇸</span>
            <button class="nav-bar__dropdown-btn nav-bar__dropdown-btn--compact">
              <span class="nav-bar__dropdown-label">EN</span>
              <span class="material-symbols-rounded nav-bar__chevron">expand_more</span>
            </button>
          </div>
        </div>
      </div>
      <div class="nav-bar__bottom nav-bar__bottom--dark">
        <div class="nav-bar__bottom-left">
          <ng-container *ngFor="let item of navItems">
            <button
              class="nav-bar__nav-item nav-bar__nav-item--light"
              [class.nav-bar__nav-item--active-light]="item === activeItem"
              (click)="onNavItemClick(item)"
            >{{ item }}</button>
          </ng-container>
        </div>
        <button class="nav-bar__cart-btn">
          <span class="material-symbols-rounded nav-bar__cart-icon">shopping_cart</span>
          <span class="nav-bar__cart-label">View Cart ({{ cartCount }})</span>
          <span class="material-symbols-rounded nav-bar__chevron">expand_more</span>
        </button>
      </div>
    </nav>

    <!-- ===== CBOT PLATFORM ===== -->
    <nav *ngIf="platform === 'CBOT'" class="nav-bar nav-bar--cbot">
      <div class="nav-bar__top nav-bar__top--blue nav-bar__top--compact">
        <div class="nav-bar__cbot-logo">
          <span class="material-symbols-rounded nav-bar__cbot-icon">smart_toy</span>
          <span class="nav-bar__cbot-wordmark">CBOT</span>
        </div>
        <div class="nav-bar__user">
          <span class="material-symbols-rounded nav-bar__user-icon">account_circle</span>
          <span class="nav-bar__user-name">{{ loggedInUser }}</span>
        </div>
      </div>
    </nav>
  `, styles: [".nav-bar{font-family:Inter,sans-serif;width:100%;box-shadow:0 8px 24px 2px #00000014}.nav-bar__top{display:flex;flex-direction:row;justify-content:space-between;align-items:center;gap:90px;padding:16px 24px;width:100%;box-sizing:border-box}.nav-bar__top--blue{background-color:#0c558c;color:#fff}.nav-bar__top--white{background-color:#fff;color:#3d3d3d}.nav-bar__top--compact{padding:4px 24px;gap:90px}.nav-bar__logo{display:flex;align-items:center;flex-shrink:0}.nav-bar__logo-wordmark{font-family:Inter,sans-serif;font-weight:700;font-size:18px;letter-spacing:-.5px;white-space:nowrap}.nav-bar__logo-wordmark--color{background:linear-gradient(135deg,#0c558c,#3674b2);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}.nav-bar__left{display:flex;align-items:center;gap:10px;flex-shrink:0}.nav-bar__divider{width:1px;height:32px;background-color:#7a7a7a;flex-shrink:0}.nav-bar__mp-name{font-family:Roboto,Inter,sans-serif;font-weight:400;font-size:18px;color:#111;white-space:nowrap}.nav-bar__actions{display:flex;flex-direction:row;align-items:center;gap:16px}.nav-bar__actions--wide{gap:24px}.nav-bar__search{display:flex;flex-direction:row;align-items:center;gap:4px;padding:4px 8px;width:400px;height:32px;border-radius:4px;box-sizing:border-box;cursor:pointer}.nav-bar__search--filled{background-color:#e7eef3}.nav-bar__search--outlined{background-color:#fff;border:1px solid #7A7A7A}.nav-bar__search-icon{font-size:16px;color:#a3a3a3;flex-shrink:0}.nav-bar__search-icon--dark{color:#3d3d3d}.nav-bar__search-label{font-size:14px;font-weight:400;color:#a3a3a3;flex:1}.nav-bar__search-label--dark{color:#3d3d3d}.nav-bar__icon-btn{display:flex;align-items:center;justify-content:center;width:24px;height:24px;background:none;border:none;cursor:pointer;color:#fff;padding:0}.nav-bar__icon-btn--dark{color:#3d3d3d}.nav-bar__icon-btn .material-symbols-rounded{font-size:24px}.nav-bar__flag-btn{width:24px;height:24px}.nav-bar__flag-emoji{font-size:18px;line-height:1}.nav-bar__dropdown-btn{display:flex;flex-direction:row;align-items:center;gap:8px;background:none;border:none;cursor:pointer;padding:0}.nav-bar__dropdown-btn--compact{gap:4px}.nav-bar__dropdown-label{font-family:Inter,sans-serif;font-size:14px;font-weight:400;color:#3d3d3d;white-space:nowrap}.nav-bar__chevron{font-size:18px;color:#3d3d3d}.nav-bar__country{display:flex;flex-direction:row;align-items:center;gap:15px}.nav-bar__bottom{display:flex;flex-direction:row;align-items:center;padding:15px 24px;box-sizing:border-box;width:100%}.nav-bar__bottom--white{background-color:#fff;gap:64px}.nav-bar__bottom--dark{background-color:#252525;justify-content:space-between}.nav-bar__bottom-left{display:flex;flex-direction:row;align-items:center;gap:64px}.nav-bar__nav-item{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.286em;white-space:nowrap;background:none;border:none;cursor:pointer;padding:0 0 2px;color:#3d3d3d;border-bottom:2px solid transparent;transition:color .15s,border-color .15s}.nav-bar__nav-item:hover{color:#0c558c;border-bottom-color:#0c558c}.nav-bar__nav-item--active{color:#0c558c;font-weight:600;border-bottom-color:#0c558c}.nav-bar__nav-item--light{color:#fff}.nav-bar__nav-item--light:hover{color:#fffc;border-bottom-color:#fffc}.nav-bar__nav-item--active-light{color:#fff;font-weight:600;border-bottom-color:#fff}.nav-bar__cart-btn{display:flex;flex-direction:row;align-items:center;justify-content:center;gap:8px;padding:10px 12px 10px 16px;background-color:#0c558c;color:#fff;border:none;border-radius:4px;cursor:pointer;white-space:nowrap;font-family:Inter,sans-serif;flex-shrink:0}.nav-bar__cart-btn:hover{background-color:#093e66}.nav-bar__cart-icon{font-size:20px}.nav-bar__cart-label{font-size:14px;font-weight:400;line-height:1.286em}.nav-bar__cbot-logo{display:flex;align-items:center;gap:8px}.nav-bar__cbot-icon{font-size:28px;color:#fff}.nav-bar__cbot-wordmark{font-family:Inter,sans-serif;font-size:20px;font-weight:700;color:#fff;letter-spacing:2px}.nav-bar__user{display:flex;flex-direction:row;align-items:center;gap:4px}.nav-bar__user-icon{font-size:24px;color:#fff}.nav-bar__user-name{font-family:Inter,sans-serif;font-size:14px;font-weight:500;color:#fff;line-height:1.286em}\n"] }]
        }], propDecorators: { platform: [{
                type: Input
            }], navItems: [{
                type: Input
            }], activeItem: [{
                type: Input
            }], cartCount: [{
                type: Input
            }], userName: [{
                type: Input
            }], marketplaceName: [{
                type: Input
            }], loggedInUser: [{
                type: Input
            }], navItemClick: [{
                type: Output
            }] } });

const DEFAULT_ICON_SET1 = [
    { icon: 'add' },
    { icon: 'filter_list' },
    { icon: 'attach_file' },
    { icon: 'delete' },
    { icon: 'upload' },
];
const DEFAULT_ICON_SET2 = [
    { icon: 'add' },
    { icon: 'filter_list' },
    { icon: 'attach_file' },
    { icon: 'delete' },
    { icon: 'upload' },
];
const DEFAULT_ICON_SET3 = [
    { icon: 'add' },
    { icon: 'filter_list' },
    { icon: 'attach_file' },
    { icon: 'delete' },
    { icon: 'upload' },
];
const DEFAULT_TEXT_SET1 = [
    { label: 'Button', leftIconName: 'add' },
    { label: 'Button', leftIconName: 'add' },
    { label: 'Button', leftIconName: 'add' },
    { label: 'Button', leftIconName: 'add' },
];
const DEFAULT_TEXT_SET2 = [
    { label: 'Button', leftIconName: 'add' },
    { label: 'Button', leftIconName: 'add' },
    { label: 'Button', leftIconName: 'add' },
];
const DEFAULT_TEXT_SET3 = [
    { label: 'Button', leftIconName: 'add' },
    { label: 'Button', leftIconName: 'add' },
    { label: 'Button', leftIconName: 'add' },
];
class ActionbarComponent {
    constructor() {
        /** Visual style for the bar – "icon" or "text". */
        this.type = 'icon';
        /** Size preset that controls spacing; mirrors the design spec (XS by default). */
        this.size = 'xs';
        /** Whether to show the middle set. */
        this.showSet2 = true;
        /** Whether to show the right-hand set. */
        this.showSet3 = true;
        /** Whether to show the trailing kebab menu. */
        this.showKebabMenu = true;
        /** Icon buttons for the first group (icon mode). */
        this.set1 = DEFAULT_ICON_SET1;
        /** Icon buttons for the second group (icon mode). */
        this.set2 = DEFAULT_ICON_SET2;
        /** Icon buttons for the third group (icon mode). */
        this.set3 = DEFAULT_ICON_SET3;
        /** Text buttons for the first group (text mode). */
        this.textSet1 = DEFAULT_TEXT_SET1;
        /** Text buttons for the second group (text mode). */
        this.textSet2 = DEFAULT_TEXT_SET2;
        /** Text buttons for the third group (text mode). */
        this.textSet3 = DEFAULT_TEXT_SET3;
    }
    /** Map ActionBar size to ButtonComponent size (text variant starts from S). */
    get buttonSize() {
        switch (this.size) {
            case 's':
                return 'small';
            case 'm':
                return 'medium';
            case 'l':
            case 'xl':
                return 'large';
            default:
                return 'small';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ActionbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.14", type: ActionbarComponent, isStandalone: true, selector: "appcore-actionbar", inputs: { type: "type", size: "size", showSet2: "showSet2", showSet3: "showSet3", showKebabMenu: "showKebabMenu", set1: "set1", set2: "set2", set3: "set3", textSet1: "textSet1", textSet2: "textSet2", textSet3: "textSet3" }, ngImport: i0, template: `
    <div class="appcore-actionbar" [ngClass]="'appcore-actionbar--' + size">
      @if (type === 'icon') {
        <div class="set">
          @for (button of set1; track button.icon) {
            <button type="button" class="appcore-actionbar__icon-button">
              <app-icon
                [icon]="button.icon"
                [iconSet]="button.iconSet ?? 'material'"
                size="sm"
              ></app-icon>
            </button>
          }
        </div>

        @if (showSet2) {
          <div class="set">
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
            @for (button of set2; track button.icon) {
              <button type="button" class="appcore-actionbar__icon-button">
                <app-icon
                  [icon]="button.icon"
                  [iconSet]="button.iconSet ?? 'material'"
                  size="sm"
                ></app-icon>
              </button>
            }
          </div>
        }

        @if (showSet3) {
          <div class="set">
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
            @for (button of set3; track button.icon) {
              <button type="button" class="appcore-actionbar__icon-button">
                <app-icon
                  [icon]="button.icon"
                  [iconSet]="button.iconSet ?? 'material'"
                  size="sm"
                ></app-icon>
              </button>
            }
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
          </div>
        }

        @if (showKebabMenu) {
          <div class="icon-button-wrapper">
            <button
              type="button"
              class="appcore-actionbar__icon-button appcore-actionbar__icon-button--kebab"
            >
              <app-icon icon="more_vert" iconSet="material" size="sm"></app-icon>
            </button>
          </div>
        }
      } @else {
        <!-- Text Action Bar -->
        <div class="set">
          @for (btn of textSet1; track btn.label + $index) {
            <appcore-button
              class="appcore-actionbar__text-button"
              [size]="buttonSize"
              type="tertiary"
              [buttonText]="true"
              [label]="btn.label"
              [showLeftIcon]="!!btn.leftIconName"
              [leftIconName]="btn.leftIconName ?? ''"
            ></appcore-button>
          }
        </div>

        @if (showSet2) {
          <div class="set">
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
            @for (btn of textSet2; track btn.label + $index) {
              <appcore-button
                class="appcore-actionbar__text-button"
                [size]="buttonSize"
                type="tertiary"
                [buttonText]="true"
                [label]="btn.label"
                [showLeftIcon]="!!btn.leftIconName"
                [leftIconName]="btn.leftIconName ?? ''"
              ></appcore-button>
            }
          </div>
        }

        @if (showSet3) {
          <div class="set">
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
            @for (btn of textSet3; track btn.label + $index) {
              <appcore-button
                class="appcore-actionbar__text-button"
                [size]="buttonSize"
                type="tertiary"
                [buttonText]="true"
                [label]="btn.label"
                [showLeftIcon]="!!btn.leftIconName"
                [leftIconName]="btn.leftIconName ?? ''"
              ></appcore-button>
            }
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
          </div>
        }

        @if (showKebabMenu) {
          <div class="icon-button-wrapper">
            <button
              type="button"
              class="appcore-actionbar__icon-button appcore-actionbar__icon-button--kebab"
            >
              <app-icon icon="more_vert" iconSet="material" size="sm"></app-icon>
            </button>
          </div>
        }
      }
    </div>
  `, isInline: true, styles: ["@charset \"UTF-8\";.AppCore-actionbar{display:inline-flex;align-items:center;gap:.5rem}.AppCore-actionbar .set{display:inline-flex;align-items:center;flex:0 0 auto;gap:.25rem}.AppCore-actionbar__icon-button{display:inline-flex;align-items:center;justify-content:center;padding:.125rem;border-radius:.25rem;border:none;background-color:transparent;cursor:pointer;transition:background-color .15s ease,box-shadow .15s ease,transform .05s ease;outline:none}.AppCore-actionbar__icon-button:hover{background-color:#f5f5f5}.AppCore-actionbar__icon-button:active{background-color:#f5f5f5;transform:translateY(1px)}.AppCore-actionbar__icon-button:disabled{opacity:.4;cursor:not-allowed}.AppCore-actionbar__divider{width:1px;height:1.5rem;background-color:#ccc}.AppCore-actionbar .icon-button-wrapper{display:inline-flex;align-items:center;gap:.25rem;padding:.125rem;background-color:#f5f5f5;border-radius:.25rem}.AppCore-actionbar__text-button{margin:0}.AppCore-actionbar--xs ::ng-deep .icon{width:.875rem!important;height:.875rem!important;font-size:.875rem!important;aspect-ratio:1/1}.AppCore-actionbar--s ::ng-deep .icon{width:1rem!important;height:1rem!important;font-size:1rem!important;aspect-ratio:1/1}.AppCore-actionbar--m ::ng-deep .icon{width:1rem!important;height:1rem!important;font-size:1rem!important;aspect-ratio:1/1}.AppCore-actionbar--l ::ng-deep .icon{width:1.125rem!important;height:1.125rem!important;font-size:1.125rem!important;aspect-ratio:1/1}.AppCore-actionbar--xl ::ng-deep .icon{width:1.25rem!important;height:1.25rem!important;font-size:1.25rem!important;aspect-ratio:1/1}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }, { kind: "component", type: ButtonComponent, selector: "appcore-button", inputs: ["buttonText", "label", "size", "state", "type", "nativeType", "showLeftIcon", "showRightIcon", "leftIconName", "rightIconName", "leftIconSet", "rightIconSet", "leftIconSrc", "rightIconSrc"], outputs: ["buttonClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ActionbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-actionbar', standalone: true, imports: [CommonModule, IconComponent, ButtonComponent], template: `
    <div class="appcore-actionbar" [ngClass]="'appcore-actionbar--' + size">
      @if (type === 'icon') {
        <div class="set">
          @for (button of set1; track button.icon) {
            <button type="button" class="appcore-actionbar__icon-button">
              <app-icon
                [icon]="button.icon"
                [iconSet]="button.iconSet ?? 'material'"
                size="sm"
              ></app-icon>
            </button>
          }
        </div>

        @if (showSet2) {
          <div class="set">
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
            @for (button of set2; track button.icon) {
              <button type="button" class="appcore-actionbar__icon-button">
                <app-icon
                  [icon]="button.icon"
                  [iconSet]="button.iconSet ?? 'material'"
                  size="sm"
                ></app-icon>
              </button>
            }
          </div>
        }

        @if (showSet3) {
          <div class="set">
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
            @for (button of set3; track button.icon) {
              <button type="button" class="appcore-actionbar__icon-button">
                <app-icon
                  [icon]="button.icon"
                  [iconSet]="button.iconSet ?? 'material'"
                  size="sm"
                ></app-icon>
              </button>
            }
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
          </div>
        }

        @if (showKebabMenu) {
          <div class="icon-button-wrapper">
            <button
              type="button"
              class="appcore-actionbar__icon-button appcore-actionbar__icon-button--kebab"
            >
              <app-icon icon="more_vert" iconSet="material" size="sm"></app-icon>
            </button>
          </div>
        }
      } @else {
        <!-- Text Action Bar -->
        <div class="set">
          @for (btn of textSet1; track btn.label + $index) {
            <appcore-button
              class="appcore-actionbar__text-button"
              [size]="buttonSize"
              type="tertiary"
              [buttonText]="true"
              [label]="btn.label"
              [showLeftIcon]="!!btn.leftIconName"
              [leftIconName]="btn.leftIconName ?? ''"
            ></appcore-button>
          }
        </div>

        @if (showSet2) {
          <div class="set">
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
            @for (btn of textSet2; track btn.label + $index) {
              <appcore-button
                class="appcore-actionbar__text-button"
                [size]="buttonSize"
                type="tertiary"
                [buttonText]="true"
                [label]="btn.label"
                [showLeftIcon]="!!btn.leftIconName"
                [leftIconName]="btn.leftIconName ?? ''"
              ></appcore-button>
            }
          </div>
        }

        @if (showSet3) {
          <div class="set">
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
            @for (btn of textSet3; track btn.label + $index) {
              <appcore-button
                class="appcore-actionbar__text-button"
                [size]="buttonSize"
                type="tertiary"
                [buttonText]="true"
                [label]="btn.label"
                [showLeftIcon]="!!btn.leftIconName"
                [leftIconName]="btn.leftIconName ?? ''"
              ></appcore-button>
            }
            <div class="appcore-actionbar__divider" aria-hidden="true"></div>
          </div>
        }

        @if (showKebabMenu) {
          <div class="icon-button-wrapper">
            <button
              type="button"
              class="appcore-actionbar__icon-button appcore-actionbar__icon-button--kebab"
            >
              <app-icon icon="more_vert" iconSet="material" size="sm"></app-icon>
            </button>
          </div>
        }
      }
    </div>
  `, styles: ["@charset \"UTF-8\";.AppCore-actionbar{display:inline-flex;align-items:center;gap:.5rem}.AppCore-actionbar .set{display:inline-flex;align-items:center;flex:0 0 auto;gap:.25rem}.AppCore-actionbar__icon-button{display:inline-flex;align-items:center;justify-content:center;padding:.125rem;border-radius:.25rem;border:none;background-color:transparent;cursor:pointer;transition:background-color .15s ease,box-shadow .15s ease,transform .05s ease;outline:none}.AppCore-actionbar__icon-button:hover{background-color:#f5f5f5}.AppCore-actionbar__icon-button:active{background-color:#f5f5f5;transform:translateY(1px)}.AppCore-actionbar__icon-button:disabled{opacity:.4;cursor:not-allowed}.AppCore-actionbar__divider{width:1px;height:1.5rem;background-color:#ccc}.AppCore-actionbar .icon-button-wrapper{display:inline-flex;align-items:center;gap:.25rem;padding:.125rem;background-color:#f5f5f5;border-radius:.25rem}.AppCore-actionbar__text-button{margin:0}.AppCore-actionbar--xs ::ng-deep .icon{width:.875rem!important;height:.875rem!important;font-size:.875rem!important;aspect-ratio:1/1}.AppCore-actionbar--s ::ng-deep .icon{width:1rem!important;height:1rem!important;font-size:1rem!important;aspect-ratio:1/1}.AppCore-actionbar--m ::ng-deep .icon{width:1rem!important;height:1rem!important;font-size:1rem!important;aspect-ratio:1/1}.AppCore-actionbar--l ::ng-deep .icon{width:1.125rem!important;height:1.125rem!important;font-size:1.125rem!important;aspect-ratio:1/1}.AppCore-actionbar--xl ::ng-deep .icon{width:1.25rem!important;height:1.25rem!important;font-size:1.25rem!important;aspect-ratio:1/1}\n"] }]
        }], propDecorators: { type: [{
                type: Input
            }], size: [{
                type: Input
            }], showSet2: [{
                type: Input
            }], showSet3: [{
                type: Input
            }], showKebabMenu: [{
                type: Input
            }], set1: [{
                type: Input
            }], set2: [{
                type: Input
            }], set3: [{
                type: Input
            }], textSet1: [{
                type: Input
            }], textSet2: [{
                type: Input
            }], textSet3: [{
                type: Input
            }] } });

class AlertComponent {
    constructor() {
        this.type = 'Information';
        this.title = '';
        this.description = 'Alert description text goes here.';
        this.showIcon = true;
        this.dismissible = false;
        this.dismiss = new EventEmitter();
    }
    get iconName() {
        switch (this.type) {
            case 'Success': return 'check_circle';
            case 'Warning': return 'warning';
            case 'Error': return 'error';
            case 'Information':
            default: return 'info';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: AlertComponent, isStandalone: true, selector: "appcore-alert", inputs: { type: "type", title: "title", description: "description", showIcon: "showIcon", dismissible: "dismissible" }, outputs: { dismiss: "dismiss" }, ngImport: i0, template: `
    <div
      class="appcore-alert"
      [ngClass]="'appcore-alert--type-' + type"
      role="alert"
    >
      <app-icon
        *ngIf="showIcon"
        class="appcore-alert__icon"
        [icon]="iconName"
        iconSet="material"
        size="md"
      ></app-icon>

      <div class="appcore-alert__content">
        <span *ngIf="title" class="appcore-alert__title">{{ title }}</span>
        <span *ngIf="description" class="appcore-alert__description">{{ description }}</span>
      </div>

      <button
        *ngIf="dismissible"
        type="button"
        class="appcore-alert__close"
        (click)="dismiss.emit()"
        aria-label="Close"
      >
        <app-icon icon="close" iconSet="material" size="sm"></app-icon>
      </button>
    </div>
  `, isInline: true, styles: [".appcore-alert{display:flex;align-items:flex-start;gap:.5rem;padding:1rem;border-radius:.5rem;font-family:Inter,sans-serif;width:100%;box-sizing:border-box}.appcore-alert__icon{flex-shrink:0;margin-top:1px}.appcore-alert__icon ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-alert__content{flex:1;display:flex;flex-direction:column;gap:.25rem}.appcore-alert__title{font-size:14px;line-height:20px;font-weight:500;color:inherit}.appcore-alert__description{font-size:14px;line-height:20px;font-weight:400;color:inherit}.appcore-alert__close{flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;padding:.125rem;border:none;background:transparent;cursor:pointer;border-radius:.25rem;color:inherit;opacity:.7;transition:opacity .15s ease}.appcore-alert__close:hover{opacity:1}.appcore-alert__close ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-alert--type-Information{background-color:#e7eef3;color:#0c558c}.appcore-alert--type-Success{background-color:#efe;color:#238823}.appcore-alert--type-Warning{background-color:#fff7e0;color:#111}.appcore-alert--type-Error{background-color:#ffeeef;color:#d2222d}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-alert', standalone: true, imports: [CommonModule, IconComponent], template: `
    <div
      class="appcore-alert"
      [ngClass]="'appcore-alert--type-' + type"
      role="alert"
    >
      <app-icon
        *ngIf="showIcon"
        class="appcore-alert__icon"
        [icon]="iconName"
        iconSet="material"
        size="md"
      ></app-icon>

      <div class="appcore-alert__content">
        <span *ngIf="title" class="appcore-alert__title">{{ title }}</span>
        <span *ngIf="description" class="appcore-alert__description">{{ description }}</span>
      </div>

      <button
        *ngIf="dismissible"
        type="button"
        class="appcore-alert__close"
        (click)="dismiss.emit()"
        aria-label="Close"
      >
        <app-icon icon="close" iconSet="material" size="sm"></app-icon>
      </button>
    </div>
  `, styles: [".appcore-alert{display:flex;align-items:flex-start;gap:.5rem;padding:1rem;border-radius:.5rem;font-family:Inter,sans-serif;width:100%;box-sizing:border-box}.appcore-alert__icon{flex-shrink:0;margin-top:1px}.appcore-alert__icon ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-alert__content{flex:1;display:flex;flex-direction:column;gap:.25rem}.appcore-alert__title{font-size:14px;line-height:20px;font-weight:500;color:inherit}.appcore-alert__description{font-size:14px;line-height:20px;font-weight:400;color:inherit}.appcore-alert__close{flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;padding:.125rem;border:none;background:transparent;cursor:pointer;border-radius:.25rem;color:inherit;opacity:.7;transition:opacity .15s ease}.appcore-alert__close:hover{opacity:1}.appcore-alert__close ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-alert--type-Information{background-color:#e7eef3;color:#0c558c}.appcore-alert--type-Success{background-color:#efe;color:#238823}.appcore-alert--type-Warning{background-color:#fff7e0;color:#111}.appcore-alert--type-Error{background-color:#ffeeef;color:#d2222d}\n"] }]
        }], propDecorators: { type: [{
                type: Input
            }], title: [{
                type: Input
            }], description: [{
                type: Input
            }], showIcon: [{
                type: Input
            }], dismissible: [{
                type: Input
            }], dismiss: [{
                type: Output
            }] } });

class BadgeComponent {
    constructor() {
        this.label = 'Label';
        this.type = 'Default';
        this.badgeStyle = 'Outlined';
        this.size = 'S';
        this.showPrefixIcon = false;
        this.showSuffixIcon = false;
        this.prefixIcon = 'add';
        this.prefixIconSet = 'material';
        this.suffixIcon = 'add';
        this.suffixIconSet = 'material';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: BadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: BadgeComponent, isStandalone: true, selector: "app-badge", inputs: { label: "label", type: "type", badgeStyle: "badgeStyle", size: "size", showPrefixIcon: "showPrefixIcon", showSuffixIcon: "showSuffixIcon", prefixIcon: "prefixIcon", prefixIconSet: "prefixIconSet", prefixIconSrc: "prefixIconSrc", suffixIcon: "suffixIcon", suffixIconSet: "suffixIconSet", suffixIconSrc: "suffixIconSrc" }, ngImport: i0, template: `
    <span
      class="appcore-badge"
      [ngClass]="[
        'appcore-badge--type-' + type,
        'appcore-badge--style-' + badgeStyle,
        'appcore-badge--size-' + size
      ]"
    >
      <app-icon
        *ngIf="showPrefixIcon"
        class="appcore-badge__icon"
        [icon]="prefixIcon"
        [iconSet]="prefixIconSet"
        [src]="prefixIconSrc"
        size="sm"
      ></app-icon>

      <span class="appcore-badge__label">{{ label }}</span>

      <app-icon
        *ngIf="showSuffixIcon"
        class="appcore-badge__icon"
        [icon]="suffixIcon"
        [iconSet]="suffixIconSet"
        [src]="suffixIconSrc"
        size="sm"
      ></app-icon>
    </span>
  `, isInline: true, styles: [".appcore-badge{display:inline-flex;align-items:center;gap:2px;border-radius:80px;border:1px solid transparent;white-space:nowrap;font-family:Inter,sans-serif;font-weight:400}.appcore-badge--size-S{padding:3px 6px}.appcore-badge--size-S .appcore-badge__label{font-size:10px;line-height:14px}.appcore-badge--size-S .appcore-badge__icon ::ng-deep .material-symbols-rounded,.appcore-badge--size-S .appcore-badge__icon ::ng-deep img.icon{font-size:12px!important;width:12px!important;height:12px!important}.appcore-badge--size-M{padding:4px 8px}.appcore-badge--size-M .appcore-badge__label{font-size:12px;line-height:16px}.appcore-badge--size-M .appcore-badge__icon ::ng-deep .material-symbols-rounded,.appcore-badge--size-M .appcore-badge__icon ::ng-deep img.icon{font-size:14px!important;width:14px!important;height:14px!important}.appcore-badge--size-L{padding:5px 10px}.appcore-badge--size-L .appcore-badge__label{font-size:14px;line-height:18px}.appcore-badge--size-L .appcore-badge__icon ::ng-deep .material-symbols-rounded,.appcore-badge--size-L .appcore-badge__icon ::ng-deep img.icon{font-size:16px!important;width:16px!important;height:16px!important}.appcore-badge--type-Default.appcore-badge--style-Outlined{background-color:#fff;border-color:#ccc;color:#3d3d3d}.appcore-badge--type-Default.appcore-badge--style-Toned{background-color:#f5f5f5;border-color:transparent;color:#3d3d3d}.appcore-badge--type-Default.appcore-badge--style-Highlighted{background-color:#252525;border-color:transparent;color:#fff}.appcore-badge--type-Error.appcore-badge--style-Outlined{background-color:#fff;border-color:#b01d26;color:#d2222d}.appcore-badge--type-Error.appcore-badge--style-Toned{background-color:#ffeeef;border-color:transparent;color:#d2222d}.appcore-badge--type-Error.appcore-badge--style-Highlighted{background-color:#d2222d;border-color:transparent;color:#fff}.appcore-badge--type-Success.appcore-badge--style-Outlined{background-color:#fff;border-color:#58a558;color:#238823}.appcore-badge--type-Success.appcore-badge--style-Toned{background-color:#efe;border-color:transparent;color:#238823}.appcore-badge--type-Success.appcore-badge--style-Highlighted{background-color:#238823;border-color:transparent;color:#fff}.appcore-badge--type-Warning.appcore-badge--style-Outlined{background-color:#fff;border-color:#ffce3d;color:#ffbf00}.appcore-badge--type-Warning.appcore-badge--style-Toned{background-color:#fff2cc;border-color:transparent;color:#111}.appcore-badge--type-Warning.appcore-badge--style-Highlighted{background-color:#ffbf00;border-color:transparent;color:#111}.appcore-badge--type-Information.appcore-badge--style-Outlined{background-color:#fff;border-color:#0c558c;color:#0c558c}.appcore-badge--type-Information.appcore-badge--style-Toned{background-color:#e7eef3;border-color:transparent;color:#0c558c}.appcore-badge--type-Information.appcore-badge--style-Highlighted{background-color:#0c558c;border-color:transparent;color:#fff}.appcore-badge__icon ::ng-deep .material-symbols-rounded,.appcore-badge__icon ::ng-deep img.icon{color:inherit!important}.appcore-badge__label{display:inline;font-family:inherit;font-weight:inherit;color:inherit}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: BadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-badge', standalone: true, imports: [CommonModule, IconComponent], template: `
    <span
      class="appcore-badge"
      [ngClass]="[
        'appcore-badge--type-' + type,
        'appcore-badge--style-' + badgeStyle,
        'appcore-badge--size-' + size
      ]"
    >
      <app-icon
        *ngIf="showPrefixIcon"
        class="appcore-badge__icon"
        [icon]="prefixIcon"
        [iconSet]="prefixIconSet"
        [src]="prefixIconSrc"
        size="sm"
      ></app-icon>

      <span class="appcore-badge__label">{{ label }}</span>

      <app-icon
        *ngIf="showSuffixIcon"
        class="appcore-badge__icon"
        [icon]="suffixIcon"
        [iconSet]="suffixIconSet"
        [src]="suffixIconSrc"
        size="sm"
      ></app-icon>
    </span>
  `, styles: [".appcore-badge{display:inline-flex;align-items:center;gap:2px;border-radius:80px;border:1px solid transparent;white-space:nowrap;font-family:Inter,sans-serif;font-weight:400}.appcore-badge--size-S{padding:3px 6px}.appcore-badge--size-S .appcore-badge__label{font-size:10px;line-height:14px}.appcore-badge--size-S .appcore-badge__icon ::ng-deep .material-symbols-rounded,.appcore-badge--size-S .appcore-badge__icon ::ng-deep img.icon{font-size:12px!important;width:12px!important;height:12px!important}.appcore-badge--size-M{padding:4px 8px}.appcore-badge--size-M .appcore-badge__label{font-size:12px;line-height:16px}.appcore-badge--size-M .appcore-badge__icon ::ng-deep .material-symbols-rounded,.appcore-badge--size-M .appcore-badge__icon ::ng-deep img.icon{font-size:14px!important;width:14px!important;height:14px!important}.appcore-badge--size-L{padding:5px 10px}.appcore-badge--size-L .appcore-badge__label{font-size:14px;line-height:18px}.appcore-badge--size-L .appcore-badge__icon ::ng-deep .material-symbols-rounded,.appcore-badge--size-L .appcore-badge__icon ::ng-deep img.icon{font-size:16px!important;width:16px!important;height:16px!important}.appcore-badge--type-Default.appcore-badge--style-Outlined{background-color:#fff;border-color:#ccc;color:#3d3d3d}.appcore-badge--type-Default.appcore-badge--style-Toned{background-color:#f5f5f5;border-color:transparent;color:#3d3d3d}.appcore-badge--type-Default.appcore-badge--style-Highlighted{background-color:#252525;border-color:transparent;color:#fff}.appcore-badge--type-Error.appcore-badge--style-Outlined{background-color:#fff;border-color:#b01d26;color:#d2222d}.appcore-badge--type-Error.appcore-badge--style-Toned{background-color:#ffeeef;border-color:transparent;color:#d2222d}.appcore-badge--type-Error.appcore-badge--style-Highlighted{background-color:#d2222d;border-color:transparent;color:#fff}.appcore-badge--type-Success.appcore-badge--style-Outlined{background-color:#fff;border-color:#58a558;color:#238823}.appcore-badge--type-Success.appcore-badge--style-Toned{background-color:#efe;border-color:transparent;color:#238823}.appcore-badge--type-Success.appcore-badge--style-Highlighted{background-color:#238823;border-color:transparent;color:#fff}.appcore-badge--type-Warning.appcore-badge--style-Outlined{background-color:#fff;border-color:#ffce3d;color:#ffbf00}.appcore-badge--type-Warning.appcore-badge--style-Toned{background-color:#fff2cc;border-color:transparent;color:#111}.appcore-badge--type-Warning.appcore-badge--style-Highlighted{background-color:#ffbf00;border-color:transparent;color:#111}.appcore-badge--type-Information.appcore-badge--style-Outlined{background-color:#fff;border-color:#0c558c;color:#0c558c}.appcore-badge--type-Information.appcore-badge--style-Toned{background-color:#e7eef3;border-color:transparent;color:#0c558c}.appcore-badge--type-Information.appcore-badge--style-Highlighted{background-color:#0c558c;border-color:transparent;color:#fff}.appcore-badge__icon ::ng-deep .material-symbols-rounded,.appcore-badge__icon ::ng-deep img.icon{color:inherit!important}.appcore-badge__label{display:inline;font-family:inherit;font-weight:inherit;color:inherit}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], type: [{
                type: Input
            }], badgeStyle: [{
                type: Input
            }], size: [{
                type: Input
            }], showPrefixIcon: [{
                type: Input
            }], showSuffixIcon: [{
                type: Input
            }], prefixIcon: [{
                type: Input
            }], prefixIconSet: [{
                type: Input
            }], prefixIconSrc: [{
                type: Input
            }], suffixIcon: [{
                type: Input
            }], suffixIconSet: [{
                type: Input
            }], suffixIconSrc: [{
                type: Input
            }] } });

class BadgeIndicatorComponent {
    constructor() {
        this.type = 'Default';
        this.indicatorStyle = 'Dot - Inline';
        this.label = 'Label';
        this.count = '+99';
    }
    get styleKey() {
        const map = {
            'Dot - Inline': 'dot-inline',
            'Dot - Overlapping': 'dot-overlapping',
            'With Text': 'text',
            'With Text - Overlapping': 'text-overlapping',
        };
        return map[this.indicatorStyle];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: BadgeIndicatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: BadgeIndicatorComponent, isStandalone: true, selector: "app-badge-indicator", inputs: { type: "type", indicatorStyle: "indicatorStyle", label: "label", count: "count" }, ngImport: i0, template: `
    <div
      class="appcore-badge-indicator"
      [ngClass]="[
        'appcore-badge-indicator--type-' + type,
        'appcore-badge-indicator--style-' + styleKey
      ]"
    >
      <!-- Dot (Dot - Inline and Dot - Overlapping) -->
      <div
        *ngIf="indicatorStyle === 'Dot - Inline' || indicatorStyle === 'Dot - Overlapping'"
        class="appcore-badge-indicator__dot"
      ></div>

      <!-- Avatar (overlapping styles) -->
      <span
        *ngIf="indicatorStyle === 'Dot - Overlapping' || indicatorStyle === 'With Text - Overlapping'"
        class="appcore-badge-indicator__avatar"
      >
        <span class="material-symbols-rounded appcore-badge-indicator__avatar-icon">person</span>
      </span>

      <!-- Label (Dot - Inline only) -->
      <span
        *ngIf="indicatorStyle === 'Dot - Inline'"
        class="appcore-badge-indicator__label"
      >{{ label }}</span>

      <!-- Count pill (With Text and With Text - Overlapping) -->
      <div
        *ngIf="indicatorStyle === 'With Text' || indicatorStyle === 'With Text - Overlapping'"
        class="appcore-badge-indicator__pill"
      >
        <span class="appcore-badge-indicator__count">{{ count }}</span>
      </div>
    </div>
  `, isInline: true, styles: [".appcore-badge-indicator{display:inline-flex;align-items:center;gap:4px}.appcore-badge-indicator--style-dot-overlapping{position:relative;width:24px;height:24px;gap:0}.appcore-badge-indicator--style-dot-overlapping .appcore-badge-indicator__dot{position:absolute;top:0;right:0;z-index:1}.appcore-badge-indicator--style-text{gap:0}.appcore-badge-indicator--style-text-overlapping{position:relative;width:28px;height:28px;gap:0}.appcore-badge-indicator--style-text-overlapping .appcore-badge-indicator__avatar{position:absolute;top:2px;left:2px}.appcore-badge-indicator--style-text-overlapping .appcore-badge-indicator__pill{position:absolute;top:0;left:14px}.appcore-badge-indicator__dot{width:8px;height:8px;border-radius:40px;flex-shrink:0}.appcore-badge-indicator__avatar{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:50%;overflow:hidden;flex-shrink:0;background-color:#f5f5f5}.appcore-badge-indicator__avatar-icon{font-size:16px!important;width:16px!important;height:16px!important;color:#a3a3a3;-webkit-user-select:none;user-select:none}.appcore-badge-indicator__label{font-family:Inter,sans-serif;font-size:12px;line-height:16px;font-weight:400;color:#3d3d3d;white-space:nowrap}.appcore-badge-indicator__pill{display:inline-flex;align-items:center;justify-content:center;min-width:18px;padding:2px 4px;border-radius:100px}.appcore-badge-indicator__count{font-family:Inter,sans-serif;font-size:10px;line-height:14px;font-weight:400;white-space:nowrap}.appcore-badge-indicator--type-Default .appcore-badge-indicator__dot,.appcore-badge-indicator--type-Default .appcore-badge-indicator__pill{background-color:#0c558c}.appcore-badge-indicator--type-Default .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#fff}.appcore-badge-indicator--type-Error .appcore-badge-indicator__dot,.appcore-badge-indicator--type-Error .appcore-badge-indicator__pill{background-color:#d2222d}.appcore-badge-indicator--type-Error .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#fff}.appcore-badge-indicator--type-Success .appcore-badge-indicator__dot,.appcore-badge-indicator--type-Success .appcore-badge-indicator__pill{background-color:#238823}.appcore-badge-indicator--type-Success .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#fff}.appcore-badge-indicator--type-Warning .appcore-badge-indicator__dot,.appcore-badge-indicator--type-Warning .appcore-badge-indicator__pill{background-color:#ffbf00}.appcore-badge-indicator--type-Warning .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#252525}.appcore-badge-indicator--type-Inactive .appcore-badge-indicator__dot{background-color:#a3a3a3}.appcore-badge-indicator--type-Inactive .appcore-badge-indicator__pill{background-color:#f5f5f5}.appcore-badge-indicator--type-Inactive .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#a3a3a3}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: BadgeIndicatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-badge-indicator', standalone: true, imports: [CommonModule], template: `
    <div
      class="appcore-badge-indicator"
      [ngClass]="[
        'appcore-badge-indicator--type-' + type,
        'appcore-badge-indicator--style-' + styleKey
      ]"
    >
      <!-- Dot (Dot - Inline and Dot - Overlapping) -->
      <div
        *ngIf="indicatorStyle === 'Dot - Inline' || indicatorStyle === 'Dot - Overlapping'"
        class="appcore-badge-indicator__dot"
      ></div>

      <!-- Avatar (overlapping styles) -->
      <span
        *ngIf="indicatorStyle === 'Dot - Overlapping' || indicatorStyle === 'With Text - Overlapping'"
        class="appcore-badge-indicator__avatar"
      >
        <span class="material-symbols-rounded appcore-badge-indicator__avatar-icon">person</span>
      </span>

      <!-- Label (Dot - Inline only) -->
      <span
        *ngIf="indicatorStyle === 'Dot - Inline'"
        class="appcore-badge-indicator__label"
      >{{ label }}</span>

      <!-- Count pill (With Text and With Text - Overlapping) -->
      <div
        *ngIf="indicatorStyle === 'With Text' || indicatorStyle === 'With Text - Overlapping'"
        class="appcore-badge-indicator__pill"
      >
        <span class="appcore-badge-indicator__count">{{ count }}</span>
      </div>
    </div>
  `, styles: [".appcore-badge-indicator{display:inline-flex;align-items:center;gap:4px}.appcore-badge-indicator--style-dot-overlapping{position:relative;width:24px;height:24px;gap:0}.appcore-badge-indicator--style-dot-overlapping .appcore-badge-indicator__dot{position:absolute;top:0;right:0;z-index:1}.appcore-badge-indicator--style-text{gap:0}.appcore-badge-indicator--style-text-overlapping{position:relative;width:28px;height:28px;gap:0}.appcore-badge-indicator--style-text-overlapping .appcore-badge-indicator__avatar{position:absolute;top:2px;left:2px}.appcore-badge-indicator--style-text-overlapping .appcore-badge-indicator__pill{position:absolute;top:0;left:14px}.appcore-badge-indicator__dot{width:8px;height:8px;border-radius:40px;flex-shrink:0}.appcore-badge-indicator__avatar{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:50%;overflow:hidden;flex-shrink:0;background-color:#f5f5f5}.appcore-badge-indicator__avatar-icon{font-size:16px!important;width:16px!important;height:16px!important;color:#a3a3a3;-webkit-user-select:none;user-select:none}.appcore-badge-indicator__label{font-family:Inter,sans-serif;font-size:12px;line-height:16px;font-weight:400;color:#3d3d3d;white-space:nowrap}.appcore-badge-indicator__pill{display:inline-flex;align-items:center;justify-content:center;min-width:18px;padding:2px 4px;border-radius:100px}.appcore-badge-indicator__count{font-family:Inter,sans-serif;font-size:10px;line-height:14px;font-weight:400;white-space:nowrap}.appcore-badge-indicator--type-Default .appcore-badge-indicator__dot,.appcore-badge-indicator--type-Default .appcore-badge-indicator__pill{background-color:#0c558c}.appcore-badge-indicator--type-Default .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#fff}.appcore-badge-indicator--type-Error .appcore-badge-indicator__dot,.appcore-badge-indicator--type-Error .appcore-badge-indicator__pill{background-color:#d2222d}.appcore-badge-indicator--type-Error .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#fff}.appcore-badge-indicator--type-Success .appcore-badge-indicator__dot,.appcore-badge-indicator--type-Success .appcore-badge-indicator__pill{background-color:#238823}.appcore-badge-indicator--type-Success .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#fff}.appcore-badge-indicator--type-Warning .appcore-badge-indicator__dot,.appcore-badge-indicator--type-Warning .appcore-badge-indicator__pill{background-color:#ffbf00}.appcore-badge-indicator--type-Warning .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#252525}.appcore-badge-indicator--type-Inactive .appcore-badge-indicator__dot{background-color:#a3a3a3}.appcore-badge-indicator--type-Inactive .appcore-badge-indicator__pill{background-color:#f5f5f5}.appcore-badge-indicator--type-Inactive .appcore-badge-indicator__pill .appcore-badge-indicator__count{color:#a3a3a3}\n"] }]
        }], propDecorators: { type: [{
                type: Input
            }], indicatorStyle: [{
                type: Input
            }], label: [{
                type: Input
            }], count: [{
                type: Input
            }] } });

class BannerComponent {
    constructor() {
        this.type = 'Information';
        this.title = '';
        this.description = 'Banner message goes here.';
        this.showIcon = true;
        this.dismissible = false;
        this.actionLabel = '';
        this.dismiss = new EventEmitter();
        this.action = new EventEmitter();
    }
    get iconName() {
        switch (this.type) {
            case 'Success': return 'check_circle';
            case 'Warning': return 'warning';
            case 'Error': return 'error';
            case 'Information':
            default: return 'info';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: BannerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: BannerComponent, isStandalone: true, selector: "appcore-banner", inputs: { type: "type", title: "title", description: "description", showIcon: "showIcon", dismissible: "dismissible", actionLabel: "actionLabel" }, outputs: { dismiss: "dismiss", action: "action" }, ngImport: i0, template: `
    <div
      class="appcore-banner"
      [ngClass]="'appcore-banner--type-' + type"
      role="alert"
    >
      <app-icon
        *ngIf="showIcon"
        class="appcore-banner__icon"
        [icon]="iconName"
        iconSet="material"
        size="md"
      ></app-icon>

      <div class="appcore-banner__content">
        <span *ngIf="title" class="appcore-banner__title">{{ title }}</span>
        <span *ngIf="description" class="appcore-banner__description">{{ description }}</span>
      </div>

      <div class="appcore-banner__actions" *ngIf="actionLabel">
        <button
          type="button"
          class="appcore-banner__action-btn"
          (click)="action.emit()"
        >
          {{ actionLabel }}
        </button>
      </div>

      <button
        *ngIf="dismissible"
        type="button"
        class="appcore-banner__close"
        (click)="dismiss.emit()"
        aria-label="Close"
      >
        <app-icon icon="close" iconSet="material" size="sm"></app-icon>
      </button>
    </div>
  `, isInline: true, styles: [".appcore-banner{display:flex;align-items:center;gap:.5rem;padding:1.25rem 1.5rem;font-family:Inter,sans-serif;width:100%;box-sizing:border-box;border-left:4px solid transparent}.appcore-banner__icon{flex-shrink:0}.appcore-banner__icon ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-banner__content{flex:1;display:flex;flex-direction:column;gap:.125rem}.appcore-banner__title{font-size:14px;line-height:20px;font-weight:500;color:inherit}.appcore-banner__description{font-size:14px;line-height:20px;font-weight:400;color:inherit}.appcore-banner__actions{flex-shrink:0;display:flex;align-items:center;gap:.5rem}.appcore-banner__action-btn{display:inline-flex;align-items:center;padding:.25rem .75rem;border:1px solid currentColor;background:transparent;cursor:pointer;border-radius:.25rem;font-family:Inter,sans-serif;font-size:14px;line-height:20px;font-weight:500;color:inherit;transition:opacity .15s ease}.appcore-banner__action-btn:hover{opacity:.8}.appcore-banner__close{flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;padding:.125rem;border:none;background:transparent;cursor:pointer;border-radius:.25rem;color:inherit;opacity:.7;transition:opacity .15s ease}.appcore-banner__close:hover{opacity:1}.appcore-banner__close ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-banner--type-Information{background-color:#e7eef3;border-left-color:#0c558c;color:#0c558c}.appcore-banner--type-Success{background-color:#efe;border-left-color:#238823;color:#238823}.appcore-banner--type-Warning{background-color:#fff7e0;border-left-color:#ffbf00;color:#111}.appcore-banner--type-Error{background-color:#ffeeef;border-left-color:#d2222d;color:#d2222d}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: BannerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-banner', standalone: true, imports: [CommonModule, IconComponent], template: `
    <div
      class="appcore-banner"
      [ngClass]="'appcore-banner--type-' + type"
      role="alert"
    >
      <app-icon
        *ngIf="showIcon"
        class="appcore-banner__icon"
        [icon]="iconName"
        iconSet="material"
        size="md"
      ></app-icon>

      <div class="appcore-banner__content">
        <span *ngIf="title" class="appcore-banner__title">{{ title }}</span>
        <span *ngIf="description" class="appcore-banner__description">{{ description }}</span>
      </div>

      <div class="appcore-banner__actions" *ngIf="actionLabel">
        <button
          type="button"
          class="appcore-banner__action-btn"
          (click)="action.emit()"
        >
          {{ actionLabel }}
        </button>
      </div>

      <button
        *ngIf="dismissible"
        type="button"
        class="appcore-banner__close"
        (click)="dismiss.emit()"
        aria-label="Close"
      >
        <app-icon icon="close" iconSet="material" size="sm"></app-icon>
      </button>
    </div>
  `, styles: [".appcore-banner{display:flex;align-items:center;gap:.5rem;padding:1.25rem 1.5rem;font-family:Inter,sans-serif;width:100%;box-sizing:border-box;border-left:4px solid transparent}.appcore-banner__icon{flex-shrink:0}.appcore-banner__icon ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-banner__content{flex:1;display:flex;flex-direction:column;gap:.125rem}.appcore-banner__title{font-size:14px;line-height:20px;font-weight:500;color:inherit}.appcore-banner__description{font-size:14px;line-height:20px;font-weight:400;color:inherit}.appcore-banner__actions{flex-shrink:0;display:flex;align-items:center;gap:.5rem}.appcore-banner__action-btn{display:inline-flex;align-items:center;padding:.25rem .75rem;border:1px solid currentColor;background:transparent;cursor:pointer;border-radius:.25rem;font-family:Inter,sans-serif;font-size:14px;line-height:20px;font-weight:500;color:inherit;transition:opacity .15s ease}.appcore-banner__action-btn:hover{opacity:.8}.appcore-banner__close{flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;padding:.125rem;border:none;background:transparent;cursor:pointer;border-radius:.25rem;color:inherit;opacity:.7;transition:opacity .15s ease}.appcore-banner__close:hover{opacity:1}.appcore-banner__close ::ng-deep .material-symbols-rounded{color:inherit!important}.appcore-banner--type-Information{background-color:#e7eef3;border-left-color:#0c558c;color:#0c558c}.appcore-banner--type-Success{background-color:#efe;border-left-color:#238823;color:#238823}.appcore-banner--type-Warning{background-color:#fff7e0;border-left-color:#ffbf00;color:#111}.appcore-banner--type-Error{background-color:#ffeeef;border-left-color:#d2222d;color:#d2222d}\n"] }]
        }], propDecorators: { type: [{
                type: Input
            }], title: [{
                type: Input
            }], description: [{
                type: Input
            }], showIcon: [{
                type: Input
            }], dismissible: [{
                type: Input
            }], actionLabel: [{
                type: Input
            }], dismiss: [{
                type: Output
            }], action: [{
                type: Output
            }] } });

class BreadcrumbComponent {
    constructor() {
        this.items = [
            { label: 'Home', href: '/' },
            { label: 'Section', href: '/section' },
            { label: 'Current Page' }
        ];
        this.size = 'M';
        this.itemClick = new EventEmitter();
    }
    onItemClick(event, item, index) {
        if (!item.href || item.href === '#') {
            event.preventDefault();
        }
        this.itemClick.emit({ item, index });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: BreadcrumbComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: BreadcrumbComponent, isStandalone: true, selector: "app-breadcrumb", inputs: { items: "items", size: "size" }, outputs: { itemClick: "itemClick" }, ngImport: i0, template: `
    <nav class="appcore-breadcrumb" [ngClass]="'appcore-breadcrumb--size-' + size" aria-label="Breadcrumb">
      <ol class="appcore-breadcrumb__list">
        <ng-container *ngFor="let item of items; let i = index; let last = last">
          <li class="appcore-breadcrumb__item" [class.appcore-breadcrumb__item--current]="last">
            <ng-container *ngIf="last; else linkItem">
              <span class="appcore-breadcrumb__label appcore-breadcrumb__label--current" aria-current="page">
                {{ item.label }}
              </span>
            </ng-container>
            <ng-template #linkItem>
              <a
                class="appcore-breadcrumb__link"
                [href]="item.href || '#'"
                (click)="onItemClick($event, item, i)"
              >
                {{ item.label }}
              </a>
            </ng-template>
          </li>

          <li *ngIf="!last" class="appcore-breadcrumb__separator" aria-hidden="true">
            <app-icon icon="chevron_right" iconSet="material" size="sm"></app-icon>
          </li>
        </ng-container>
      </ol>
    </nav>
  `, isInline: true, styles: [".AppCore-breadcrumb{display:inline-flex;align-items:center}.AppCore-breadcrumb__list{display:inline-flex;align-items:center;flex-wrap:wrap;gap:0;list-style:none;margin:0;padding:0}.AppCore-breadcrumb__item{display:inline-flex;align-items:center}.AppCore-breadcrumb__separator{display:inline-flex;align-items:center;color:#3d3d3d;margin:0 2px}.AppCore-breadcrumb__separator .material-symbols-rounded{font-size:16px!important;line-height:1!important;width:16px!important;height:16px!important}.AppCore-breadcrumb__link{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#0c558c;text-decoration:none;border-radius:.125rem;padding:0 2px;transition:color .15s ease}.AppCore-breadcrumb__link:hover{color:#0c5082;text-decoration:underline}.AppCore-breadcrumb__link:active{color:#0e3f65}.AppCore-breadcrumb__label--current{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;padding:0 2px}.AppCore-breadcrumb--size-S .AppCore-breadcrumb__link,.AppCore-breadcrumb--size-S .AppCore-breadcrumb__label--current{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em}.AppCore-breadcrumb--size-S .AppCore-breadcrumb__separator .material-symbols-rounded{font-size:14px!important;width:14px!important;height:14px!important}.AppCore-breadcrumb--size-M .AppCore-breadcrumb__link,.AppCore-breadcrumb--size-M .AppCore-breadcrumb__label--current{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em}.AppCore-breadcrumb--size-L .AppCore-breadcrumb__link,.AppCore-breadcrumb--size-L .AppCore-breadcrumb__label--current{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em}.AppCore-breadcrumb--size-L .AppCore-breadcrumb__separator .material-symbols-rounded{font-size:18px!important;width:18px!important;height:18px!important}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: BreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-breadcrumb', standalone: true, imports: [CommonModule, IconComponent], template: `
    <nav class="appcore-breadcrumb" [ngClass]="'appcore-breadcrumb--size-' + size" aria-label="Breadcrumb">
      <ol class="appcore-breadcrumb__list">
        <ng-container *ngFor="let item of items; let i = index; let last = last">
          <li class="appcore-breadcrumb__item" [class.appcore-breadcrumb__item--current]="last">
            <ng-container *ngIf="last; else linkItem">
              <span class="appcore-breadcrumb__label appcore-breadcrumb__label--current" aria-current="page">
                {{ item.label }}
              </span>
            </ng-container>
            <ng-template #linkItem>
              <a
                class="appcore-breadcrumb__link"
                [href]="item.href || '#'"
                (click)="onItemClick($event, item, i)"
              >
                {{ item.label }}
              </a>
            </ng-template>
          </li>

          <li *ngIf="!last" class="appcore-breadcrumb__separator" aria-hidden="true">
            <app-icon icon="chevron_right" iconSet="material" size="sm"></app-icon>
          </li>
        </ng-container>
      </ol>
    </nav>
  `, styles: [".AppCore-breadcrumb{display:inline-flex;align-items:center}.AppCore-breadcrumb__list{display:inline-flex;align-items:center;flex-wrap:wrap;gap:0;list-style:none;margin:0;padding:0}.AppCore-breadcrumb__item{display:inline-flex;align-items:center}.AppCore-breadcrumb__separator{display:inline-flex;align-items:center;color:#3d3d3d;margin:0 2px}.AppCore-breadcrumb__separator .material-symbols-rounded{font-size:16px!important;line-height:1!important;width:16px!important;height:16px!important}.AppCore-breadcrumb__link{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#0c558c;text-decoration:none;border-radius:.125rem;padding:0 2px;transition:color .15s ease}.AppCore-breadcrumb__link:hover{color:#0c5082;text-decoration:underline}.AppCore-breadcrumb__link:active{color:#0e3f65}.AppCore-breadcrumb__label--current{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;padding:0 2px}.AppCore-breadcrumb--size-S .AppCore-breadcrumb__link,.AppCore-breadcrumb--size-S .AppCore-breadcrumb__label--current{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em}.AppCore-breadcrumb--size-S .AppCore-breadcrumb__separator .material-symbols-rounded{font-size:14px!important;width:14px!important;height:14px!important}.AppCore-breadcrumb--size-M .AppCore-breadcrumb__link,.AppCore-breadcrumb--size-M .AppCore-breadcrumb__label--current{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em}.AppCore-breadcrumb--size-L .AppCore-breadcrumb__link,.AppCore-breadcrumb--size-L .AppCore-breadcrumb__label--current{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em}.AppCore-breadcrumb--size-L .AppCore-breadcrumb__separator .material-symbols-rounded{font-size:18px!important;width:18px!important;height:18px!important}\n"] }]
        }], propDecorators: { items: [{
                type: Input
            }], size: [{
                type: Input
            }], itemClick: [{
                type: Output
            }] } });

class CheckboxComponent {
    constructor() {
        /** Visible text label next to the checkbox. */
        this.label = '';
        /** Optional helper text rendered below the label. */
        this.description = '';
        /** aria-label applied when no visible label is provided. */
        this.ariaLabel = '';
        /** Whether the checkbox is checked. */
        this.checked = false;
        /** Shows a dash/minus indicator — used for "select all" partial states. */
        this.indeterminate = false;
        /** Disables interaction. */
        this.disabled = false;
        /** Applies error styling (red border). */
        this.error = false;
        /** Visual size of the checkbox. */
        this.size = 'md';
        /** HTML id forwarded to the native input. */
        this.inputId = '';
        /** Emits the new checked value when the user toggles the checkbox. */
        this.checkedChange = new EventEmitter();
    }
    ngAfterViewChecked() {
        if (this.checkboxEl) {
            this.checkboxEl.nativeElement.indeterminate = this.indeterminate && !this.checked;
        }
    }
    onNativeChange(event) {
        const input = event.target;
        this.checked = input.checked;
        this.checkedChange.emit(input.checked);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: CheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: CheckboxComponent, isStandalone: true, selector: "appcore-checkbox", inputs: { label: "label", description: "description", ariaLabel: "ariaLabel", checked: "checked", indeterminate: "indeterminate", disabled: "disabled", error: "error", size: "size", inputId: "inputId" }, outputs: { checkedChange: "checkedChange" }, viewQueries: [{ propertyName: "checkboxEl", first: true, predicate: ["checkboxEl"], descendants: true }], ngImport: i0, template: `
    <label
      class="appcore-checkbox"
      [ngClass]="[
        'appcore-checkbox--size-' + size,
        disabled ? 'appcore-checkbox--disabled' : '',
        error ? 'appcore-checkbox--error' : ''
      ]"
    >
      <span class="appcore-checkbox__control">
        <input
          #checkboxEl
          type="checkbox"
          class="appcore-checkbox__input"
          [checked]="checked"
          [disabled]="disabled"
          [attr.id]="inputId || null"
          [attr.aria-label]="!label ? ariaLabel || null : null"
          (change)="onNativeChange($event)"
        />
        <span class="appcore-checkbox__box" aria-hidden="true"></span>
      </span>
      <span *ngIf="label || description" class="appcore-checkbox__content">
        <span *ngIf="label" class="appcore-checkbox__label">{{ label }}</span>
        <span *ngIf="description" class="appcore-checkbox__description">{{ description }}</span>
      </span>
    </label>
  `, isInline: true, styles: [".appcore-checkbox{display:inline-flex;align-items:flex-start;gap:.5rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-checkbox--disabled{cursor:not-allowed}.appcore-checkbox--disabled .appcore-checkbox__label,.appcore-checkbox--disabled .appcore-checkbox__description{color:#a3a3a3}.appcore-checkbox--disabled .appcore-checkbox__control{opacity:.4}.appcore-checkbox__control{position:relative;width:16px;height:16px;flex-shrink:0;margin-top:2px}.appcore-checkbox__input{position:absolute;inset:0;opacity:0;margin:0;width:100%;height:100%;cursor:pointer;z-index:1}.appcore-checkbox__input:disabled{cursor:not-allowed}.appcore-checkbox__box{position:absolute;inset:0;border:1.5px solid rgb(204,204,204);border-radius:.25rem;background-color:#fff;transition:border-color .15s ease,background-color .15s ease,box-shadow .15s ease;pointer-events:none}.appcore-checkbox:hover:not(.appcore-checkbox--disabled) .appcore-checkbox__input:not(:checked):not(:indeterminate)+.appcore-checkbox__box{border-color:#0c558c}.appcore-checkbox__input:focus-visible+.appcore-checkbox__box{box-shadow:0 0 0 2px #007bff}.appcore-checkbox__input:checked+.appcore-checkbox__box{background-color:#0c558c;border-color:#0c558c}.appcore-checkbox__input:checked+.appcore-checkbox__box:after{content:\"\";position:absolute;left:4px;top:1.5px;width:5px;height:9px;border:2px solid rgb(255,255,255);border-top:none;border-left:none;transform:rotate(45deg)}.appcore-checkbox__input:indeterminate+.appcore-checkbox__box{background-color:#0c558c;border-color:#0c558c}.appcore-checkbox__input:indeterminate+.appcore-checkbox__box:after{content:\"\";position:absolute;left:50%;top:50%;width:8px;height:2px;background-color:#fff;border-radius:1px;transform:translate(-50%,-50%)}.appcore-checkbox--error .appcore-checkbox__input:not(:checked):not(:disabled)+.appcore-checkbox__box{border-color:#d2222d}.appcore-checkbox__content{display:flex;flex-direction:column;gap:2px}.appcore-checkbox__label{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111}.appcore-checkbox__description{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-checkbox--size-sm{gap:.25rem}.appcore-checkbox--size-sm .appcore-checkbox__control{width:14px;height:14px;margin-top:1px}.appcore-checkbox--size-sm .appcore-checkbox__input:checked+.appcore-checkbox__box:after{left:3px;top:1px;width:4px;height:7px}.appcore-checkbox--size-sm .appcore-checkbox__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-checkbox--size-sm .appcore-checkbox__description{font-family:Inter,sans-serif;font-size:10px;line-height:14px;font-weight:400;color:#525252}.appcore-checkbox--size-lg .appcore-checkbox__control{width:18px;height:18px;margin-top:3px}.appcore-checkbox--size-lg .appcore-checkbox__box{border-radius:3px}.appcore-checkbox--size-lg .appcore-checkbox__input:checked+.appcore-checkbox__box:after{left:5px;top:2px;width:5px;height:10px}.appcore-checkbox--size-lg .appcore-checkbox__input:indeterminate+.appcore-checkbox__box:after{width:10px}.appcore-checkbox--size-lg .appcore-checkbox__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-checkbox--size-lg .appcore-checkbox__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-checkbox-group{display:inline-flex;flex-direction:column;gap:.5rem;font-family:Inter,sans-serif}.appcore-checkbox-group__header{display:flex;flex-direction:column;gap:2px}.appcore-checkbox-group__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:600;color:#111}.appcore-checkbox-group__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#525252}.appcore-checkbox-group__divider{height:1px;background-color:#ccc}.appcore-checkbox-group__items{display:flex;flex-direction:column;gap:.5rem}.appcore-checkbox-group__items--horizontal{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-checkbox-group__error{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: CheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-checkbox', standalone: true, imports: [CommonModule], template: `
    <label
      class="appcore-checkbox"
      [ngClass]="[
        'appcore-checkbox--size-' + size,
        disabled ? 'appcore-checkbox--disabled' : '',
        error ? 'appcore-checkbox--error' : ''
      ]"
    >
      <span class="appcore-checkbox__control">
        <input
          #checkboxEl
          type="checkbox"
          class="appcore-checkbox__input"
          [checked]="checked"
          [disabled]="disabled"
          [attr.id]="inputId || null"
          [attr.aria-label]="!label ? ariaLabel || null : null"
          (change)="onNativeChange($event)"
        />
        <span class="appcore-checkbox__box" aria-hidden="true"></span>
      </span>
      <span *ngIf="label || description" class="appcore-checkbox__content">
        <span *ngIf="label" class="appcore-checkbox__label">{{ label }}</span>
        <span *ngIf="description" class="appcore-checkbox__description">{{ description }}</span>
      </span>
    </label>
  `, styles: [".appcore-checkbox{display:inline-flex;align-items:flex-start;gap:.5rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-checkbox--disabled{cursor:not-allowed}.appcore-checkbox--disabled .appcore-checkbox__label,.appcore-checkbox--disabled .appcore-checkbox__description{color:#a3a3a3}.appcore-checkbox--disabled .appcore-checkbox__control{opacity:.4}.appcore-checkbox__control{position:relative;width:16px;height:16px;flex-shrink:0;margin-top:2px}.appcore-checkbox__input{position:absolute;inset:0;opacity:0;margin:0;width:100%;height:100%;cursor:pointer;z-index:1}.appcore-checkbox__input:disabled{cursor:not-allowed}.appcore-checkbox__box{position:absolute;inset:0;border:1.5px solid rgb(204,204,204);border-radius:.25rem;background-color:#fff;transition:border-color .15s ease,background-color .15s ease,box-shadow .15s ease;pointer-events:none}.appcore-checkbox:hover:not(.appcore-checkbox--disabled) .appcore-checkbox__input:not(:checked):not(:indeterminate)+.appcore-checkbox__box{border-color:#0c558c}.appcore-checkbox__input:focus-visible+.appcore-checkbox__box{box-shadow:0 0 0 2px #007bff}.appcore-checkbox__input:checked+.appcore-checkbox__box{background-color:#0c558c;border-color:#0c558c}.appcore-checkbox__input:checked+.appcore-checkbox__box:after{content:\"\";position:absolute;left:4px;top:1.5px;width:5px;height:9px;border:2px solid rgb(255,255,255);border-top:none;border-left:none;transform:rotate(45deg)}.appcore-checkbox__input:indeterminate+.appcore-checkbox__box{background-color:#0c558c;border-color:#0c558c}.appcore-checkbox__input:indeterminate+.appcore-checkbox__box:after{content:\"\";position:absolute;left:50%;top:50%;width:8px;height:2px;background-color:#fff;border-radius:1px;transform:translate(-50%,-50%)}.appcore-checkbox--error .appcore-checkbox__input:not(:checked):not(:disabled)+.appcore-checkbox__box{border-color:#d2222d}.appcore-checkbox__content{display:flex;flex-direction:column;gap:2px}.appcore-checkbox__label{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111}.appcore-checkbox__description{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-checkbox--size-sm{gap:.25rem}.appcore-checkbox--size-sm .appcore-checkbox__control{width:14px;height:14px;margin-top:1px}.appcore-checkbox--size-sm .appcore-checkbox__input:checked+.appcore-checkbox__box:after{left:3px;top:1px;width:4px;height:7px}.appcore-checkbox--size-sm .appcore-checkbox__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-checkbox--size-sm .appcore-checkbox__description{font-family:Inter,sans-serif;font-size:10px;line-height:14px;font-weight:400;color:#525252}.appcore-checkbox--size-lg .appcore-checkbox__control{width:18px;height:18px;margin-top:3px}.appcore-checkbox--size-lg .appcore-checkbox__box{border-radius:3px}.appcore-checkbox--size-lg .appcore-checkbox__input:checked+.appcore-checkbox__box:after{left:5px;top:2px;width:5px;height:10px}.appcore-checkbox--size-lg .appcore-checkbox__input:indeterminate+.appcore-checkbox__box:after{width:10px}.appcore-checkbox--size-lg .appcore-checkbox__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-checkbox--size-lg .appcore-checkbox__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-checkbox-group{display:inline-flex;flex-direction:column;gap:.5rem;font-family:Inter,sans-serif}.appcore-checkbox-group__header{display:flex;flex-direction:column;gap:2px}.appcore-checkbox-group__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:600;color:#111}.appcore-checkbox-group__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#525252}.appcore-checkbox-group__divider{height:1px;background-color:#ccc}.appcore-checkbox-group__items{display:flex;flex-direction:column;gap:.5rem}.appcore-checkbox-group__items--horizontal{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-checkbox-group__error{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], description: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], checked: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], disabled: [{
                type: Input
            }], error: [{
                type: Input
            }], size: [{
                type: Input
            }], inputId: [{
                type: Input
            }], checkedChange: [{
                type: Output
            }], checkboxEl: [{
                type: ViewChild,
                args: ['checkboxEl']
            }] } });

class CheckboxGroupComponent {
    constructor() {
        /** Array of checkbox items to render. */
        this.items = [];
        /** Group label displayed above the checkboxes. */
        this.groupLabel = '';
        /** Optional helper text below the group label. */
        this.groupDescription = '';
        /** Whether to show a "Select All" checkbox above the list. */
        this.showSelectAll = false;
        /** Label text for the select-all row. */
        this.selectAllLabel = 'Select All';
        /** Layout direction of the checkbox items. */
        this.orientation = 'vertical';
        /** Size applied to all checkboxes in the group. */
        this.size = 'md';
        /** Disables all checkboxes in the group. */
        this.disabled = false;
        /** Error message displayed below the group; also applies error styling to each checkbox. */
        this.error = '';
        /** Emits the full updated items array on any selection change. */
        this.selectionChange = new EventEmitter();
        this._labelId = `checkbox-group-label-${Math.random().toString(36).slice(2)}`;
    }
    get allChecked() {
        return this.items.length > 0 && this.items.every(i => i.checked);
    }
    get someChecked() {
        return this.items.some(i => i.checked);
    }
    onSelectAll(checked) {
        this.items = this.items.map(item => item.disabled ? item : { ...item, checked });
        this.selectionChange.emit([...this.items]);
    }
    onItemChange(item, checked) {
        item.checked = checked;
        this.selectionChange.emit([...this.items]);
    }
    trackById(_index, item) {
        return item.id;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: CheckboxGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: CheckboxGroupComponent, isStandalone: true, selector: "appcore-checkbox-group", inputs: { items: "items", groupLabel: "groupLabel", groupDescription: "groupDescription", showSelectAll: "showSelectAll", selectAllLabel: "selectAllLabel", orientation: "orientation", size: "size", disabled: "disabled", error: "error" }, outputs: { selectionChange: "selectionChange" }, ngImport: i0, template: `
    <div
      class="appcore-checkbox-group"
      role="group"
      [attr.aria-labelledby]="groupLabel ? _labelId : null"
    >
      <!-- Group header -->
      <div *ngIf="groupLabel || groupDescription" class="appcore-checkbox-group__header">
        <span
          *ngIf="groupLabel"
          class="appcore-checkbox-group__label"
          [id]="_labelId"
        >{{ groupLabel }}</span>
        <span *ngIf="groupDescription" class="appcore-checkbox-group__description">
          {{ groupDescription }}
        </span>
      </div>

      <!-- Select All row -->
      <ng-container *ngIf="showSelectAll">
        <appcore-checkbox
          [label]="selectAllLabel"
          [checked]="allChecked"
          [indeterminate]="someChecked && !allChecked"
          [disabled]="disabled"
          [size]="size"
          (checkedChange)="onSelectAll($event)"
        ></appcore-checkbox>
        <div class="appcore-checkbox-group__divider"></div>
      </ng-container>

      <!-- Items -->
      <div
        class="appcore-checkbox-group__items"
        [ngClass]="{ 'appcore-checkbox-group__items--horizontal': orientation === 'horizontal' }"
      >
        <appcore-checkbox
          *ngFor="let item of items; trackBy: trackById"
          [label]="item.label"
          [description]="item.description || ''"
          [checked]="item.checked"
          [disabled]="disabled || !!item.disabled"
          [error]="!!error"
          [size]="size"
          [inputId]="item.id"
          (checkedChange)="onItemChange(item, $event)"
        ></appcore-checkbox>
      </div>

      <!-- Error message -->
      <span *ngIf="error" class="appcore-checkbox-group__error" role="alert">
        {{ error }}
      </span>
    </div>
  `, isInline: true, styles: [".appcore-checkbox{display:inline-flex;align-items:flex-start;gap:.5rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-checkbox--disabled{cursor:not-allowed}.appcore-checkbox--disabled .appcore-checkbox__label,.appcore-checkbox--disabled .appcore-checkbox__description{color:#a3a3a3}.appcore-checkbox--disabled .appcore-checkbox__control{opacity:.4}.appcore-checkbox__control{position:relative;width:16px;height:16px;flex-shrink:0;margin-top:2px}.appcore-checkbox__input{position:absolute;inset:0;opacity:0;margin:0;width:100%;height:100%;cursor:pointer;z-index:1}.appcore-checkbox__input:disabled{cursor:not-allowed}.appcore-checkbox__box{position:absolute;inset:0;border:1.5px solid rgb(204,204,204);border-radius:.25rem;background-color:#fff;transition:border-color .15s ease,background-color .15s ease,box-shadow .15s ease;pointer-events:none}.appcore-checkbox:hover:not(.appcore-checkbox--disabled) .appcore-checkbox__input:not(:checked):not(:indeterminate)+.appcore-checkbox__box{border-color:#0c558c}.appcore-checkbox__input:focus-visible+.appcore-checkbox__box{box-shadow:0 0 0 2px #007bff}.appcore-checkbox__input:checked+.appcore-checkbox__box{background-color:#0c558c;border-color:#0c558c}.appcore-checkbox__input:checked+.appcore-checkbox__box:after{content:\"\";position:absolute;left:4px;top:1.5px;width:5px;height:9px;border:2px solid rgb(255,255,255);border-top:none;border-left:none;transform:rotate(45deg)}.appcore-checkbox__input:indeterminate+.appcore-checkbox__box{background-color:#0c558c;border-color:#0c558c}.appcore-checkbox__input:indeterminate+.appcore-checkbox__box:after{content:\"\";position:absolute;left:50%;top:50%;width:8px;height:2px;background-color:#fff;border-radius:1px;transform:translate(-50%,-50%)}.appcore-checkbox--error .appcore-checkbox__input:not(:checked):not(:disabled)+.appcore-checkbox__box{border-color:#d2222d}.appcore-checkbox__content{display:flex;flex-direction:column;gap:2px}.appcore-checkbox__label{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111}.appcore-checkbox__description{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-checkbox--size-sm{gap:.25rem}.appcore-checkbox--size-sm .appcore-checkbox__control{width:14px;height:14px;margin-top:1px}.appcore-checkbox--size-sm .appcore-checkbox__input:checked+.appcore-checkbox__box:after{left:3px;top:1px;width:4px;height:7px}.appcore-checkbox--size-sm .appcore-checkbox__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-checkbox--size-sm .appcore-checkbox__description{font-family:Inter,sans-serif;font-size:10px;line-height:14px;font-weight:400;color:#525252}.appcore-checkbox--size-lg .appcore-checkbox__control{width:18px;height:18px;margin-top:3px}.appcore-checkbox--size-lg .appcore-checkbox__box{border-radius:3px}.appcore-checkbox--size-lg .appcore-checkbox__input:checked+.appcore-checkbox__box:after{left:5px;top:2px;width:5px;height:10px}.appcore-checkbox--size-lg .appcore-checkbox__input:indeterminate+.appcore-checkbox__box:after{width:10px}.appcore-checkbox--size-lg .appcore-checkbox__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-checkbox--size-lg .appcore-checkbox__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-checkbox-group{display:inline-flex;flex-direction:column;gap:.5rem;font-family:Inter,sans-serif}.appcore-checkbox-group__header{display:flex;flex-direction:column;gap:2px}.appcore-checkbox-group__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:600;color:#111}.appcore-checkbox-group__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#525252}.appcore-checkbox-group__divider{height:1px;background-color:#ccc}.appcore-checkbox-group__items{display:flex;flex-direction:column;gap:.5rem}.appcore-checkbox-group__items--horizontal{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-checkbox-group__error{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CheckboxComponent, selector: "appcore-checkbox", inputs: ["label", "description", "ariaLabel", "checked", "indeterminate", "disabled", "error", "size", "inputId"], outputs: ["checkedChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: CheckboxGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-checkbox-group', standalone: true, imports: [CommonModule, CheckboxComponent], template: `
    <div
      class="appcore-checkbox-group"
      role="group"
      [attr.aria-labelledby]="groupLabel ? _labelId : null"
    >
      <!-- Group header -->
      <div *ngIf="groupLabel || groupDescription" class="appcore-checkbox-group__header">
        <span
          *ngIf="groupLabel"
          class="appcore-checkbox-group__label"
          [id]="_labelId"
        >{{ groupLabel }}</span>
        <span *ngIf="groupDescription" class="appcore-checkbox-group__description">
          {{ groupDescription }}
        </span>
      </div>

      <!-- Select All row -->
      <ng-container *ngIf="showSelectAll">
        <appcore-checkbox
          [label]="selectAllLabel"
          [checked]="allChecked"
          [indeterminate]="someChecked && !allChecked"
          [disabled]="disabled"
          [size]="size"
          (checkedChange)="onSelectAll($event)"
        ></appcore-checkbox>
        <div class="appcore-checkbox-group__divider"></div>
      </ng-container>

      <!-- Items -->
      <div
        class="appcore-checkbox-group__items"
        [ngClass]="{ 'appcore-checkbox-group__items--horizontal': orientation === 'horizontal' }"
      >
        <appcore-checkbox
          *ngFor="let item of items; trackBy: trackById"
          [label]="item.label"
          [description]="item.description || ''"
          [checked]="item.checked"
          [disabled]="disabled || !!item.disabled"
          [error]="!!error"
          [size]="size"
          [inputId]="item.id"
          (checkedChange)="onItemChange(item, $event)"
        ></appcore-checkbox>
      </div>

      <!-- Error message -->
      <span *ngIf="error" class="appcore-checkbox-group__error" role="alert">
        {{ error }}
      </span>
    </div>
  `, styles: [".appcore-checkbox{display:inline-flex;align-items:flex-start;gap:.5rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-checkbox--disabled{cursor:not-allowed}.appcore-checkbox--disabled .appcore-checkbox__label,.appcore-checkbox--disabled .appcore-checkbox__description{color:#a3a3a3}.appcore-checkbox--disabled .appcore-checkbox__control{opacity:.4}.appcore-checkbox__control{position:relative;width:16px;height:16px;flex-shrink:0;margin-top:2px}.appcore-checkbox__input{position:absolute;inset:0;opacity:0;margin:0;width:100%;height:100%;cursor:pointer;z-index:1}.appcore-checkbox__input:disabled{cursor:not-allowed}.appcore-checkbox__box{position:absolute;inset:0;border:1.5px solid rgb(204,204,204);border-radius:.25rem;background-color:#fff;transition:border-color .15s ease,background-color .15s ease,box-shadow .15s ease;pointer-events:none}.appcore-checkbox:hover:not(.appcore-checkbox--disabled) .appcore-checkbox__input:not(:checked):not(:indeterminate)+.appcore-checkbox__box{border-color:#0c558c}.appcore-checkbox__input:focus-visible+.appcore-checkbox__box{box-shadow:0 0 0 2px #007bff}.appcore-checkbox__input:checked+.appcore-checkbox__box{background-color:#0c558c;border-color:#0c558c}.appcore-checkbox__input:checked+.appcore-checkbox__box:after{content:\"\";position:absolute;left:4px;top:1.5px;width:5px;height:9px;border:2px solid rgb(255,255,255);border-top:none;border-left:none;transform:rotate(45deg)}.appcore-checkbox__input:indeterminate+.appcore-checkbox__box{background-color:#0c558c;border-color:#0c558c}.appcore-checkbox__input:indeterminate+.appcore-checkbox__box:after{content:\"\";position:absolute;left:50%;top:50%;width:8px;height:2px;background-color:#fff;border-radius:1px;transform:translate(-50%,-50%)}.appcore-checkbox--error .appcore-checkbox__input:not(:checked):not(:disabled)+.appcore-checkbox__box{border-color:#d2222d}.appcore-checkbox__content{display:flex;flex-direction:column;gap:2px}.appcore-checkbox__label{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111}.appcore-checkbox__description{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-checkbox--size-sm{gap:.25rem}.appcore-checkbox--size-sm .appcore-checkbox__control{width:14px;height:14px;margin-top:1px}.appcore-checkbox--size-sm .appcore-checkbox__input:checked+.appcore-checkbox__box:after{left:3px;top:1px;width:4px;height:7px}.appcore-checkbox--size-sm .appcore-checkbox__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-checkbox--size-sm .appcore-checkbox__description{font-family:Inter,sans-serif;font-size:10px;line-height:14px;font-weight:400;color:#525252}.appcore-checkbox--size-lg .appcore-checkbox__control{width:18px;height:18px;margin-top:3px}.appcore-checkbox--size-lg .appcore-checkbox__box{border-radius:3px}.appcore-checkbox--size-lg .appcore-checkbox__input:checked+.appcore-checkbox__box:after{left:5px;top:2px;width:5px;height:10px}.appcore-checkbox--size-lg .appcore-checkbox__input:indeterminate+.appcore-checkbox__box:after{width:10px}.appcore-checkbox--size-lg .appcore-checkbox__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-checkbox--size-lg .appcore-checkbox__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-checkbox-group{display:inline-flex;flex-direction:column;gap:.5rem;font-family:Inter,sans-serif}.appcore-checkbox-group__header{display:flex;flex-direction:column;gap:2px}.appcore-checkbox-group__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:600;color:#111}.appcore-checkbox-group__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#525252}.appcore-checkbox-group__divider{height:1px;background-color:#ccc}.appcore-checkbox-group__items{display:flex;flex-direction:column;gap:.5rem}.appcore-checkbox-group__items--horizontal{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-checkbox-group__error{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}\n"] }]
        }], propDecorators: { items: [{
                type: Input
            }], groupLabel: [{
                type: Input
            }], groupDescription: [{
                type: Input
            }], showSelectAll: [{
                type: Input
            }], selectAllLabel: [{
                type: Input
            }], orientation: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], error: [{
                type: Input
            }], selectionChange: [{
                type: Output
            }] } });

const DEFAULT_GROUPS = [
    {
        id: 'group-personal',
        label: 'Personal Information',
        columns: [
            { id: 'col-first-name', label: 'First Name', visible: true, locked: true },
            { id: 'col-last-name', label: 'Last Name', visible: true },
            { id: 'col-email', label: 'Email', visible: true },
            { id: 'col-phone', label: 'Phone', visible: false },
            { id: 'col-dob', label: 'Date of Birth', visible: false },
        ],
    },
    {
        id: 'group-address',
        label: 'Address',
        columns: [
            { id: 'col-street', label: 'Street', visible: true },
            { id: 'col-city', label: 'City', visible: true },
            { id: 'col-state', label: 'State', visible: false },
            { id: 'col-zip', label: 'Zip Code', visible: false },
            { id: 'col-country', label: 'Country', visible: true },
        ],
    },
    {
        id: 'group-account',
        label: 'Account Details',
        collapsed: true,
        columns: [
            { id: 'col-account-id', label: 'Account ID', visible: true, locked: true },
            { id: 'col-created', label: 'Created Date', visible: true },
            { id: 'col-modified', label: 'Last Modified', visible: false },
            { id: 'col-status', label: 'Status', visible: true },
        ],
    },
];
class ColumnManagerComponent {
    constructor() {
        /** List of column groups to manage. */
        this.groups = DEFAULT_GROUPS;
        /** Panel title displayed in the header. */
        this.title = 'Manage Columns';
        /** Whether to show the search input. */
        this.searchable = true;
        /** Emits on every visibility/order change (live updates). */
        this.groupsChange = new EventEmitter();
        /** Emits when the user clicks Apply. */
        this.apply = new EventEmitter();
        /** Emits when the user clicks Cancel or the close button. */
        this.cancel = new EventEmitter();
        this.searchQuery = '';
        this.internalGroups = [];
    }
    ngOnInit() {
        this.internalGroups = this.deepCopy(this.groups);
    }
    ngOnChanges(changes) {
        if (changes['groups'] && !changes['groups'].firstChange) {
            this.internalGroups = this.deepCopy(this.groups);
        }
    }
    get allVisible() {
        return this.internalGroups.every(g => g.columns.every(c => c.visible));
    }
    get someVisible() {
        return this.internalGroups.some(g => g.columns.some(c => c.visible));
    }
    get visibleCount() {
        return this.internalGroups.reduce((sum, g) => sum + g.columns.filter(c => c.visible).length, 0);
    }
    get totalCount() {
        return this.internalGroups.reduce((sum, g) => sum + g.columns.length, 0);
    }
    isGroupAllVisible(group) {
        return group.columns.every(c => c.visible);
    }
    isGroupSomeVisible(group) {
        return group.columns.some(c => c.visible);
    }
    getGroupVisibleCount(group) {
        return group.columns.filter(c => c.visible).length;
    }
    getFilteredColumns(group) {
        const q = this.searchQuery.trim().toLowerCase();
        if (!q)
            return group.columns;
        return group.columns.filter(c => c.label.toLowerCase().includes(q));
    }
    toggleAllColumns(visible) {
        this.internalGroups.forEach(g => g.columns.forEach(c => {
            if (!c.locked)
                c.visible = visible;
        }));
        this.emitChange();
    }
    toggleGroup(group, visible) {
        group.columns.forEach(c => {
            if (!c.locked)
                c.visible = visible;
        });
        this.emitChange();
    }
    toggleGroupCollapse(group) {
        group.collapsed = !group.collapsed;
    }
    onColumnVisibilityChange() {
        this.emitChange();
    }
    onGroupDrop(event) {
        moveItemInArray(this.internalGroups, event.previousIndex, event.currentIndex);
        this.emitChange();
    }
    onColumnDrop(event, groupIndex) {
        moveItemInArray(this.internalGroups[groupIndex].columns, event.previousIndex, event.currentIndex);
        this.emitChange();
    }
    onApply() {
        this.apply.emit(this.deepCopy(this.internalGroups));
    }
    onCancel() {
        this.internalGroups = this.deepCopy(this.groups);
        this.searchQuery = '';
        this.cancel.emit();
    }
    emitChange() {
        this.groupsChange.emit(this.deepCopy(this.internalGroups));
    }
    deepCopy(obj) {
        return JSON.parse(JSON.stringify(obj));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ColumnManagerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.14", type: ColumnManagerComponent, isStandalone: true, selector: "appcore-column-manager", inputs: { groups: "groups", title: "title", searchable: "searchable" }, outputs: { groupsChange: "groupsChange", apply: "apply", cancel: "cancel" }, usesOnChanges: true, ngImport: i0, template: `
    <div class="appcore-column-manager">

      <!-- Header -->
      <div class="appcore-column-manager__header">
        <span class="appcore-column-manager__title">{{ title }}</span>
        <button
          type="button"
          class="appcore-column-manager__icon-btn"
          (click)="onCancel()"
          aria-label="Close"
        >
          <app-icon icon="close" iconSet="material" size="sm"></app-icon>
        </button>
      </div>

      <!-- Search -->
      @if (searchable) {
        <div class="appcore-column-manager__search">
          <app-icon icon="search" iconSet="material" size="sm" class="appcore-column-manager__search-icon"></app-icon>
          <input
            type="text"
            class="appcore-column-manager__search-input"
            [(ngModel)]="searchQuery"
            placeholder="Search columns..."
            aria-label="Search columns"
          />
          @if (searchQuery) {
            <button
              type="button"
              class="appcore-column-manager__icon-btn appcore-column-manager__icon-btn--sm"
              (click)="searchQuery = ''"
              aria-label="Clear search"
            >
              <app-icon icon="close" iconSet="material" size="sm"></app-icon>
            </button>
          }
        </div>
      }

      <!-- Select All row -->
      @if (!searchQuery) {
        <div class="appcore-column-manager__select-all">
          <div class="appcore-column-manager__row-left">
            <span class="appcore-column-manager__drag-handle-spacer"></span>
            <label class="appcore-column-manager__check-label">
              <input
                type="checkbox"
                class="appcore-column-manager__checkbox"
                [checked]="allVisible"
                [indeterminate]="someVisible && !allVisible"
                (change)="toggleAllColumns($any($event.target).checked)"
              />
              <span class="appcore-column-manager__label appcore-column-manager__label--bold">Select All</span>
            </label>
          </div>
          <span class="appcore-column-manager__badge">{{ visibleCount }}/{{ totalCount }}</span>
        </div>
      }

      <!-- Groups drop list -->
      <div
        class="appcore-column-manager__groups"
        cdkDropList
        [cdkDropListDisabled]="!!searchQuery"
        (cdkDropListDropped)="onGroupDrop($event)"
      >
        @for (group of internalGroups; track group.id; let gi = $index) {
          <!-- Only show group if it has columns matching search -->
          @if (!searchQuery || getFilteredColumns(group).length > 0) {
            <div
              class="appcore-column-manager__group"
              cdkDrag
              [cdkDragDisabled]="group.locked || !!searchQuery"
            >
              <div *cdkDragPlaceholder class="appcore-column-manager__drop-placeholder"></div>

              <!-- Group Header -->
              <div class="appcore-column-manager__group-header">
                <div class="appcore-column-manager__row-left">
                  <span
                    class="appcore-column-manager__drag-handle"
                    [class.appcore-column-manager__drag-handle--hidden]="group.locked || !!searchQuery"
                    cdkDragHandle
                    aria-label="Drag to reorder group"
                  >
                    <app-icon icon="drag_indicator" iconSet="material" size="sm"></app-icon>
                  </span>
                  <input
                    type="checkbox"
                    class="appcore-column-manager__checkbox"
                    [checked]="isGroupAllVisible(group)"
                    [indeterminate]="isGroupSomeVisible(group) && !isGroupAllVisible(group)"
                    (change)="toggleGroup(group, $any($event.target).checked)"
                  />
                  <button
                    type="button"
                    class="appcore-column-manager__group-toggle"
                    (click)="toggleGroupCollapse(group)"
                  >
                    <app-icon
                      [icon]="group.collapsed && !searchQuery ? 'chevron_right' : 'expand_more'"
                      iconSet="material"
                      size="sm"
                    ></app-icon>
                    <span class="appcore-column-manager__group-label">{{ group.label }}</span>
                  </button>
                </div>
                <span class="appcore-column-manager__badge">
                  {{ getGroupVisibleCount(group) }}/{{ group.columns.length }}
                </span>
              </div>

              <!-- Columns drop list -->
              @if (!group.collapsed || !!searchQuery) {
                <div
                  class="appcore-column-manager__columns"
                  cdkDropList
                  [cdkDropListDisabled]="!!searchQuery"
                  (cdkDropListDropped)="onColumnDrop($event, gi)"
                >
                  @for (column of getFilteredColumns(group); track column.id) {
                    <div
                      class="appcore-column-manager__column"
                      cdkDrag
                      [cdkDragDisabled]="column.locked || !!searchQuery"
                    >
                      <div *cdkDragPlaceholder class="appcore-column-manager__drop-placeholder appcore-column-manager__drop-placeholder--column"></div>

                      <div class="appcore-column-manager__row-left">
                        <span
                          class="appcore-column-manager__drag-handle"
                          [class.appcore-column-manager__drag-handle--hidden]="column.locked || !!searchQuery"
                          cdkDragHandle
                          aria-label="Drag to reorder column"
                        >
                          <app-icon icon="drag_indicator" iconSet="material" size="sm"></app-icon>
                        </span>
                        <label class="appcore-column-manager__check-label">
                          <input
                            type="checkbox"
                            class="appcore-column-manager__checkbox"
                            [(ngModel)]="column.visible"
                            [disabled]="!!column.locked"
                            (ngModelChange)="onColumnVisibilityChange()"
                          />
                          <span class="appcore-column-manager__label">{{ column.label }}</span>
                        </label>
                      </div>

                      @if (column.locked) {
                        <app-icon
                          icon="lock"
                          iconSet="material"
                          size="sm"
                          class="appcore-column-manager__lock-icon"
                        ></app-icon>
                      }
                    </div>
                  }
                </div>
              }
            </div>
          }
        }
      </div>

      <!-- Footer -->
      <div class="appcore-column-manager__footer">
        <button
          type="button"
          class="appcore-column-manager__btn appcore-column-manager__btn--secondary"
          (click)="onCancel()"
        >
          Cancel
        </button>
        <button
          type="button"
          class="appcore-column-manager__btn appcore-column-manager__btn--primary"
          (click)="onApply()"
        >
          Apply
        </button>
      </div>
    </div>
  `, isInline: true, styles: [".appcore-column-manager{display:flex;flex-direction:column;width:280px;max-height:600px;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;overflow:hidden;font-family:Inter,sans-serif;box-shadow:0 4px 16px #00000014}.appcore-column-manager__header{display:flex;align-items:center;justify-content:space-between;padding:1rem 1rem .75rem;border-bottom:1px solid rgb(204,204,204);flex-shrink:0}.appcore-column-manager__title{font-size:14px;font-weight:600;line-height:20px;color:#111}.appcore-column-manager__icon-btn{display:inline-flex;align-items:center;justify-content:center;padding:.25rem;border:none;border-radius:.25rem;background:transparent;cursor:pointer;color:#3d3d3d;transition:background-color .15s ease;flex-shrink:0}.appcore-column-manager__icon-btn:hover{background-color:#ebebeb}.appcore-column-manager__icon-btn:active{background-color:#ccc}.appcore-column-manager__icon-btn--sm{padding:.125rem}.appcore-column-manager__search{display:flex;align-items:center;gap:.25rem;padding:.5rem .75rem;border-bottom:1px solid rgb(204,204,204);flex-shrink:0}.appcore-column-manager__search-icon{color:#a3a3a3;flex-shrink:0}.appcore-column-manager__search-input{flex:1;border:none;outline:none;font-family:Inter,sans-serif;font-size:14px;line-height:20px;color:#111;background:transparent;min-width:0}.appcore-column-manager__search-input::placeholder{color:#a3a3a3}.appcore-column-manager__select-all{display:flex;align-items:center;justify-content:space-between;padding:.5rem .75rem .5rem .625rem;border-bottom:1px solid rgb(204,204,204);flex-shrink:0}.appcore-column-manager__row-left{display:flex;align-items:center;gap:.25rem;min-width:0;flex:1}.appcore-column-manager__badge{font-size:12px;font-weight:400;color:#a3a3a3;white-space:nowrap;flex-shrink:0}.appcore-column-manager__checkbox{appearance:none;-webkit-appearance:none;width:16px;height:16px;min-width:16px;border:1.5px solid rgb(204,204,204);border-radius:.125rem;background-color:#fff;cursor:pointer;position:relative;transition:border-color .15s ease,background-color .15s ease;flex-shrink:0}.appcore-column-manager__checkbox:checked{background-color:#0c558c;border-color:#0c558c}.appcore-column-manager__checkbox:checked:after{content:\"\";position:absolute;left:4px;top:1.5px;width:5px;height:9px;border:2px solid rgb(255,255,255);border-top:none;border-left:none;transform:rotate(45deg)}.appcore-column-manager__checkbox:indeterminate{background-color:#0c558c;border-color:#0c558c}.appcore-column-manager__checkbox:indeterminate:after{content:\"\";position:absolute;left:3px;top:6px;width:8px;height:2px;background-color:#fff;border-radius:1px}.appcore-column-manager__checkbox:disabled{opacity:.4;cursor:not-allowed}.appcore-column-manager__checkbox:hover:not(:disabled):not(:checked):not(:indeterminate){border-color:#0c558c}.appcore-column-manager__check-label{display:flex;align-items:center;gap:.25rem;cursor:pointer;min-width:0}.appcore-column-manager__label{font-size:14px;font-weight:400;line-height:20px;color:#3d3d3d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.appcore-column-manager__label--bold{font-weight:500;color:#111}.appcore-column-manager__drag-handle{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;color:#a3a3a3;cursor:grab;border-radius:.125rem;transition:color .15s ease,opacity .15s ease}.appcore-column-manager__drag-handle:active{cursor:grabbing}.appcore-column-manager__drag-handle--hidden{opacity:0;pointer-events:none;cursor:default}.appcore-column-manager__drag-handle-spacer{display:inline-flex;width:18px;flex-shrink:0}.appcore-column-manager__groups{flex:1;overflow-y:auto;overflow-x:hidden}.appcore-column-manager__groups::-webkit-scrollbar{width:4px}.appcore-column-manager__groups::-webkit-scrollbar-track{background:transparent}.appcore-column-manager__groups::-webkit-scrollbar-thumb{background-color:#ccc;border-radius:2px}.appcore-column-manager__group{border-bottom:1px solid rgb(204,204,204)}.appcore-column-manager__group:last-child{border-bottom:none}.appcore-column-manager__group.cdk-drag-preview{background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.25rem;box-shadow:0 4px 12px #0000001f;opacity:.95}.appcore-column-manager__group.cdk-drag-animating{transition:transform .2s cubic-bezier(0,0,.2,1)}.appcore-column-manager__group-header{display:flex;align-items:center;justify-content:space-between;padding:.5rem .75rem .5rem .625rem;background-color:#f5f5f5;transition:background-color .15s ease}.appcore-column-manager__group-header:hover{background-color:#ebebeb}.appcore-column-manager__group-toggle{display:inline-flex;align-items:center;gap:.25rem;border:none;background:transparent;cursor:pointer;padding:0;min-width:0;flex:1}.appcore-column-manager__group-label{font-size:14px;font-weight:500;line-height:20px;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}.appcore-column-manager__columns{min-height:4px}.appcore-column-manager__column{display:flex;align-items:center;justify-content:space-between;padding:.5rem .75rem .5rem .625rem;background-color:#fff;transition:background-color .15s ease}.appcore-column-manager__column:hover{background-color:#f5f5f5}.appcore-column-manager__column.cdk-drag-preview{background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.25rem;box-shadow:0 2px 8px #0000001a;opacity:.95;display:flex;align-items:center;justify-content:space-between}.appcore-column-manager__column.cdk-drag-animating{transition:transform .2s cubic-bezier(0,0,.2,1)}.appcore-column-manager__drop-placeholder{background-color:#e7eef3;border:1px dashed rgb(12,85,140);border-radius:.25rem;min-height:36px;margin:.125rem;transition:all .2s ease}.appcore-column-manager__drop-placeholder--column{min-height:32px}.appcore-column-manager__groups.cdk-drop-list-dragging .appcore-column-manager__group:not(.cdk-drag-placeholder){transition:transform .2s cubic-bezier(0,0,.2,1)}.appcore-column-manager__columns.cdk-drop-list-dragging .appcore-column-manager__column:not(.cdk-drag-placeholder){transition:transform .2s cubic-bezier(0,0,.2,1)}.appcore-column-manager__lock-icon{color:#a3a3a3;flex-shrink:0}.appcore-column-manager__footer{display:flex;align-items:center;justify-content:flex-end;gap:.5rem;padding:.625rem 1rem;border-top:1px solid rgb(204,204,204);flex-shrink:0}.appcore-column-manager__btn{display:inline-flex;align-items:center;justify-content:center;padding:.5rem 1rem;border-radius:.5rem;font-family:Inter,sans-serif;font-size:14px;font-weight:500;line-height:20px;cursor:pointer;transition:background-color .15s ease,border-color .15s ease,color .15s ease;white-space:nowrap}.appcore-column-manager__btn--primary{background-color:#0c558c;border:1.5px solid rgb(12,85,140);color:#fff}.appcore-column-manager__btn--primary:hover{background-color:#0c5082;border-color:#0c5082}.appcore-column-manager__btn--primary:active{background-color:#0e3f65;border-color:#0e3f65}.appcore-column-manager__btn--secondary{background-color:transparent;border:1.5px solid rgb(204,204,204);color:#3d3d3d}.appcore-column-manager__btn--secondary:hover{background-color:#f5f5f5;border-color:#7a7a7a}.appcore-column-manager__btn--secondary:active{background-color:#ebebeb}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i2$1.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i2$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i2$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: i2$1.CdkDragPlaceholder, selector: "ng-template[cdkDragPlaceholder]", inputs: ["data"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ColumnManagerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-column-manager', standalone: true, imports: [CommonModule, FormsModule, DragDropModule, IconComponent], template: `
    <div class="appcore-column-manager">

      <!-- Header -->
      <div class="appcore-column-manager__header">
        <span class="appcore-column-manager__title">{{ title }}</span>
        <button
          type="button"
          class="appcore-column-manager__icon-btn"
          (click)="onCancel()"
          aria-label="Close"
        >
          <app-icon icon="close" iconSet="material" size="sm"></app-icon>
        </button>
      </div>

      <!-- Search -->
      @if (searchable) {
        <div class="appcore-column-manager__search">
          <app-icon icon="search" iconSet="material" size="sm" class="appcore-column-manager__search-icon"></app-icon>
          <input
            type="text"
            class="appcore-column-manager__search-input"
            [(ngModel)]="searchQuery"
            placeholder="Search columns..."
            aria-label="Search columns"
          />
          @if (searchQuery) {
            <button
              type="button"
              class="appcore-column-manager__icon-btn appcore-column-manager__icon-btn--sm"
              (click)="searchQuery = ''"
              aria-label="Clear search"
            >
              <app-icon icon="close" iconSet="material" size="sm"></app-icon>
            </button>
          }
        </div>
      }

      <!-- Select All row -->
      @if (!searchQuery) {
        <div class="appcore-column-manager__select-all">
          <div class="appcore-column-manager__row-left">
            <span class="appcore-column-manager__drag-handle-spacer"></span>
            <label class="appcore-column-manager__check-label">
              <input
                type="checkbox"
                class="appcore-column-manager__checkbox"
                [checked]="allVisible"
                [indeterminate]="someVisible && !allVisible"
                (change)="toggleAllColumns($any($event.target).checked)"
              />
              <span class="appcore-column-manager__label appcore-column-manager__label--bold">Select All</span>
            </label>
          </div>
          <span class="appcore-column-manager__badge">{{ visibleCount }}/{{ totalCount }}</span>
        </div>
      }

      <!-- Groups drop list -->
      <div
        class="appcore-column-manager__groups"
        cdkDropList
        [cdkDropListDisabled]="!!searchQuery"
        (cdkDropListDropped)="onGroupDrop($event)"
      >
        @for (group of internalGroups; track group.id; let gi = $index) {
          <!-- Only show group if it has columns matching search -->
          @if (!searchQuery || getFilteredColumns(group).length > 0) {
            <div
              class="appcore-column-manager__group"
              cdkDrag
              [cdkDragDisabled]="group.locked || !!searchQuery"
            >
              <div *cdkDragPlaceholder class="appcore-column-manager__drop-placeholder"></div>

              <!-- Group Header -->
              <div class="appcore-column-manager__group-header">
                <div class="appcore-column-manager__row-left">
                  <span
                    class="appcore-column-manager__drag-handle"
                    [class.appcore-column-manager__drag-handle--hidden]="group.locked || !!searchQuery"
                    cdkDragHandle
                    aria-label="Drag to reorder group"
                  >
                    <app-icon icon="drag_indicator" iconSet="material" size="sm"></app-icon>
                  </span>
                  <input
                    type="checkbox"
                    class="appcore-column-manager__checkbox"
                    [checked]="isGroupAllVisible(group)"
                    [indeterminate]="isGroupSomeVisible(group) && !isGroupAllVisible(group)"
                    (change)="toggleGroup(group, $any($event.target).checked)"
                  />
                  <button
                    type="button"
                    class="appcore-column-manager__group-toggle"
                    (click)="toggleGroupCollapse(group)"
                  >
                    <app-icon
                      [icon]="group.collapsed && !searchQuery ? 'chevron_right' : 'expand_more'"
                      iconSet="material"
                      size="sm"
                    ></app-icon>
                    <span class="appcore-column-manager__group-label">{{ group.label }}</span>
                  </button>
                </div>
                <span class="appcore-column-manager__badge">
                  {{ getGroupVisibleCount(group) }}/{{ group.columns.length }}
                </span>
              </div>

              <!-- Columns drop list -->
              @if (!group.collapsed || !!searchQuery) {
                <div
                  class="appcore-column-manager__columns"
                  cdkDropList
                  [cdkDropListDisabled]="!!searchQuery"
                  (cdkDropListDropped)="onColumnDrop($event, gi)"
                >
                  @for (column of getFilteredColumns(group); track column.id) {
                    <div
                      class="appcore-column-manager__column"
                      cdkDrag
                      [cdkDragDisabled]="column.locked || !!searchQuery"
                    >
                      <div *cdkDragPlaceholder class="appcore-column-manager__drop-placeholder appcore-column-manager__drop-placeholder--column"></div>

                      <div class="appcore-column-manager__row-left">
                        <span
                          class="appcore-column-manager__drag-handle"
                          [class.appcore-column-manager__drag-handle--hidden]="column.locked || !!searchQuery"
                          cdkDragHandle
                          aria-label="Drag to reorder column"
                        >
                          <app-icon icon="drag_indicator" iconSet="material" size="sm"></app-icon>
                        </span>
                        <label class="appcore-column-manager__check-label">
                          <input
                            type="checkbox"
                            class="appcore-column-manager__checkbox"
                            [(ngModel)]="column.visible"
                            [disabled]="!!column.locked"
                            (ngModelChange)="onColumnVisibilityChange()"
                          />
                          <span class="appcore-column-manager__label">{{ column.label }}</span>
                        </label>
                      </div>

                      @if (column.locked) {
                        <app-icon
                          icon="lock"
                          iconSet="material"
                          size="sm"
                          class="appcore-column-manager__lock-icon"
                        ></app-icon>
                      }
                    </div>
                  }
                </div>
              }
            </div>
          }
        }
      </div>

      <!-- Footer -->
      <div class="appcore-column-manager__footer">
        <button
          type="button"
          class="appcore-column-manager__btn appcore-column-manager__btn--secondary"
          (click)="onCancel()"
        >
          Cancel
        </button>
        <button
          type="button"
          class="appcore-column-manager__btn appcore-column-manager__btn--primary"
          (click)="onApply()"
        >
          Apply
        </button>
      </div>
    </div>
  `, styles: [".appcore-column-manager{display:flex;flex-direction:column;width:280px;max-height:600px;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;overflow:hidden;font-family:Inter,sans-serif;box-shadow:0 4px 16px #00000014}.appcore-column-manager__header{display:flex;align-items:center;justify-content:space-between;padding:1rem 1rem .75rem;border-bottom:1px solid rgb(204,204,204);flex-shrink:0}.appcore-column-manager__title{font-size:14px;font-weight:600;line-height:20px;color:#111}.appcore-column-manager__icon-btn{display:inline-flex;align-items:center;justify-content:center;padding:.25rem;border:none;border-radius:.25rem;background:transparent;cursor:pointer;color:#3d3d3d;transition:background-color .15s ease;flex-shrink:0}.appcore-column-manager__icon-btn:hover{background-color:#ebebeb}.appcore-column-manager__icon-btn:active{background-color:#ccc}.appcore-column-manager__icon-btn--sm{padding:.125rem}.appcore-column-manager__search{display:flex;align-items:center;gap:.25rem;padding:.5rem .75rem;border-bottom:1px solid rgb(204,204,204);flex-shrink:0}.appcore-column-manager__search-icon{color:#a3a3a3;flex-shrink:0}.appcore-column-manager__search-input{flex:1;border:none;outline:none;font-family:Inter,sans-serif;font-size:14px;line-height:20px;color:#111;background:transparent;min-width:0}.appcore-column-manager__search-input::placeholder{color:#a3a3a3}.appcore-column-manager__select-all{display:flex;align-items:center;justify-content:space-between;padding:.5rem .75rem .5rem .625rem;border-bottom:1px solid rgb(204,204,204);flex-shrink:0}.appcore-column-manager__row-left{display:flex;align-items:center;gap:.25rem;min-width:0;flex:1}.appcore-column-manager__badge{font-size:12px;font-weight:400;color:#a3a3a3;white-space:nowrap;flex-shrink:0}.appcore-column-manager__checkbox{appearance:none;-webkit-appearance:none;width:16px;height:16px;min-width:16px;border:1.5px solid rgb(204,204,204);border-radius:.125rem;background-color:#fff;cursor:pointer;position:relative;transition:border-color .15s ease,background-color .15s ease;flex-shrink:0}.appcore-column-manager__checkbox:checked{background-color:#0c558c;border-color:#0c558c}.appcore-column-manager__checkbox:checked:after{content:\"\";position:absolute;left:4px;top:1.5px;width:5px;height:9px;border:2px solid rgb(255,255,255);border-top:none;border-left:none;transform:rotate(45deg)}.appcore-column-manager__checkbox:indeterminate{background-color:#0c558c;border-color:#0c558c}.appcore-column-manager__checkbox:indeterminate:after{content:\"\";position:absolute;left:3px;top:6px;width:8px;height:2px;background-color:#fff;border-radius:1px}.appcore-column-manager__checkbox:disabled{opacity:.4;cursor:not-allowed}.appcore-column-manager__checkbox:hover:not(:disabled):not(:checked):not(:indeterminate){border-color:#0c558c}.appcore-column-manager__check-label{display:flex;align-items:center;gap:.25rem;cursor:pointer;min-width:0}.appcore-column-manager__label{font-size:14px;font-weight:400;line-height:20px;color:#3d3d3d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.appcore-column-manager__label--bold{font-weight:500;color:#111}.appcore-column-manager__drag-handle{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;color:#a3a3a3;cursor:grab;border-radius:.125rem;transition:color .15s ease,opacity .15s ease}.appcore-column-manager__drag-handle:active{cursor:grabbing}.appcore-column-manager__drag-handle--hidden{opacity:0;pointer-events:none;cursor:default}.appcore-column-manager__drag-handle-spacer{display:inline-flex;width:18px;flex-shrink:0}.appcore-column-manager__groups{flex:1;overflow-y:auto;overflow-x:hidden}.appcore-column-manager__groups::-webkit-scrollbar{width:4px}.appcore-column-manager__groups::-webkit-scrollbar-track{background:transparent}.appcore-column-manager__groups::-webkit-scrollbar-thumb{background-color:#ccc;border-radius:2px}.appcore-column-manager__group{border-bottom:1px solid rgb(204,204,204)}.appcore-column-manager__group:last-child{border-bottom:none}.appcore-column-manager__group.cdk-drag-preview{background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.25rem;box-shadow:0 4px 12px #0000001f;opacity:.95}.appcore-column-manager__group.cdk-drag-animating{transition:transform .2s cubic-bezier(0,0,.2,1)}.appcore-column-manager__group-header{display:flex;align-items:center;justify-content:space-between;padding:.5rem .75rem .5rem .625rem;background-color:#f5f5f5;transition:background-color .15s ease}.appcore-column-manager__group-header:hover{background-color:#ebebeb}.appcore-column-manager__group-toggle{display:inline-flex;align-items:center;gap:.25rem;border:none;background:transparent;cursor:pointer;padding:0;min-width:0;flex:1}.appcore-column-manager__group-label{font-size:14px;font-weight:500;line-height:20px;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}.appcore-column-manager__columns{min-height:4px}.appcore-column-manager__column{display:flex;align-items:center;justify-content:space-between;padding:.5rem .75rem .5rem .625rem;background-color:#fff;transition:background-color .15s ease}.appcore-column-manager__column:hover{background-color:#f5f5f5}.appcore-column-manager__column.cdk-drag-preview{background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.25rem;box-shadow:0 2px 8px #0000001a;opacity:.95;display:flex;align-items:center;justify-content:space-between}.appcore-column-manager__column.cdk-drag-animating{transition:transform .2s cubic-bezier(0,0,.2,1)}.appcore-column-manager__drop-placeholder{background-color:#e7eef3;border:1px dashed rgb(12,85,140);border-radius:.25rem;min-height:36px;margin:.125rem;transition:all .2s ease}.appcore-column-manager__drop-placeholder--column{min-height:32px}.appcore-column-manager__groups.cdk-drop-list-dragging .appcore-column-manager__group:not(.cdk-drag-placeholder){transition:transform .2s cubic-bezier(0,0,.2,1)}.appcore-column-manager__columns.cdk-drop-list-dragging .appcore-column-manager__column:not(.cdk-drag-placeholder){transition:transform .2s cubic-bezier(0,0,.2,1)}.appcore-column-manager__lock-icon{color:#a3a3a3;flex-shrink:0}.appcore-column-manager__footer{display:flex;align-items:center;justify-content:flex-end;gap:.5rem;padding:.625rem 1rem;border-top:1px solid rgb(204,204,204);flex-shrink:0}.appcore-column-manager__btn{display:inline-flex;align-items:center;justify-content:center;padding:.5rem 1rem;border-radius:.5rem;font-family:Inter,sans-serif;font-size:14px;font-weight:500;line-height:20px;cursor:pointer;transition:background-color .15s ease,border-color .15s ease,color .15s ease;white-space:nowrap}.appcore-column-manager__btn--primary{background-color:#0c558c;border:1.5px solid rgb(12,85,140);color:#fff}.appcore-column-manager__btn--primary:hover{background-color:#0c5082;border-color:#0c5082}.appcore-column-manager__btn--primary:active{background-color:#0e3f65;border-color:#0e3f65}.appcore-column-manager__btn--secondary{background-color:transparent;border:1.5px solid rgb(204,204,204);color:#3d3d3d}.appcore-column-manager__btn--secondary:hover{background-color:#f5f5f5;border-color:#7a7a7a}.appcore-column-manager__btn--secondary:active{background-color:#ebebeb}\n"] }]
        }], propDecorators: { groups: [{
                type: Input
            }], title: [{
                type: Input
            }], searchable: [{
                type: Input
            }], groupsChange: [{
                type: Output
            }], apply: [{
                type: Output
            }], cancel: [{
                type: Output
            }] } });

class ComboboxComponent {
    constructor(elementRef) {
        this.elementRef = elementRef;
        /** List of selectable options. */
        this.options = [];
        /** Currently selected value. */
        this.value = '';
        /** Placeholder shown when nothing is selected. */
        this.placeholder = 'Select an option';
        /** Field label rendered above the control. */
        this.label = '';
        /** Helper text shown below the control in the default state. */
        this.helperText = '';
        /** Error message shown when error=true. */
        this.errorMessage = '';
        /** Visual size of the combobox. */
        this.size = 'md';
        /** Disables all interaction. */
        this.disabled = false;
        /** Shows error styling and errorMessage. */
        this.error = false;
        /** Allows typing to filter options. */
        this.searchable = false;
        /** Emits the new value string when selection changes. */
        this.valueChange = new EventEmitter();
        /** Emits the full option object when selection changes. */
        this.selectionChange = new EventEmitter();
        this.isOpen = false;
        this.searchText = '';
    }
    get selectedOption() {
        return this.options.find((o) => o.value === this.value);
    }
    get filteredOptions() {
        if (!this.searchable || !this.searchText)
            return this.options;
        const query = this.searchText.toLowerCase();
        return this.options.filter((o) => o.label.toLowerCase().includes(query));
    }
    get inputValue() {
        if (this.isOpen && this.searchable)
            return this.searchText;
        return this.selectedOption?.label ?? '';
    }
    onDocumentClick(event) {
        if (!this.elementRef.nativeElement.contains(event.target)) {
            this.close();
        }
    }
    open() {
        if (this.disabled)
            return;
        this.isOpen = true;
        if (this.searchable)
            this.searchText = '';
    }
    close() {
        this.isOpen = false;
        if (this.searchable)
            this.searchText = this.selectedOption?.label ?? '';
    }
    onControlClick() {
        if (!this.isOpen)
            this.open();
    }
    onChevronClick(event) {
        event.stopPropagation();
        this.isOpen ? this.close() : this.open();
    }
    onFocus() {
        if (!this.isOpen)
            this.open();
    }
    onBlur() {
        // mousedown preventDefault on options keeps focus in input, so blur only
        // fires when clicking truly outside – handled by document:click instead.
    }
    onInput(event) {
        this.searchText = event.target.value;
        if (!this.isOpen)
            this.open();
    }
    selectOption(option) {
        if (option.disabled)
            return;
        this.value = option.value;
        this.searchText = option.label;
        this.valueChange.emit(option.value);
        this.selectionChange.emit(option);
        this.close();
    }
    clear(event) {
        event.stopPropagation();
        this.value = '';
        this.searchText = '';
        this.valueChange.emit('');
        this.selectionChange.emit(null);
        this.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ComboboxComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: ComboboxComponent, isStandalone: true, selector: "appcore-combobox", inputs: { options: "options", value: "value", placeholder: "placeholder", label: "label", helperText: "helperText", errorMessage: "errorMessage", size: "size", disabled: "disabled", error: "error", searchable: "searchable" }, outputs: { valueChange: "valueChange", selectionChange: "selectionChange" }, host: { listeners: { "document:click": "onDocumentClick($event)" } }, ngImport: i0, template: `
    <div
      class="appcore-combobox"
      [ngClass]="[
        'appcore-combobox--' + size,
        disabled ? 'appcore-combobox--disabled' : '',
        error ? 'appcore-combobox--error' : '',
        isOpen ? 'appcore-combobox--open' : ''
      ]"
    >
      <!-- Label -->
      <label *ngIf="label" class="appcore-combobox__label">{{ label }}</label>

      <!-- Control -->
      <div class="appcore-combobox__control" (click)="onControlClick()">
        <input
          class="appcore-combobox__input"
          type="text"
          [placeholder]="placeholder"
          [disabled]="disabled"
          [readOnly]="!searchable"
          [value]="inputValue"
          (input)="onInput($event)"
          (focus)="onFocus()"
          (blur)="onBlur()"
          (keydown.escape)="close()"
          autocomplete="off"
          aria-autocomplete="list"
          [attr.aria-expanded]="isOpen"
          role="combobox"
        />

        <!-- Clear button -->
        <button
          *ngIf="value && !disabled"
          class="appcore-combobox__clear"
          type="button"
          (click)="clear($event)"
          (mousedown)="$event.preventDefault()"
          aria-label="Clear selection"
        >
          <app-icon icon="close" size="sm"></app-icon>
        </button>

        <!-- Chevron -->
        <span
          class="appcore-combobox__chevron"
          [class.appcore-combobox__chevron--open]="isOpen"
          (click)="onChevronClick($event)"
          aria-hidden="true"
        >
          <app-icon icon="keyboard_arrow_down" size="sm"></app-icon>
        </span>
      </div>

      <!-- Dropdown -->
      <div *ngIf="isOpen" class="appcore-combobox__dropdown" role="listbox">
        <ul class="appcore-combobox__options">
          <li
            *ngFor="let option of filteredOptions"
            class="appcore-combobox__option"
            [ngClass]="{
              'appcore-combobox__option--selected': option.value === value,
              'appcore-combobox__option--disabled': option.disabled
            }"
            role="option"
            [attr.aria-selected]="option.value === value"
            (click)="selectOption(option)"
            (mousedown)="$event.preventDefault()"
          >
            <span class="appcore-combobox__option-label">{{ option.label }}</span>
            <app-icon
              *ngIf="option.value === value"
              icon="check"
              size="sm"
              class="appcore-combobox__option-check"
            ></app-icon>
          </li>
          <li *ngIf="filteredOptions.length === 0" class="appcore-combobox__option--empty">
            No options found
          </li>
        </ul>
      </div>

      <!-- Helper / Error text -->
      <span *ngIf="error && errorMessage" class="appcore-combobox__error-text">
        {{ errorMessage }}
      </span>
      <span *ngIf="!error && helperText" class="appcore-combobox__helper-text">
        {{ helperText }}
      </span>
    </div>
  `, isInline: true, styles: [".appcore-combobox{display:inline-flex;flex-direction:column;gap:.25rem;font-family:Inter,sans-serif;position:relative;width:100%}.appcore-combobox__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#3d3d3d}.appcore-combobox__control{display:flex;align-items:center;gap:.25rem;padding:0 .625rem;height:40px;border:1px solid rgb(204,204,204);border-radius:.5rem;background-color:#fff;cursor:pointer;transition:border-color .15s ease,box-shadow .15s ease}.appcore-combobox__control:focus-within{border-color:#0c558c;box-shadow:0 0 0 2px #007bff;outline:none}.appcore-combobox--open .appcore-combobox__control{border-color:#0c558c}.appcore-combobox__input{flex:1;min-width:0;border:none;outline:none;background:transparent;font-family:Inter,sans-serif;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;color:#111;cursor:pointer}.appcore-combobox__input[readonly]{cursor:pointer}.appcore-combobox__input::placeholder{color:#a3a3a3;font-weight:400}.appcore-combobox__input:disabled{cursor:not-allowed}.appcore-combobox__clear{display:flex;align-items:center;justify-content:center;padding:0;border:none;background:transparent;cursor:pointer;color:#a3a3a3;flex-shrink:0;line-height:1}.appcore-combobox__clear:hover{color:#111}.appcore-combobox__chevron{display:flex;align-items:center;justify-content:center;color:#525252;flex-shrink:0;transition:transform .2s ease}.appcore-combobox__chevron--open{transform:rotate(180deg)}.appcore-combobox__dropdown{position:absolute;top:calc(100% + 4px);left:0;right:0;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;box-shadow:0 4px 12px #0000001a;z-index:1000;overflow:hidden}.appcore-combobox__options{list-style:none;margin:0;padding:.25rem 0;max-height:240px;overflow-y:auto}.appcore-combobox__option{display:flex;align-items:center;justify-content:space-between;padding:.5rem .625rem;cursor:pointer;transition:background-color .1s ease;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111}.appcore-combobox__option:hover{background-color:#e7eef3}.appcore-combobox__option--selected{background-color:#e7eef3;color:#0c558c;font-weight:500}.appcore-combobox__option--disabled{color:#a3a3a3;cursor:not-allowed;pointer-events:none}.appcore-combobox__option--empty{padding:.5rem .625rem;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#a3a3a3;text-align:center}.appcore-combobox__option-label{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.appcore-combobox__option-check{flex-shrink:0;color:#0c558c}.appcore-combobox__helper-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-combobox__error-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}.appcore-combobox--error .appcore-combobox__control{border-color:#d2222d}.appcore-combobox--error .appcore-combobox__control:focus-within{border-color:#d2222d;box-shadow:0 0 0 2px #d2222d40}.appcore-combobox--disabled .appcore-combobox__label{color:#a3a3a3}.appcore-combobox--disabled .appcore-combobox__control{background-color:#f5f5f5;border-color:#ccc;cursor:not-allowed;pointer-events:none}.appcore-combobox--disabled .appcore-combobox__input{color:#a3a3a3}.appcore-combobox--sm .appcore-combobox__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--sm .appcore-combobox__control{height:32px;padding:0 .5rem}.appcore-combobox--sm .appcore-combobox__input{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--sm .appcore-combobox__option{padding:.25rem .5rem;font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--lg .appcore-combobox__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--lg .appcore-combobox__control{height:48px;padding:0 .75rem}.appcore-combobox--lg .appcore-combobox__input{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--lg .appcore-combobox__option{padding:.625rem .75rem;font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ComboboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-combobox', standalone: true, imports: [CommonModule, IconComponent], template: `
    <div
      class="appcore-combobox"
      [ngClass]="[
        'appcore-combobox--' + size,
        disabled ? 'appcore-combobox--disabled' : '',
        error ? 'appcore-combobox--error' : '',
        isOpen ? 'appcore-combobox--open' : ''
      ]"
    >
      <!-- Label -->
      <label *ngIf="label" class="appcore-combobox__label">{{ label }}</label>

      <!-- Control -->
      <div class="appcore-combobox__control" (click)="onControlClick()">
        <input
          class="appcore-combobox__input"
          type="text"
          [placeholder]="placeholder"
          [disabled]="disabled"
          [readOnly]="!searchable"
          [value]="inputValue"
          (input)="onInput($event)"
          (focus)="onFocus()"
          (blur)="onBlur()"
          (keydown.escape)="close()"
          autocomplete="off"
          aria-autocomplete="list"
          [attr.aria-expanded]="isOpen"
          role="combobox"
        />

        <!-- Clear button -->
        <button
          *ngIf="value && !disabled"
          class="appcore-combobox__clear"
          type="button"
          (click)="clear($event)"
          (mousedown)="$event.preventDefault()"
          aria-label="Clear selection"
        >
          <app-icon icon="close" size="sm"></app-icon>
        </button>

        <!-- Chevron -->
        <span
          class="appcore-combobox__chevron"
          [class.appcore-combobox__chevron--open]="isOpen"
          (click)="onChevronClick($event)"
          aria-hidden="true"
        >
          <app-icon icon="keyboard_arrow_down" size="sm"></app-icon>
        </span>
      </div>

      <!-- Dropdown -->
      <div *ngIf="isOpen" class="appcore-combobox__dropdown" role="listbox">
        <ul class="appcore-combobox__options">
          <li
            *ngFor="let option of filteredOptions"
            class="appcore-combobox__option"
            [ngClass]="{
              'appcore-combobox__option--selected': option.value === value,
              'appcore-combobox__option--disabled': option.disabled
            }"
            role="option"
            [attr.aria-selected]="option.value === value"
            (click)="selectOption(option)"
            (mousedown)="$event.preventDefault()"
          >
            <span class="appcore-combobox__option-label">{{ option.label }}</span>
            <app-icon
              *ngIf="option.value === value"
              icon="check"
              size="sm"
              class="appcore-combobox__option-check"
            ></app-icon>
          </li>
          <li *ngIf="filteredOptions.length === 0" class="appcore-combobox__option--empty">
            No options found
          </li>
        </ul>
      </div>

      <!-- Helper / Error text -->
      <span *ngIf="error && errorMessage" class="appcore-combobox__error-text">
        {{ errorMessage }}
      </span>
      <span *ngIf="!error && helperText" class="appcore-combobox__helper-text">
        {{ helperText }}
      </span>
    </div>
  `, styles: [".appcore-combobox{display:inline-flex;flex-direction:column;gap:.25rem;font-family:Inter,sans-serif;position:relative;width:100%}.appcore-combobox__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#3d3d3d}.appcore-combobox__control{display:flex;align-items:center;gap:.25rem;padding:0 .625rem;height:40px;border:1px solid rgb(204,204,204);border-radius:.5rem;background-color:#fff;cursor:pointer;transition:border-color .15s ease,box-shadow .15s ease}.appcore-combobox__control:focus-within{border-color:#0c558c;box-shadow:0 0 0 2px #007bff;outline:none}.appcore-combobox--open .appcore-combobox__control{border-color:#0c558c}.appcore-combobox__input{flex:1;min-width:0;border:none;outline:none;background:transparent;font-family:Inter,sans-serif;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;color:#111;cursor:pointer}.appcore-combobox__input[readonly]{cursor:pointer}.appcore-combobox__input::placeholder{color:#a3a3a3;font-weight:400}.appcore-combobox__input:disabled{cursor:not-allowed}.appcore-combobox__clear{display:flex;align-items:center;justify-content:center;padding:0;border:none;background:transparent;cursor:pointer;color:#a3a3a3;flex-shrink:0;line-height:1}.appcore-combobox__clear:hover{color:#111}.appcore-combobox__chevron{display:flex;align-items:center;justify-content:center;color:#525252;flex-shrink:0;transition:transform .2s ease}.appcore-combobox__chevron--open{transform:rotate(180deg)}.appcore-combobox__dropdown{position:absolute;top:calc(100% + 4px);left:0;right:0;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;box-shadow:0 4px 12px #0000001a;z-index:1000;overflow:hidden}.appcore-combobox__options{list-style:none;margin:0;padding:.25rem 0;max-height:240px;overflow-y:auto}.appcore-combobox__option{display:flex;align-items:center;justify-content:space-between;padding:.5rem .625rem;cursor:pointer;transition:background-color .1s ease;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111}.appcore-combobox__option:hover{background-color:#e7eef3}.appcore-combobox__option--selected{background-color:#e7eef3;color:#0c558c;font-weight:500}.appcore-combobox__option--disabled{color:#a3a3a3;cursor:not-allowed;pointer-events:none}.appcore-combobox__option--empty{padding:.5rem .625rem;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#a3a3a3;text-align:center}.appcore-combobox__option-label{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.appcore-combobox__option-check{flex-shrink:0;color:#0c558c}.appcore-combobox__helper-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-combobox__error-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}.appcore-combobox--error .appcore-combobox__control{border-color:#d2222d}.appcore-combobox--error .appcore-combobox__control:focus-within{border-color:#d2222d;box-shadow:0 0 0 2px #d2222d40}.appcore-combobox--disabled .appcore-combobox__label{color:#a3a3a3}.appcore-combobox--disabled .appcore-combobox__control{background-color:#f5f5f5;border-color:#ccc;cursor:not-allowed;pointer-events:none}.appcore-combobox--disabled .appcore-combobox__input{color:#a3a3a3}.appcore-combobox--sm .appcore-combobox__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--sm .appcore-combobox__control{height:32px;padding:0 .5rem}.appcore-combobox--sm .appcore-combobox__input{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--sm .appcore-combobox__option{padding:.25rem .5rem;font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--lg .appcore-combobox__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--lg .appcore-combobox__control{height:48px;padding:0 .75rem}.appcore-combobox--lg .appcore-combobox__input{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-combobox--lg .appcore-combobox__option{padding:.625rem .75rem;font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { options: [{
                type: Input
            }], value: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], label: [{
                type: Input
            }], helperText: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], error: [{
                type: Input
            }], searchable: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class DatePickerComponent {
    constructor(elementRef) {
        this.elementRef = elementRef;
        /** Currently selected date. */
        this.value = null;
        /** Field label rendered above the control. */
        this.label = '';
        /** Placeholder shown when no date is selected. */
        this.placeholder = 'Select a date';
        /** Helper text shown below the control in the default state. */
        this.helperText = '';
        /** Error message shown when error=true. */
        this.errorMessage = '';
        /** Visual size of the picker. */
        this.size = 'md';
        /** Disables all interaction. */
        this.disabled = false;
        /** Shows error styling and errorMessage. */
        this.error = false;
        /** Earliest selectable date (inclusive). */
        this.minDate = null;
        /** Latest selectable date (inclusive). */
        this.maxDate = null;
        /** Emits the selected Date (or null when cleared). */
        this.valueChange = new EventEmitter();
        this.weekdays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
        this.isOpen = false;
        this.viewYear = new Date().getFullYear();
        this.viewMonth = new Date().getMonth(); // 0-based
    }
    // ─── Lifecycle ──────────────────────────────────────────────────────────────
    ngOnChanges() {
        if (this.value) {
            this.viewYear = this.value.getFullYear();
            this.viewMonth = this.value.getMonth();
        }
    }
    // ─── Outside-click close ────────────────────────────────────────────────────
    onDocumentClick(event) {
        if (!this.elementRef.nativeElement.contains(event.target)) {
            this.close();
        }
    }
    // ─── Open / close ───────────────────────────────────────────────────────────
    open() {
        if (this.disabled)
            return;
        if (this.value) {
            this.viewYear = this.value.getFullYear();
            this.viewMonth = this.value.getMonth();
        }
        this.isOpen = true;
    }
    close() {
        this.isOpen = false;
    }
    onControlClick() {
        this.isOpen ? this.close() : this.open();
    }
    // ─── Navigation ─────────────────────────────────────────────────────────────
    prevMonth() {
        if (this.viewMonth === 0) {
            this.viewMonth = 11;
            this.viewYear--;
        }
        else {
            this.viewMonth--;
        }
    }
    nextMonth() {
        if (this.viewMonth === 11) {
            this.viewMonth = 0;
            this.viewYear++;
        }
        else {
            this.viewMonth++;
        }
    }
    // ─── Day selection ──────────────────────────────────────────────────────────
    selectDay(cell) {
        if (cell.isDisabled)
            return;
        this.value = cell.date;
        this.valueChange.emit(cell.date);
        this.close();
    }
    clear(event) {
        event.stopPropagation();
        this.value = null;
        this.valueChange.emit(null);
    }
    // ─── Computed properties ────────────────────────────────────────────────────
    get monthYearLabel() {
        return new Date(this.viewYear, this.viewMonth, 1).toLocaleDateString('en-US', {
            month: 'long',
            year: 'numeric',
        });
    }
    get calendarCells() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const firstOfMonth = new Date(this.viewYear, this.viewMonth, 1);
        const startOffset = firstOfMonth.getDay(); // 0 = Sunday
        const daysInMonth = new Date(this.viewYear, this.viewMonth + 1, 0).getDate();
        const cells = [];
        // Leading days from previous month
        const prevMonthDays = new Date(this.viewYear, this.viewMonth, 0).getDate();
        for (let i = startOffset - 1; i >= 0; i--) {
            const date = new Date(this.viewYear, this.viewMonth - 1, prevMonthDays - i);
            cells.push(this.buildCell(date, false, today));
        }
        // Days in current month
        for (let d = 1; d <= daysInMonth; d++) {
            const date = new Date(this.viewYear, this.viewMonth, d);
            cells.push(this.buildCell(date, true, today));
        }
        // Trailing days to fill last row (always show 6 rows = 42 cells)
        const remaining = 42 - cells.length;
        for (let d = 1; d <= remaining; d++) {
            const date = new Date(this.viewYear, this.viewMonth + 1, d);
            cells.push(this.buildCell(date, false, today));
        }
        return cells;
    }
    buildCell(date, inMonth, today) {
        const d = new Date(date);
        d.setHours(0, 0, 0, 0);
        const isToday = d.getTime() === today.getTime();
        const isSelected = this.value !== null &&
            (() => {
                const v = new Date(this.value);
                v.setHours(0, 0, 0, 0);
                return v.getTime() === d.getTime();
            })();
        let isDisabled = false;
        if (this.minDate) {
            const min = new Date(this.minDate);
            min.setHours(0, 0, 0, 0);
            if (d < min)
                isDisabled = true;
        }
        if (this.maxDate) {
            const max = new Date(this.maxDate);
            max.setHours(0, 0, 0, 0);
            if (d > max)
                isDisabled = true;
        }
        return { date, inMonth, isToday, isSelected, isDisabled };
    }
    formatDate(date) {
        return date.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DatePickerComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: DatePickerComponent, isStandalone: true, selector: "appcore-datepicker", inputs: { value: "value", label: "label", placeholder: "placeholder", helperText: "helperText", errorMessage: "errorMessage", size: "size", disabled: "disabled", error: "error", minDate: "minDate", maxDate: "maxDate" }, outputs: { valueChange: "valueChange" }, host: { listeners: { "document:click": "onDocumentClick($event)" } }, usesOnChanges: true, ngImport: i0, template: `
    <div
      class="appcore-datepicker"
      [ngClass]="[
        'appcore-datepicker--' + size,
        disabled ? 'appcore-datepicker--disabled' : '',
        error ? 'appcore-datepicker--error' : '',
        isOpen ? 'appcore-datepicker--open' : ''
      ]"
    >
      <!-- Label -->
      <label *ngIf="label" class="appcore-datepicker__label">{{ label }}</label>

      <!-- Trigger control -->
      <div class="appcore-datepicker__control" (click)="onControlClick()">
        <span
          class="appcore-datepicker__value"
          [class.appcore-datepicker__value--placeholder]="!value"
        >
          {{ value ? formatDate(value) : placeholder }}
        </span>

        <!-- Clear button -->
        <button
          *ngIf="value && !disabled"
          class="appcore-datepicker__clear"
          type="button"
          (click)="clear($event)"
          (mousedown)="$event.preventDefault()"
          aria-label="Clear date"
        >
          <app-icon icon="close" size="sm"></app-icon>
        </button>

        <!-- Calendar icon -->
        <span class="appcore-datepicker__icon" aria-hidden="true">
          <app-icon icon="calendar_today" size="sm"></app-icon>
        </span>
      </div>

      <!-- Calendar dropdown -->
      <div *ngIf="isOpen" class="appcore-datepicker__calendar" role="dialog" aria-label="Date picker">

        <!-- Calendar header -->
        <div class="appcore-datepicker__cal-header">
          <button
            class="appcore-datepicker__nav-btn"
            type="button"
            (click)="prevMonth()"
            (mousedown)="$event.preventDefault()"
            aria-label="Previous month"
          >
            <app-icon icon="chevron_left" size="sm"></app-icon>
          </button>

          <span class="appcore-datepicker__cal-title">
            {{ monthYearLabel }}
          </span>

          <button
            class="appcore-datepicker__nav-btn"
            type="button"
            (click)="nextMonth()"
            (mousedown)="$event.preventDefault()"
            aria-label="Next month"
          >
            <app-icon icon="chevron_right" size="sm"></app-icon>
          </button>
        </div>

        <!-- Weekday headers -->
        <div class="appcore-datepicker__weekdays">
          <span *ngFor="let day of weekdays" class="appcore-datepicker__weekday">{{ day }}</span>
        </div>

        <!-- Day grid -->
        <div class="appcore-datepicker__days">
          <button
            *ngFor="let cell of calendarCells"
            class="appcore-datepicker__day"
            type="button"
            [ngClass]="{
              'appcore-datepicker__day--outside': !cell.inMonth,
              'appcore-datepicker__day--today': cell.isToday,
              'appcore-datepicker__day--selected': cell.isSelected,
              'appcore-datepicker__day--disabled': cell.isDisabled
            }"
            [disabled]="cell.isDisabled"
            (click)="selectDay(cell)"
            (mousedown)="$event.preventDefault()"
            [attr.aria-label]="cell.date | date:'longDate'"
            [attr.aria-selected]="cell.isSelected"
            [attr.aria-current]="cell.isToday ? 'date' : null"
          >
            {{ cell.date.getDate() }}
          </button>
        </div>
      </div>

      <!-- Helper / Error text -->
      <span *ngIf="error && errorMessage" class="appcore-datepicker__error-text">
        {{ errorMessage }}
      </span>
      <span *ngIf="!error && helperText" class="appcore-datepicker__helper-text">
        {{ helperText }}
      </span>
    </div>
  `, isInline: true, styles: [".appcore-datepicker{display:inline-flex;flex-direction:column;gap:.25rem;font-family:Inter,sans-serif;position:relative;width:100%}.appcore-datepicker__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#3d3d3d}.appcore-datepicker__control{display:flex;align-items:center;gap:.25rem;padding:0 .625rem;height:40px;border:1px solid rgb(204,204,204);border-radius:.5rem;background-color:#fff;cursor:pointer;transition:border-color .15s ease,box-shadow .15s ease}.appcore-datepicker__control:focus-within{border-color:#0c558c;box-shadow:0 0 0 2px #007bff;outline:none}.appcore-datepicker--open .appcore-datepicker__control{border-color:#0c558c}.appcore-datepicker__value{flex:1;min-width:0;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;user-select:none}.appcore-datepicker__value--placeholder{color:#a3a3a3;font-weight:400}.appcore-datepicker__clear{display:flex;align-items:center;justify-content:center;padding:0;border:none;background:transparent;cursor:pointer;color:#a3a3a3;flex-shrink:0;line-height:1}.appcore-datepicker__clear:hover{color:#111}.appcore-datepicker__icon{display:flex;align-items:center;justify-content:center;color:#525252;flex-shrink:0;pointer-events:none}.appcore-datepicker__calendar{position:absolute;top:calc(100% + 4px);left:0;width:280px;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;box-shadow:0 4px 12px #0000001a;z-index:1000;padding:.625rem}.appcore-datepicker__cal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:.5rem}.appcore-datepicker__cal-title{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111;flex:1;text-align:center}.appcore-datepicker__nav-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;color:#525252;transition:background-color .1s ease,color .1s ease;flex-shrink:0}.appcore-datepicker__nav-btn:hover{background-color:#e7eef3;color:#0c558c}.appcore-datepicker__nav-btn:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-datepicker__weekdays{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-bottom:.125rem}.appcore-datepicker__weekday{font-size:12px;line-height:18px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#a3a3a3;text-align:center;padding:.125rem 0}.appcore-datepicker__days{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}.appcore-datepicker__day{display:flex;align-items:center;justify-content:center;width:100%;aspect-ratio:1;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;transition:background-color .1s ease,color .1s ease}.appcore-datepicker__day:hover:not(:disabled){background-color:#e7eef3;color:#0c558c}.appcore-datepicker__day:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-datepicker__day--outside{color:#a3a3a3}.appcore-datepicker__day--today:not(.appcore-datepicker__day--selected){color:#0c558c;font-weight:500;position:relative}.appcore-datepicker__day--today:not(.appcore-datepicker__day--selected):after{content:\"\";position:absolute;bottom:3px;left:50%;transform:translate(-50%);width:4px;height:4px;border-radius:50%;background-color:#0c558c}.appcore-datepicker__day--selected{background-color:#0c558c;color:#fff;font-weight:500}.appcore-datepicker__day--selected:hover{background-color:#0c5082}.appcore-datepicker__day--disabled{color:#a3a3a3;cursor:not-allowed;pointer-events:none}.appcore-datepicker__helper-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-datepicker__error-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}.appcore-datepicker--error .appcore-datepicker__control{border-color:#d2222d}.appcore-datepicker--error .appcore-datepicker__control:focus-within{border-color:#d2222d;box-shadow:0 0 0 2px #d2222d40}.appcore-datepicker--disabled .appcore-datepicker__label{color:#a3a3a3}.appcore-datepicker--disabled .appcore-datepicker__control{background-color:#f5f5f5;border-color:#ccc;cursor:not-allowed;pointer-events:none}.appcore-datepicker--disabled .appcore-datepicker__value{color:#a3a3a3}.appcore-datepicker--sm .appcore-datepicker__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-datepicker--sm .appcore-datepicker__control{height:32px;padding:0 .5rem}.appcore-datepicker--sm .appcore-datepicker__value{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-datepicker--lg .appcore-datepicker__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-datepicker--lg .appcore-datepicker__control{height:48px;padding:0 .75rem}.appcore-datepicker--lg .appcore-datepicker__value{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.DatePipe, name: "date" }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-datepicker', standalone: true, imports: [CommonModule, IconComponent], template: `
    <div
      class="appcore-datepicker"
      [ngClass]="[
        'appcore-datepicker--' + size,
        disabled ? 'appcore-datepicker--disabled' : '',
        error ? 'appcore-datepicker--error' : '',
        isOpen ? 'appcore-datepicker--open' : ''
      ]"
    >
      <!-- Label -->
      <label *ngIf="label" class="appcore-datepicker__label">{{ label }}</label>

      <!-- Trigger control -->
      <div class="appcore-datepicker__control" (click)="onControlClick()">
        <span
          class="appcore-datepicker__value"
          [class.appcore-datepicker__value--placeholder]="!value"
        >
          {{ value ? formatDate(value) : placeholder }}
        </span>

        <!-- Clear button -->
        <button
          *ngIf="value && !disabled"
          class="appcore-datepicker__clear"
          type="button"
          (click)="clear($event)"
          (mousedown)="$event.preventDefault()"
          aria-label="Clear date"
        >
          <app-icon icon="close" size="sm"></app-icon>
        </button>

        <!-- Calendar icon -->
        <span class="appcore-datepicker__icon" aria-hidden="true">
          <app-icon icon="calendar_today" size="sm"></app-icon>
        </span>
      </div>

      <!-- Calendar dropdown -->
      <div *ngIf="isOpen" class="appcore-datepicker__calendar" role="dialog" aria-label="Date picker">

        <!-- Calendar header -->
        <div class="appcore-datepicker__cal-header">
          <button
            class="appcore-datepicker__nav-btn"
            type="button"
            (click)="prevMonth()"
            (mousedown)="$event.preventDefault()"
            aria-label="Previous month"
          >
            <app-icon icon="chevron_left" size="sm"></app-icon>
          </button>

          <span class="appcore-datepicker__cal-title">
            {{ monthYearLabel }}
          </span>

          <button
            class="appcore-datepicker__nav-btn"
            type="button"
            (click)="nextMonth()"
            (mousedown)="$event.preventDefault()"
            aria-label="Next month"
          >
            <app-icon icon="chevron_right" size="sm"></app-icon>
          </button>
        </div>

        <!-- Weekday headers -->
        <div class="appcore-datepicker__weekdays">
          <span *ngFor="let day of weekdays" class="appcore-datepicker__weekday">{{ day }}</span>
        </div>

        <!-- Day grid -->
        <div class="appcore-datepicker__days">
          <button
            *ngFor="let cell of calendarCells"
            class="appcore-datepicker__day"
            type="button"
            [ngClass]="{
              'appcore-datepicker__day--outside': !cell.inMonth,
              'appcore-datepicker__day--today': cell.isToday,
              'appcore-datepicker__day--selected': cell.isSelected,
              'appcore-datepicker__day--disabled': cell.isDisabled
            }"
            [disabled]="cell.isDisabled"
            (click)="selectDay(cell)"
            (mousedown)="$event.preventDefault()"
            [attr.aria-label]="cell.date | date:'longDate'"
            [attr.aria-selected]="cell.isSelected"
            [attr.aria-current]="cell.isToday ? 'date' : null"
          >
            {{ cell.date.getDate() }}
          </button>
        </div>
      </div>

      <!-- Helper / Error text -->
      <span *ngIf="error && errorMessage" class="appcore-datepicker__error-text">
        {{ errorMessage }}
      </span>
      <span *ngIf="!error && helperText" class="appcore-datepicker__helper-text">
        {{ helperText }}
      </span>
    </div>
  `, styles: [".appcore-datepicker{display:inline-flex;flex-direction:column;gap:.25rem;font-family:Inter,sans-serif;position:relative;width:100%}.appcore-datepicker__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#3d3d3d}.appcore-datepicker__control{display:flex;align-items:center;gap:.25rem;padding:0 .625rem;height:40px;border:1px solid rgb(204,204,204);border-radius:.5rem;background-color:#fff;cursor:pointer;transition:border-color .15s ease,box-shadow .15s ease}.appcore-datepicker__control:focus-within{border-color:#0c558c;box-shadow:0 0 0 2px #007bff;outline:none}.appcore-datepicker--open .appcore-datepicker__control{border-color:#0c558c}.appcore-datepicker__value{flex:1;min-width:0;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;user-select:none}.appcore-datepicker__value--placeholder{color:#a3a3a3;font-weight:400}.appcore-datepicker__clear{display:flex;align-items:center;justify-content:center;padding:0;border:none;background:transparent;cursor:pointer;color:#a3a3a3;flex-shrink:0;line-height:1}.appcore-datepicker__clear:hover{color:#111}.appcore-datepicker__icon{display:flex;align-items:center;justify-content:center;color:#525252;flex-shrink:0;pointer-events:none}.appcore-datepicker__calendar{position:absolute;top:calc(100% + 4px);left:0;width:280px;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;box-shadow:0 4px 12px #0000001a;z-index:1000;padding:.625rem}.appcore-datepicker__cal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:.5rem}.appcore-datepicker__cal-title{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111;flex:1;text-align:center}.appcore-datepicker__nav-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;color:#525252;transition:background-color .1s ease,color .1s ease;flex-shrink:0}.appcore-datepicker__nav-btn:hover{background-color:#e7eef3;color:#0c558c}.appcore-datepicker__nav-btn:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-datepicker__weekdays{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-bottom:.125rem}.appcore-datepicker__weekday{font-size:12px;line-height:18px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#a3a3a3;text-align:center;padding:.125rem 0}.appcore-datepicker__days{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}.appcore-datepicker__day{display:flex;align-items:center;justify-content:center;width:100%;aspect-ratio:1;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;transition:background-color .1s ease,color .1s ease}.appcore-datepicker__day:hover:not(:disabled){background-color:#e7eef3;color:#0c558c}.appcore-datepicker__day:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-datepicker__day--outside{color:#a3a3a3}.appcore-datepicker__day--today:not(.appcore-datepicker__day--selected){color:#0c558c;font-weight:500;position:relative}.appcore-datepicker__day--today:not(.appcore-datepicker__day--selected):after{content:\"\";position:absolute;bottom:3px;left:50%;transform:translate(-50%);width:4px;height:4px;border-radius:50%;background-color:#0c558c}.appcore-datepicker__day--selected{background-color:#0c558c;color:#fff;font-weight:500}.appcore-datepicker__day--selected:hover{background-color:#0c5082}.appcore-datepicker__day--disabled{color:#a3a3a3;cursor:not-allowed;pointer-events:none}.appcore-datepicker__helper-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-datepicker__error-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}.appcore-datepicker--error .appcore-datepicker__control{border-color:#d2222d}.appcore-datepicker--error .appcore-datepicker__control:focus-within{border-color:#d2222d;box-shadow:0 0 0 2px #d2222d40}.appcore-datepicker--disabled .appcore-datepicker__label{color:#a3a3a3}.appcore-datepicker--disabled .appcore-datepicker__control{background-color:#f5f5f5;border-color:#ccc;cursor:not-allowed;pointer-events:none}.appcore-datepicker--disabled .appcore-datepicker__value{color:#a3a3a3}.appcore-datepicker--sm .appcore-datepicker__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-datepicker--sm .appcore-datepicker__control{height:32px;padding:0 .5rem}.appcore-datepicker--sm .appcore-datepicker__value{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-datepicker--lg .appcore-datepicker__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-datepicker--lg .appcore-datepicker__control{height:48px;padding:0 .75rem}.appcore-datepicker--lg .appcore-datepicker__value{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { value: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], helperText: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], error: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class DateRangePickerComponent {
    constructor(elementRef) {
        this.elementRef = elementRef;
        /** Currently selected date range. */
        this.value = null;
        /** Field label rendered above the control. */
        this.label = '';
        /** Placeholder shown when no range is selected. */
        this.placeholder = 'Select date range';
        /** Helper text shown below the control in the default state. */
        this.helperText = '';
        /** Error message shown when error=true. */
        this.errorMessage = '';
        /** Visual size of the picker. */
        this.size = 'md';
        /** Disables all interaction. */
        this.disabled = false;
        /** Shows error styling and errorMessage. */
        this.error = false;
        /** Earliest selectable date (inclusive). */
        this.minDate = null;
        /** Latest selectable date (inclusive). */
        this.maxDate = null;
        /** Emits the completed DateRange (or null when cleared). */
        this.valueChange = new EventEmitter();
        this.weekdays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
        this.isOpen = false;
        this.leftViewYear = new Date().getFullYear();
        this.leftViewMonth = new Date().getMonth();
        /** Pending start date — set on first click, waiting for the end click. */
        this.pendingStart = null;
        /** Currently hovered date used for range preview during selection. */
        this.hoverDate = null;
    }
    // ─── Lifecycle ──────────────────────────────────────────────────────────────
    ngOnChanges() {
        if (this.value?.start) {
            this.leftViewYear = this.value.start.getFullYear();
            this.leftViewMonth = this.value.start.getMonth();
            // Ensure both months are not the same when value is set
            if (this.leftViewMonth === this.rightViewMonth &&
                this.leftViewYear === this.rightViewYear) {
                // This won't happen as rightView is always leftView + 1 month
            }
        }
    }
    // ─── Outside-click close ────────────────────────────────────────────────────
    onDocumentClick(event) {
        if (!this.elementRef.nativeElement.contains(event.target)) {
            this.cancelPending();
            this.close();
        }
    }
    // ─── Open / close ───────────────────────────────────────────────────────────
    open() {
        if (this.disabled)
            return;
        if (this.value?.start) {
            this.leftViewYear = this.value.start.getFullYear();
            this.leftViewMonth = this.value.start.getMonth();
        }
        this.isOpen = true;
    }
    close() {
        this.isOpen = false;
    }
    onControlClick() {
        this.isOpen ? this.close() : this.open();
    }
    cancelPending() {
        this.pendingStart = null;
        this.hoverDate = null;
    }
    // ─── Navigation ─────────────────────────────────────────────────────────────
    prevMonth() {
        if (this.leftViewMonth === 0) {
            this.leftViewMonth = 11;
            this.leftViewYear--;
        }
        else {
            this.leftViewMonth--;
        }
    }
    nextMonth() {
        if (this.leftViewMonth === 11) {
            this.leftViewMonth = 0;
            this.leftViewYear++;
        }
        else {
            this.leftViewMonth++;
        }
    }
    // ─── Right calendar derived month/year ──────────────────────────────────────
    get rightViewMonth() {
        return this.leftViewMonth === 11 ? 0 : this.leftViewMonth + 1;
    }
    get rightViewYear() {
        return this.leftViewMonth === 11 ? this.leftViewYear + 1 : this.leftViewYear;
    }
    // ─── Day selection ──────────────────────────────────────────────────────────
    selectDay(cell) {
        if (cell.isDisabled)
            return;
        const date = new Date(cell.date);
        date.setHours(0, 0, 0, 0);
        if (!this.pendingStart) {
            // First click — set start and wait for end
            this.pendingStart = date;
        }
        else {
            // Second click — commit the range
            let start = this.pendingStart;
            let end = date;
            if (start > end) {
                [start, end] = [end, start];
            }
            this.value = { start, end };
            this.pendingStart = null;
            this.hoverDate = null;
            this.valueChange.emit(this.value);
            this.close();
        }
    }
    onDayHover(cell) {
        if (this.pendingStart && !cell.isDisabled) {
            this.hoverDate = new Date(cell.date);
            this.hoverDate.setHours(0, 0, 0, 0);
        }
    }
    onDayLeave() {
        if (this.pendingStart) {
            this.hoverDate = null;
        }
    }
    clear(event) {
        event.stopPropagation();
        this.value = null;
        this.pendingStart = null;
        this.hoverDate = null;
        this.valueChange.emit(null);
    }
    // ─── Computed properties ────────────────────────────────────────────────────
    get hasValue() {
        return !!(this.value?.start && this.value?.end);
    }
    get hasDisplayValue() {
        return !!(this.value?.start || this.pendingStart);
    }
    get displayValue() {
        if (this.value?.start && this.value?.end) {
            return `${this.formatDate(this.value.start)} – ${this.formatDate(this.value.end)}`;
        }
        if (this.pendingStart) {
            return `${this.formatDate(this.pendingStart)} – ...`;
        }
        return this.placeholder;
    }
    get leftMonthYearLabel() {
        return new Date(this.leftViewYear, this.leftViewMonth, 1).toLocaleDateString('en-US', {
            month: 'long',
            year: 'numeric',
        });
    }
    get rightMonthYearLabel() {
        return new Date(this.rightViewYear, this.rightViewMonth, 1).toLocaleDateString('en-US', {
            month: 'long',
            year: 'numeric',
        });
    }
    get leftCalendarCells() {
        return this.buildCalendarCells(this.leftViewYear, this.leftViewMonth);
    }
    get rightCalendarCells() {
        return this.buildCalendarCells(this.rightViewYear, this.rightViewMonth);
    }
    buildCalendarCells(year, month) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const firstOfMonth = new Date(year, month, 1);
        const startOffset = firstOfMonth.getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const prevMonthDays = new Date(year, month, 0).getDate();
        const cells = [];
        for (let i = startOffset - 1; i >= 0; i--) {
            const date = new Date(year, month - 1, prevMonthDays - i);
            cells.push(this.buildCell(date, false, today));
        }
        for (let d = 1; d <= daysInMonth; d++) {
            const date = new Date(year, month, d);
            cells.push(this.buildCell(date, true, today));
        }
        const remaining = 42 - cells.length;
        for (let d = 1; d <= remaining; d++) {
            const date = new Date(year, month + 1, d);
            cells.push(this.buildCell(date, false, today));
        }
        return cells;
    }
    buildCell(date, inMonth, today) {
        const d = new Date(date);
        d.setHours(0, 0, 0, 0);
        const isToday = d.getTime() === today.getTime();
        let isDisabled = false;
        if (this.minDate) {
            const min = new Date(this.minDate);
            min.setHours(0, 0, 0, 0);
            if (d < min)
                isDisabled = true;
        }
        if (this.maxDate) {
            const max = new Date(this.maxDate);
            max.setHours(0, 0, 0, 0);
            if (d > max)
                isDisabled = true;
        }
        // Determine range boundaries — either committed value or pending preview
        let rangeStart = null;
        let rangeEnd = null;
        if (this.pendingStart) {
            const anchor = this.pendingStart;
            const hover = this.hoverDate ?? anchor;
            rangeStart = anchor <= hover ? anchor : hover;
            rangeEnd = anchor <= hover ? hover : anchor;
        }
        else if (this.value?.start && this.value?.end) {
            rangeStart = new Date(this.value.start);
            rangeStart.setHours(0, 0, 0, 0);
            rangeEnd = new Date(this.value.end);
            rangeEnd.setHours(0, 0, 0, 0);
        }
        const isRangeStart = rangeStart !== null && d.getTime() === rangeStart.getTime();
        const isRangeEnd = rangeEnd !== null && d.getTime() === rangeEnd.getTime();
        const isInRange = rangeStart !== null &&
            rangeEnd !== null &&
            d > rangeStart &&
            d < rangeEnd;
        return { date, inMonth, isToday, isDisabled, isRangeStart, isRangeEnd, isInRange };
    }
    formatDate(date) {
        return date.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DateRangePickerComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: DateRangePickerComponent, isStandalone: true, selector: "appcore-daterangepicker", inputs: { value: "value", label: "label", placeholder: "placeholder", helperText: "helperText", errorMessage: "errorMessage", size: "size", disabled: "disabled", error: "error", minDate: "minDate", maxDate: "maxDate" }, outputs: { valueChange: "valueChange" }, host: { listeners: { "document:click": "onDocumentClick($event)" } }, usesOnChanges: true, ngImport: i0, template: `
    <div
      class="appcore-daterangepicker"
      [ngClass]="[
        'appcore-daterangepicker--' + size,
        disabled ? 'appcore-daterangepicker--disabled' : '',
        error ? 'appcore-daterangepicker--error' : '',
        isOpen ? 'appcore-daterangepicker--open' : ''
      ]"
    >
      <!-- Label -->
      <label *ngIf="label" class="appcore-daterangepicker__label">{{ label }}</label>

      <!-- Trigger control -->
      <div class="appcore-daterangepicker__control" (click)="onControlClick()">
        <span class="appcore-daterangepicker__icon" aria-hidden="true">
          <app-icon icon="calendar_today" size="sm"></app-icon>
        </span>

        <span
          class="appcore-daterangepicker__value"
          [class.appcore-daterangepicker__value--placeholder]="!hasDisplayValue"
        >
          {{ displayValue }}
        </span>

        <!-- Clear button -->
        <button
          *ngIf="hasValue && !disabled"
          class="appcore-daterangepicker__clear"
          type="button"
          (click)="clear($event)"
          (mousedown)="$event.preventDefault()"
          aria-label="Clear date range"
        >
          <app-icon icon="close" size="sm"></app-icon>
        </button>
      </div>

      <!-- Calendar panel -->
      <div
        *ngIf="isOpen"
        class="appcore-daterangepicker__panel"
        role="dialog"
        aria-label="Date range picker"
      >
        <div class="appcore-daterangepicker__calendars">

          <!-- Left calendar -->
          <div class="appcore-daterangepicker__calendar">
            <div class="appcore-daterangepicker__cal-header">
              <button
                class="appcore-daterangepicker__nav-btn"
                type="button"
                (click)="prevMonth()"
                (mousedown)="$event.preventDefault()"
                aria-label="Previous month"
              >
                <app-icon icon="chevron_left" size="sm"></app-icon>
              </button>
              <span class="appcore-daterangepicker__cal-title">{{ leftMonthYearLabel }}</span>
              <span class="appcore-daterangepicker__nav-spacer"></span>
            </div>

            <div class="appcore-daterangepicker__weekdays">
              <span *ngFor="let day of weekdays" class="appcore-daterangepicker__weekday">{{ day }}</span>
            </div>

            <div class="appcore-daterangepicker__days">
              <button
                *ngFor="let cell of leftCalendarCells"
                class="appcore-daterangepicker__day"
                type="button"
                [ngClass]="{
                  'appcore-daterangepicker__day--outside': !cell.inMonth,
                  'appcore-daterangepicker__day--today': cell.isToday,
                  'appcore-daterangepicker__day--disabled': cell.isDisabled,
                  'appcore-daterangepicker__day--range-start': cell.isRangeStart,
                  'appcore-daterangepicker__day--range-end': cell.isRangeEnd,
                  'appcore-daterangepicker__day--in-range': cell.isInRange
                }"
                [disabled]="cell.isDisabled"
                (click)="selectDay(cell)"
                (mouseenter)="onDayHover(cell)"
                (mouseleave)="onDayLeave()"
                (mousedown)="$event.preventDefault()"
                [attr.aria-label]="cell.date | date:'longDate'"
                [attr.aria-selected]="cell.isRangeStart || cell.isRangeEnd"
                [attr.aria-current]="cell.isToday ? 'date' : null"
              >
                {{ cell.date.getDate() }}
              </button>
            </div>
          </div>

          <div class="appcore-daterangepicker__divider"></div>

          <!-- Right calendar -->
          <div class="appcore-daterangepicker__calendar">
            <div class="appcore-daterangepicker__cal-header">
              <span class="appcore-daterangepicker__nav-spacer"></span>
              <span class="appcore-daterangepicker__cal-title">{{ rightMonthYearLabel }}</span>
              <button
                class="appcore-daterangepicker__nav-btn"
                type="button"
                (click)="nextMonth()"
                (mousedown)="$event.preventDefault()"
                aria-label="Next month"
              >
                <app-icon icon="chevron_right" size="sm"></app-icon>
              </button>
            </div>

            <div class="appcore-daterangepicker__weekdays">
              <span *ngFor="let day of weekdays" class="appcore-daterangepicker__weekday">{{ day }}</span>
            </div>

            <div class="appcore-daterangepicker__days">
              <button
                *ngFor="let cell of rightCalendarCells"
                class="appcore-daterangepicker__day"
                type="button"
                [ngClass]="{
                  'appcore-daterangepicker__day--outside': !cell.inMonth,
                  'appcore-daterangepicker__day--today': cell.isToday,
                  'appcore-daterangepicker__day--disabled': cell.isDisabled,
                  'appcore-daterangepicker__day--range-start': cell.isRangeStart,
                  'appcore-daterangepicker__day--range-end': cell.isRangeEnd,
                  'appcore-daterangepicker__day--in-range': cell.isInRange
                }"
                [disabled]="cell.isDisabled"
                (click)="selectDay(cell)"
                (mouseenter)="onDayHover(cell)"
                (mouseleave)="onDayLeave()"
                (mousedown)="$event.preventDefault()"
                [attr.aria-label]="cell.date | date:'longDate'"
                [attr.aria-selected]="cell.isRangeStart || cell.isRangeEnd"
                [attr.aria-current]="cell.isToday ? 'date' : null"
              >
                {{ cell.date.getDate() }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Helper / Error text -->
      <span *ngIf="error && errorMessage" class="appcore-daterangepicker__error-text">
        {{ errorMessage }}
      </span>
      <span *ngIf="!error && helperText" class="appcore-daterangepicker__helper-text">
        {{ helperText }}
      </span>
    </div>
  `, isInline: true, styles: [".appcore-daterangepicker{display:inline-flex;flex-direction:column;gap:.25rem;font-family:Inter,sans-serif;position:relative;width:100%}.appcore-daterangepicker__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#3d3d3d}.appcore-daterangepicker__control{display:flex;align-items:center;gap:.25rem;padding:0 .625rem;height:40px;border:1px solid rgb(204,204,204);border-radius:.5rem;background-color:#fff;cursor:pointer;transition:border-color .15s ease,box-shadow .15s ease}.appcore-daterangepicker__control:focus-within{border-color:#0c558c;box-shadow:0 0 0 2px #007bff;outline:none}.appcore-daterangepicker--open .appcore-daterangepicker__control{border-color:#0c558c}.appcore-daterangepicker__icon{display:flex;align-items:center;justify-content:center;color:#525252;flex-shrink:0;pointer-events:none}.appcore-daterangepicker__value{flex:1;min-width:0;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;user-select:none}.appcore-daterangepicker__value--placeholder{color:#a3a3a3;font-weight:400}.appcore-daterangepicker__clear{display:flex;align-items:center;justify-content:center;padding:0;border:none;background:transparent;cursor:pointer;color:#a3a3a3;flex-shrink:0;line-height:1}.appcore-daterangepicker__clear:hover{color:#111}.appcore-daterangepicker__panel{position:absolute;top:calc(100% + 4px);left:0;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;box-shadow:0 4px 12px #0000001a;z-index:1000;padding:.625rem}.appcore-daterangepicker__calendars{display:flex;align-items:flex-start;gap:0}.appcore-daterangepicker__calendar{width:252px}.appcore-daterangepicker__divider{width:1px;align-self:stretch;background-color:#ccc;margin:0 .75rem;flex-shrink:0}.appcore-daterangepicker__cal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:.5rem}.appcore-daterangepicker__cal-title{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111;flex:1;text-align:center}.appcore-daterangepicker__nav-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;color:#525252;transition:background-color .1s ease,color .1s ease;flex-shrink:0}.appcore-daterangepicker__nav-btn:hover{background-color:#e7eef3;color:#0c558c}.appcore-daterangepicker__nav-btn:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-daterangepicker__nav-spacer{width:28px;flex-shrink:0}.appcore-daterangepicker__weekdays{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-bottom:.125rem}.appcore-daterangepicker__weekday{font-size:12px;line-height:18px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#a3a3a3;text-align:center;padding:.125rem 0}.appcore-daterangepicker__days{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}.appcore-daterangepicker__day{display:flex;align-items:center;justify-content:center;width:100%;aspect-ratio:1;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;position:relative;z-index:0;font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;transition:background-color .1s ease,color .1s ease}.appcore-daterangepicker__day:before{content:\"\";position:absolute;inset:0;background:transparent;z-index:-1;pointer-events:none}.appcore-daterangepicker__day:hover:not(:disabled):not(.appcore-daterangepicker__day--range-start):not(.appcore-daterangepicker__day--range-end):not(.appcore-daterangepicker__day--in-range){background-color:#e7eef3;color:#0c558c}.appcore-daterangepicker__day:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-daterangepicker__day--outside{color:#a3a3a3}.appcore-daterangepicker__day--today:not(.appcore-daterangepicker__day--range-start):not(.appcore-daterangepicker__day--range-end){color:#0c558c;font-weight:500}.appcore-daterangepicker__day--today:not(.appcore-daterangepicker__day--range-start):not(.appcore-daterangepicker__day--range-end):after{content:\"\";position:absolute;bottom:3px;left:50%;transform:translate(-50%);width:4px;height:4px;border-radius:50%;background-color:#0c558c}.appcore-daterangepicker__day--in-range{background-color:#e7eef3;color:#0c558c;border-radius:0}.appcore-daterangepicker__day--in-range:before{background-color:#e7eef3;left:-2px;right:-2px}.appcore-daterangepicker__day--range-start:not(.appcore-daterangepicker__day--range-end){background-color:#0c558c;color:#fff;font-weight:500;border-radius:.25rem 0 0 .25rem}.appcore-daterangepicker__day--range-start:not(.appcore-daterangepicker__day--range-end):before{background-color:#e7eef3;left:50%;right:-2px}.appcore-daterangepicker__day--range-end:not(.appcore-daterangepicker__day--range-start){background-color:#0c558c;color:#fff;font-weight:500;border-radius:0 .25rem .25rem 0}.appcore-daterangepicker__day--range-end:not(.appcore-daterangepicker__day--range-start):before{background-color:#e7eef3;left:-2px;right:50%}.appcore-daterangepicker__day--range-start.appcore-daterangepicker__day--range-end{background-color:#0c558c;color:#fff;font-weight:500;border-radius:.25rem}.appcore-daterangepicker__day--range-start.appcore-daterangepicker__day--range-end:before{display:none}.appcore-daterangepicker__day--disabled{color:#a3a3a3;cursor:not-allowed;pointer-events:none}.appcore-daterangepicker__helper-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-daterangepicker__error-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}.appcore-daterangepicker--error .appcore-daterangepicker__control{border-color:#d2222d}.appcore-daterangepicker--error .appcore-daterangepicker__control:focus-within{border-color:#d2222d;box-shadow:0 0 0 2px #d2222d40}.appcore-daterangepicker--disabled .appcore-daterangepicker__label{color:#a3a3a3}.appcore-daterangepicker--disabled .appcore-daterangepicker__control{background-color:#f5f5f5;border-color:#ccc;cursor:not-allowed;pointer-events:none}.appcore-daterangepicker--disabled .appcore-daterangepicker__value,.appcore-daterangepicker--disabled .appcore-daterangepicker__icon{color:#a3a3a3}.appcore-daterangepicker--sm .appcore-daterangepicker__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-daterangepicker--sm .appcore-daterangepicker__control{height:32px;padding:0 .5rem}.appcore-daterangepicker--sm .appcore-daterangepicker__value{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-daterangepicker--lg .appcore-daterangepicker__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-daterangepicker--lg .appcore-daterangepicker__control{height:48px;padding:0 .75rem}.appcore-daterangepicker--lg .appcore-daterangepicker__value{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.DatePipe, name: "date" }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DateRangePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-daterangepicker', standalone: true, imports: [CommonModule, IconComponent], template: `
    <div
      class="appcore-daterangepicker"
      [ngClass]="[
        'appcore-daterangepicker--' + size,
        disabled ? 'appcore-daterangepicker--disabled' : '',
        error ? 'appcore-daterangepicker--error' : '',
        isOpen ? 'appcore-daterangepicker--open' : ''
      ]"
    >
      <!-- Label -->
      <label *ngIf="label" class="appcore-daterangepicker__label">{{ label }}</label>

      <!-- Trigger control -->
      <div class="appcore-daterangepicker__control" (click)="onControlClick()">
        <span class="appcore-daterangepicker__icon" aria-hidden="true">
          <app-icon icon="calendar_today" size="sm"></app-icon>
        </span>

        <span
          class="appcore-daterangepicker__value"
          [class.appcore-daterangepicker__value--placeholder]="!hasDisplayValue"
        >
          {{ displayValue }}
        </span>

        <!-- Clear button -->
        <button
          *ngIf="hasValue && !disabled"
          class="appcore-daterangepicker__clear"
          type="button"
          (click)="clear($event)"
          (mousedown)="$event.preventDefault()"
          aria-label="Clear date range"
        >
          <app-icon icon="close" size="sm"></app-icon>
        </button>
      </div>

      <!-- Calendar panel -->
      <div
        *ngIf="isOpen"
        class="appcore-daterangepicker__panel"
        role="dialog"
        aria-label="Date range picker"
      >
        <div class="appcore-daterangepicker__calendars">

          <!-- Left calendar -->
          <div class="appcore-daterangepicker__calendar">
            <div class="appcore-daterangepicker__cal-header">
              <button
                class="appcore-daterangepicker__nav-btn"
                type="button"
                (click)="prevMonth()"
                (mousedown)="$event.preventDefault()"
                aria-label="Previous month"
              >
                <app-icon icon="chevron_left" size="sm"></app-icon>
              </button>
              <span class="appcore-daterangepicker__cal-title">{{ leftMonthYearLabel }}</span>
              <span class="appcore-daterangepicker__nav-spacer"></span>
            </div>

            <div class="appcore-daterangepicker__weekdays">
              <span *ngFor="let day of weekdays" class="appcore-daterangepicker__weekday">{{ day }}</span>
            </div>

            <div class="appcore-daterangepicker__days">
              <button
                *ngFor="let cell of leftCalendarCells"
                class="appcore-daterangepicker__day"
                type="button"
                [ngClass]="{
                  'appcore-daterangepicker__day--outside': !cell.inMonth,
                  'appcore-daterangepicker__day--today': cell.isToday,
                  'appcore-daterangepicker__day--disabled': cell.isDisabled,
                  'appcore-daterangepicker__day--range-start': cell.isRangeStart,
                  'appcore-daterangepicker__day--range-end': cell.isRangeEnd,
                  'appcore-daterangepicker__day--in-range': cell.isInRange
                }"
                [disabled]="cell.isDisabled"
                (click)="selectDay(cell)"
                (mouseenter)="onDayHover(cell)"
                (mouseleave)="onDayLeave()"
                (mousedown)="$event.preventDefault()"
                [attr.aria-label]="cell.date | date:'longDate'"
                [attr.aria-selected]="cell.isRangeStart || cell.isRangeEnd"
                [attr.aria-current]="cell.isToday ? 'date' : null"
              >
                {{ cell.date.getDate() }}
              </button>
            </div>
          </div>

          <div class="appcore-daterangepicker__divider"></div>

          <!-- Right calendar -->
          <div class="appcore-daterangepicker__calendar">
            <div class="appcore-daterangepicker__cal-header">
              <span class="appcore-daterangepicker__nav-spacer"></span>
              <span class="appcore-daterangepicker__cal-title">{{ rightMonthYearLabel }}</span>
              <button
                class="appcore-daterangepicker__nav-btn"
                type="button"
                (click)="nextMonth()"
                (mousedown)="$event.preventDefault()"
                aria-label="Next month"
              >
                <app-icon icon="chevron_right" size="sm"></app-icon>
              </button>
            </div>

            <div class="appcore-daterangepicker__weekdays">
              <span *ngFor="let day of weekdays" class="appcore-daterangepicker__weekday">{{ day }}</span>
            </div>

            <div class="appcore-daterangepicker__days">
              <button
                *ngFor="let cell of rightCalendarCells"
                class="appcore-daterangepicker__day"
                type="button"
                [ngClass]="{
                  'appcore-daterangepicker__day--outside': !cell.inMonth,
                  'appcore-daterangepicker__day--today': cell.isToday,
                  'appcore-daterangepicker__day--disabled': cell.isDisabled,
                  'appcore-daterangepicker__day--range-start': cell.isRangeStart,
                  'appcore-daterangepicker__day--range-end': cell.isRangeEnd,
                  'appcore-daterangepicker__day--in-range': cell.isInRange
                }"
                [disabled]="cell.isDisabled"
                (click)="selectDay(cell)"
                (mouseenter)="onDayHover(cell)"
                (mouseleave)="onDayLeave()"
                (mousedown)="$event.preventDefault()"
                [attr.aria-label]="cell.date | date:'longDate'"
                [attr.aria-selected]="cell.isRangeStart || cell.isRangeEnd"
                [attr.aria-current]="cell.isToday ? 'date' : null"
              >
                {{ cell.date.getDate() }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Helper / Error text -->
      <span *ngIf="error && errorMessage" class="appcore-daterangepicker__error-text">
        {{ errorMessage }}
      </span>
      <span *ngIf="!error && helperText" class="appcore-daterangepicker__helper-text">
        {{ helperText }}
      </span>
    </div>
  `, styles: [".appcore-daterangepicker{display:inline-flex;flex-direction:column;gap:.25rem;font-family:Inter,sans-serif;position:relative;width:100%}.appcore-daterangepicker__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#3d3d3d}.appcore-daterangepicker__control{display:flex;align-items:center;gap:.25rem;padding:0 .625rem;height:40px;border:1px solid rgb(204,204,204);border-radius:.5rem;background-color:#fff;cursor:pointer;transition:border-color .15s ease,box-shadow .15s ease}.appcore-daterangepicker__control:focus-within{border-color:#0c558c;box-shadow:0 0 0 2px #007bff;outline:none}.appcore-daterangepicker--open .appcore-daterangepicker__control{border-color:#0c558c}.appcore-daterangepicker__icon{display:flex;align-items:center;justify-content:center;color:#525252;flex-shrink:0;pointer-events:none}.appcore-daterangepicker__value{flex:1;min-width:0;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;user-select:none}.appcore-daterangepicker__value--placeholder{color:#a3a3a3;font-weight:400}.appcore-daterangepicker__clear{display:flex;align-items:center;justify-content:center;padding:0;border:none;background:transparent;cursor:pointer;color:#a3a3a3;flex-shrink:0;line-height:1}.appcore-daterangepicker__clear:hover{color:#111}.appcore-daterangepicker__panel{position:absolute;top:calc(100% + 4px);left:0;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;box-shadow:0 4px 12px #0000001a;z-index:1000;padding:.625rem}.appcore-daterangepicker__calendars{display:flex;align-items:flex-start;gap:0}.appcore-daterangepicker__calendar{width:252px}.appcore-daterangepicker__divider{width:1px;align-self:stretch;background-color:#ccc;margin:0 .75rem;flex-shrink:0}.appcore-daterangepicker__cal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:.5rem}.appcore-daterangepicker__cal-title{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111;flex:1;text-align:center}.appcore-daterangepicker__nav-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;color:#525252;transition:background-color .1s ease,color .1s ease;flex-shrink:0}.appcore-daterangepicker__nav-btn:hover{background-color:#e7eef3;color:#0c558c}.appcore-daterangepicker__nav-btn:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-daterangepicker__nav-spacer{width:28px;flex-shrink:0}.appcore-daterangepicker__weekdays{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-bottom:.125rem}.appcore-daterangepicker__weekday{font-size:12px;line-height:18px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#a3a3a3;text-align:center;padding:.125rem 0}.appcore-daterangepicker__days{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}.appcore-daterangepicker__day{display:flex;align-items:center;justify-content:center;width:100%;aspect-ratio:1;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;position:relative;z-index:0;font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;transition:background-color .1s ease,color .1s ease}.appcore-daterangepicker__day:before{content:\"\";position:absolute;inset:0;background:transparent;z-index:-1;pointer-events:none}.appcore-daterangepicker__day:hover:not(:disabled):not(.appcore-daterangepicker__day--range-start):not(.appcore-daterangepicker__day--range-end):not(.appcore-daterangepicker__day--in-range){background-color:#e7eef3;color:#0c558c}.appcore-daterangepicker__day:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-daterangepicker__day--outside{color:#a3a3a3}.appcore-daterangepicker__day--today:not(.appcore-daterangepicker__day--range-start):not(.appcore-daterangepicker__day--range-end){color:#0c558c;font-weight:500}.appcore-daterangepicker__day--today:not(.appcore-daterangepicker__day--range-start):not(.appcore-daterangepicker__day--range-end):after{content:\"\";position:absolute;bottom:3px;left:50%;transform:translate(-50%);width:4px;height:4px;border-radius:50%;background-color:#0c558c}.appcore-daterangepicker__day--in-range{background-color:#e7eef3;color:#0c558c;border-radius:0}.appcore-daterangepicker__day--in-range:before{background-color:#e7eef3;left:-2px;right:-2px}.appcore-daterangepicker__day--range-start:not(.appcore-daterangepicker__day--range-end){background-color:#0c558c;color:#fff;font-weight:500;border-radius:.25rem 0 0 .25rem}.appcore-daterangepicker__day--range-start:not(.appcore-daterangepicker__day--range-end):before{background-color:#e7eef3;left:50%;right:-2px}.appcore-daterangepicker__day--range-end:not(.appcore-daterangepicker__day--range-start){background-color:#0c558c;color:#fff;font-weight:500;border-radius:0 .25rem .25rem 0}.appcore-daterangepicker__day--range-end:not(.appcore-daterangepicker__day--range-start):before{background-color:#e7eef3;left:-2px;right:50%}.appcore-daterangepicker__day--range-start.appcore-daterangepicker__day--range-end{background-color:#0c558c;color:#fff;font-weight:500;border-radius:.25rem}.appcore-daterangepicker__day--range-start.appcore-daterangepicker__day--range-end:before{display:none}.appcore-daterangepicker__day--disabled{color:#a3a3a3;cursor:not-allowed;pointer-events:none}.appcore-daterangepicker__helper-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-daterangepicker__error-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}.appcore-daterangepicker--error .appcore-daterangepicker__control{border-color:#d2222d}.appcore-daterangepicker--error .appcore-daterangepicker__control:focus-within{border-color:#d2222d;box-shadow:0 0 0 2px #d2222d40}.appcore-daterangepicker--disabled .appcore-daterangepicker__label{color:#a3a3a3}.appcore-daterangepicker--disabled .appcore-daterangepicker__control{background-color:#f5f5f5;border-color:#ccc;cursor:not-allowed;pointer-events:none}.appcore-daterangepicker--disabled .appcore-daterangepicker__value,.appcore-daterangepicker--disabled .appcore-daterangepicker__icon{color:#a3a3a3}.appcore-daterangepicker--sm .appcore-daterangepicker__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-daterangepicker--sm .appcore-daterangepicker__control{height:32px;padding:0 .5rem}.appcore-daterangepicker--sm .appcore-daterangepicker__value{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-daterangepicker--lg .appcore-daterangepicker__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-daterangepicker--lg .appcore-daterangepicker__control{height:48px;padding:0 .75rem}.appcore-daterangepicker--lg .appcore-daterangepicker__value{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { value: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], helperText: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], error: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class MonthPickerComponent {
    constructor(elementRef) {
        this.elementRef = elementRef;
        /** Currently selected month/year. */
        this.value = null;
        /** Field label rendered above the control. */
        this.label = '';
        /** Placeholder shown when no month is selected. */
        this.placeholder = 'Select a month';
        /** Helper text shown below the control in the default state. */
        this.helperText = '';
        /** Error message shown when error=true. */
        this.errorMessage = '';
        /** Visual size of the picker. */
        this.size = 'md';
        /** Disables all interaction. */
        this.disabled = false;
        /** Shows error styling and errorMessage. */
        this.error = false;
        /** Earliest selectable month (inclusive). */
        this.minValue = null;
        /** Latest selectable month (inclusive). */
        this.maxValue = null;
        /** Emits the selected MonthValue (or null when cleared). */
        this.valueChange = new EventEmitter();
        this.monthLabels = [
            'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
        ];
        this.isOpen = false;
        this.viewYear = new Date().getFullYear();
    }
    // ─── Lifecycle ──────────────────────────────────────────────────────────────
    ngOnChanges() {
        if (this.value) {
            this.viewYear = this.value.year;
        }
    }
    // ─── Outside-click close ────────────────────────────────────────────────────
    onDocumentClick(event) {
        if (!this.elementRef.nativeElement.contains(event.target)) {
            this.close();
        }
    }
    // ─── Open / close ───────────────────────────────────────────────────────────
    open() {
        if (this.disabled)
            return;
        if (this.value) {
            this.viewYear = this.value.year;
        }
        this.isOpen = true;
    }
    close() {
        this.isOpen = false;
    }
    onControlClick() {
        this.isOpen ? this.close() : this.open();
    }
    // ─── Year navigation ────────────────────────────────────────────────────────
    prevYear() {
        this.viewYear--;
    }
    nextYear() {
        this.viewYear++;
    }
    // ─── Month selection ────────────────────────────────────────────────────────
    selectMonth(cell) {
        if (cell.isDisabled)
            return;
        this.value = { year: this.viewYear, month: cell.month };
        this.valueChange.emit(this.value);
        this.close();
    }
    clear(event) {
        event.stopPropagation();
        this.value = null;
        this.valueChange.emit(null);
    }
    // ─── Computed properties ────────────────────────────────────────────────────
    get monthCells() {
        const now = new Date();
        const currentYear = now.getFullYear();
        const currentMonth = now.getMonth();
        return this.monthLabels.map((label, index) => {
            const isSelected = this.value !== null &&
                this.value.year === this.viewYear &&
                this.value.month === index;
            const isCurrentMonth = this.viewYear === currentYear && index === currentMonth;
            let isDisabled = false;
            if (this.minValue) {
                const minTotal = this.minValue.year * 12 + this.minValue.month;
                const cellTotal = this.viewYear * 12 + index;
                if (cellTotal < minTotal)
                    isDisabled = true;
            }
            if (this.maxValue) {
                const maxTotal = this.maxValue.year * 12 + this.maxValue.month;
                const cellTotal = this.viewYear * 12 + index;
                if (cellTotal > maxTotal)
                    isDisabled = true;
            }
            return { label, month: index, isSelected, isCurrentMonth, isDisabled };
        });
    }
    formatValue(v) {
        return new Date(v.year, v.month, 1).toLocaleDateString('en-US', {
            month: 'short',
            year: 'numeric',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: MonthPickerComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: MonthPickerComponent, isStandalone: true, selector: "appcore-monthpicker", inputs: { value: "value", label: "label", placeholder: "placeholder", helperText: "helperText", errorMessage: "errorMessage", size: "size", disabled: "disabled", error: "error", minValue: "minValue", maxValue: "maxValue" }, outputs: { valueChange: "valueChange" }, host: { listeners: { "document:click": "onDocumentClick($event)" } }, usesOnChanges: true, ngImport: i0, template: `
    <div
      class="appcore-monthpicker"
      [ngClass]="[
        'appcore-monthpicker--' + size,
        disabled ? 'appcore-monthpicker--disabled' : '',
        error ? 'appcore-monthpicker--error' : '',
        isOpen ? 'appcore-monthpicker--open' : ''
      ]"
    >
      <!-- Label -->
      <label *ngIf="label" class="appcore-monthpicker__label">{{ label }}</label>

      <!-- Trigger control -->
      <div class="appcore-monthpicker__control" (click)="onControlClick()">
        <span
          class="appcore-monthpicker__value"
          [class.appcore-monthpicker__value--placeholder]="!value"
        >
          {{ value ? formatValue(value) : placeholder }}
        </span>

        <!-- Clear button -->
        <button
          *ngIf="value && !disabled"
          class="appcore-monthpicker__clear"
          type="button"
          (click)="clear($event)"
          (mousedown)="$event.preventDefault()"
          aria-label="Clear month"
        >
          <app-icon icon="close" size="sm"></app-icon>
        </button>

        <!-- Calendar icon -->
        <span class="appcore-monthpicker__icon" aria-hidden="true">
          <app-icon icon="calendar_today" size="sm"></app-icon>
        </span>
      </div>

      <!-- Month picker panel -->
      <div
        *ngIf="isOpen"
        class="appcore-monthpicker__panel"
        role="dialog"
        aria-label="Month picker"
      >
        <!-- Year navigation header -->
        <div class="appcore-monthpicker__header">
          <button
            class="appcore-monthpicker__nav-btn"
            type="button"
            (click)="prevYear()"
            (mousedown)="$event.preventDefault()"
            aria-label="Previous year"
          >
            <app-icon icon="chevron_left" size="sm"></app-icon>
          </button>

          <span class="appcore-monthpicker__year-label">{{ viewYear }}</span>

          <button
            class="appcore-monthpicker__nav-btn"
            type="button"
            (click)="nextYear()"
            (mousedown)="$event.preventDefault()"
            aria-label="Next year"
          >
            <app-icon icon="chevron_right" size="sm"></app-icon>
          </button>
        </div>

        <!-- Month grid (4 × 3) -->
        <div class="appcore-monthpicker__grid">
          <button
            *ngFor="let cell of monthCells"
            class="appcore-monthpicker__month"
            type="button"
            [ngClass]="{
              'appcore-monthpicker__month--current': cell.isCurrentMonth,
              'appcore-monthpicker__month--selected': cell.isSelected,
              'appcore-monthpicker__month--disabled': cell.isDisabled
            }"
            [disabled]="cell.isDisabled"
            (click)="selectMonth(cell)"
            (mousedown)="$event.preventDefault()"
            [attr.aria-label]="cell.label + ' ' + viewYear"
            [attr.aria-selected]="cell.isSelected"
            [attr.aria-current]="cell.isCurrentMonth ? 'date' : null"
          >
            {{ cell.label }}
          </button>
        </div>
      </div>

      <!-- Helper / Error text -->
      <span *ngIf="error && errorMessage" class="appcore-monthpicker__error-text">
        {{ errorMessage }}
      </span>
      <span *ngIf="!error && helperText" class="appcore-monthpicker__helper-text">
        {{ helperText }}
      </span>
    </div>
  `, isInline: true, styles: [".appcore-monthpicker{display:inline-flex;flex-direction:column;gap:.25rem;font-family:Inter,sans-serif;position:relative;width:100%}.appcore-monthpicker__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#3d3d3d}.appcore-monthpicker__control{display:flex;align-items:center;gap:.25rem;padding:0 .625rem;height:40px;border:1px solid rgb(204,204,204);border-radius:.5rem;background-color:#fff;cursor:pointer;transition:border-color .15s ease,box-shadow .15s ease}.appcore-monthpicker__control:focus-within{border-color:#0c558c;box-shadow:0 0 0 2px #007bff;outline:none}.appcore-monthpicker--open .appcore-monthpicker__control{border-color:#0c558c}.appcore-monthpicker__value{flex:1;min-width:0;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;user-select:none}.appcore-monthpicker__value--placeholder{color:#a3a3a3;font-weight:400}.appcore-monthpicker__clear{display:flex;align-items:center;justify-content:center;padding:0;border:none;background:transparent;cursor:pointer;color:#a3a3a3;flex-shrink:0;line-height:1}.appcore-monthpicker__clear:hover{color:#111}.appcore-monthpicker__icon{display:flex;align-items:center;justify-content:center;color:#525252;flex-shrink:0;pointer-events:none}.appcore-monthpicker__panel{position:absolute;top:calc(100% + 4px);left:0;width:256px;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;box-shadow:0 4px 12px #0000001a;z-index:1000;padding:.625rem}.appcore-monthpicker__header{display:flex;align-items:center;justify-content:space-between;margin-bottom:.5rem}.appcore-monthpicker__year-label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111;flex:1;text-align:center}.appcore-monthpicker__nav-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;color:#525252;transition:background-color .1s ease,color .1s ease;flex-shrink:0}.appcore-monthpicker__nav-btn:hover{background-color:#e7eef3;color:#0c558c}.appcore-monthpicker__nav-btn:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-monthpicker__grid{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}.appcore-monthpicker__month{display:flex;align-items:center;justify-content:center;height:36px;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;transition:background-color .1s ease,color .1s ease}.appcore-monthpicker__month:hover:not(:disabled){background-color:#e7eef3;color:#0c558c}.appcore-monthpicker__month:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-monthpicker__month--current:not(.appcore-monthpicker__month--selected){color:#0c558c;font-weight:500;position:relative}.appcore-monthpicker__month--current:not(.appcore-monthpicker__month--selected):after{content:\"\";position:absolute;bottom:4px;left:50%;transform:translate(-50%);width:4px;height:4px;border-radius:50%;background-color:#0c558c}.appcore-monthpicker__month--selected{background-color:#0c558c;color:#fff;font-weight:500}.appcore-monthpicker__month--selected:hover{background-color:#0c5082}.appcore-monthpicker__month--disabled{color:#a3a3a3;cursor:not-allowed;pointer-events:none}.appcore-monthpicker__helper-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-monthpicker__error-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}.appcore-monthpicker--error .appcore-monthpicker__control{border-color:#d2222d}.appcore-monthpicker--error .appcore-monthpicker__control:focus-within{border-color:#d2222d;box-shadow:0 0 0 2px #d2222d40}.appcore-monthpicker--disabled .appcore-monthpicker__label{color:#a3a3a3}.appcore-monthpicker--disabled .appcore-monthpicker__control{background-color:#f5f5f5;border-color:#ccc;cursor:not-allowed;pointer-events:none}.appcore-monthpicker--disabled .appcore-monthpicker__value{color:#a3a3a3}.appcore-monthpicker--sm .appcore-monthpicker__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-monthpicker--sm .appcore-monthpicker__control{height:32px;padding:0 .5rem}.appcore-monthpicker--sm .appcore-monthpicker__value{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-monthpicker--lg .appcore-monthpicker__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-monthpicker--lg .appcore-monthpicker__control{height:48px;padding:0 .75rem}.appcore-monthpicker--lg .appcore-monthpicker__value{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: MonthPickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-monthpicker', standalone: true, imports: [CommonModule, IconComponent], template: `
    <div
      class="appcore-monthpicker"
      [ngClass]="[
        'appcore-monthpicker--' + size,
        disabled ? 'appcore-monthpicker--disabled' : '',
        error ? 'appcore-monthpicker--error' : '',
        isOpen ? 'appcore-monthpicker--open' : ''
      ]"
    >
      <!-- Label -->
      <label *ngIf="label" class="appcore-monthpicker__label">{{ label }}</label>

      <!-- Trigger control -->
      <div class="appcore-monthpicker__control" (click)="onControlClick()">
        <span
          class="appcore-monthpicker__value"
          [class.appcore-monthpicker__value--placeholder]="!value"
        >
          {{ value ? formatValue(value) : placeholder }}
        </span>

        <!-- Clear button -->
        <button
          *ngIf="value && !disabled"
          class="appcore-monthpicker__clear"
          type="button"
          (click)="clear($event)"
          (mousedown)="$event.preventDefault()"
          aria-label="Clear month"
        >
          <app-icon icon="close" size="sm"></app-icon>
        </button>

        <!-- Calendar icon -->
        <span class="appcore-monthpicker__icon" aria-hidden="true">
          <app-icon icon="calendar_today" size="sm"></app-icon>
        </span>
      </div>

      <!-- Month picker panel -->
      <div
        *ngIf="isOpen"
        class="appcore-monthpicker__panel"
        role="dialog"
        aria-label="Month picker"
      >
        <!-- Year navigation header -->
        <div class="appcore-monthpicker__header">
          <button
            class="appcore-monthpicker__nav-btn"
            type="button"
            (click)="prevYear()"
            (mousedown)="$event.preventDefault()"
            aria-label="Previous year"
          >
            <app-icon icon="chevron_left" size="sm"></app-icon>
          </button>

          <span class="appcore-monthpicker__year-label">{{ viewYear }}</span>

          <button
            class="appcore-monthpicker__nav-btn"
            type="button"
            (click)="nextYear()"
            (mousedown)="$event.preventDefault()"
            aria-label="Next year"
          >
            <app-icon icon="chevron_right" size="sm"></app-icon>
          </button>
        </div>

        <!-- Month grid (4 × 3) -->
        <div class="appcore-monthpicker__grid">
          <button
            *ngFor="let cell of monthCells"
            class="appcore-monthpicker__month"
            type="button"
            [ngClass]="{
              'appcore-monthpicker__month--current': cell.isCurrentMonth,
              'appcore-monthpicker__month--selected': cell.isSelected,
              'appcore-monthpicker__month--disabled': cell.isDisabled
            }"
            [disabled]="cell.isDisabled"
            (click)="selectMonth(cell)"
            (mousedown)="$event.preventDefault()"
            [attr.aria-label]="cell.label + ' ' + viewYear"
            [attr.aria-selected]="cell.isSelected"
            [attr.aria-current]="cell.isCurrentMonth ? 'date' : null"
          >
            {{ cell.label }}
          </button>
        </div>
      </div>

      <!-- Helper / Error text -->
      <span *ngIf="error && errorMessage" class="appcore-monthpicker__error-text">
        {{ errorMessage }}
      </span>
      <span *ngIf="!error && helperText" class="appcore-monthpicker__helper-text">
        {{ helperText }}
      </span>
    </div>
  `, styles: [".appcore-monthpicker{display:inline-flex;flex-direction:column;gap:.25rem;font-family:Inter,sans-serif;position:relative;width:100%}.appcore-monthpicker__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#3d3d3d}.appcore-monthpicker__control{display:flex;align-items:center;gap:.25rem;padding:0 .625rem;height:40px;border:1px solid rgb(204,204,204);border-radius:.5rem;background-color:#fff;cursor:pointer;transition:border-color .15s ease,box-shadow .15s ease}.appcore-monthpicker__control:focus-within{border-color:#0c558c;box-shadow:0 0 0 2px #007bff;outline:none}.appcore-monthpicker--open .appcore-monthpicker__control{border-color:#0c558c}.appcore-monthpicker__value{flex:1;min-width:0;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;user-select:none}.appcore-monthpicker__value--placeholder{color:#a3a3a3;font-weight:400}.appcore-monthpicker__clear{display:flex;align-items:center;justify-content:center;padding:0;border:none;background:transparent;cursor:pointer;color:#a3a3a3;flex-shrink:0;line-height:1}.appcore-monthpicker__clear:hover{color:#111}.appcore-monthpicker__icon{display:flex;align-items:center;justify-content:center;color:#525252;flex-shrink:0;pointer-events:none}.appcore-monthpicker__panel{position:absolute;top:calc(100% + 4px);left:0;width:256px;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:.5rem;box-shadow:0 4px 12px #0000001a;z-index:1000;padding:.625rem}.appcore-monthpicker__header{display:flex;align-items:center;justify-content:space-between;margin-bottom:.5rem}.appcore-monthpicker__year-label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111;flex:1;text-align:center}.appcore-monthpicker__nav-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;color:#525252;transition:background-color .1s ease,color .1s ease;flex-shrink:0}.appcore-monthpicker__nav-btn:hover{background-color:#e7eef3;color:#0c558c}.appcore-monthpicker__nav-btn:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-monthpicker__grid{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}.appcore-monthpicker__month{display:flex;align-items:center;justify-content:center;height:36px;padding:0;border:none;border-radius:.25rem;background:transparent;cursor:pointer;font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#111;transition:background-color .1s ease,color .1s ease}.appcore-monthpicker__month:hover:not(:disabled){background-color:#e7eef3;color:#0c558c}.appcore-monthpicker__month:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:1px}.appcore-monthpicker__month--current:not(.appcore-monthpicker__month--selected){color:#0c558c;font-weight:500;position:relative}.appcore-monthpicker__month--current:not(.appcore-monthpicker__month--selected):after{content:\"\";position:absolute;bottom:4px;left:50%;transform:translate(-50%);width:4px;height:4px;border-radius:50%;background-color:#0c558c}.appcore-monthpicker__month--selected{background-color:#0c558c;color:#fff;font-weight:500}.appcore-monthpicker__month--selected:hover{background-color:#0c5082}.appcore-monthpicker__month--disabled{color:#a3a3a3;cursor:not-allowed;pointer-events:none}.appcore-monthpicker__helper-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#525252}.appcore-monthpicker__error-text{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;color:#d2222d}.appcore-monthpicker--error .appcore-monthpicker__control{border-color:#d2222d}.appcore-monthpicker--error .appcore-monthpicker__control:focus-within{border-color:#d2222d;box-shadow:0 0 0 2px #d2222d40}.appcore-monthpicker--disabled .appcore-monthpicker__label{color:#a3a3a3}.appcore-monthpicker--disabled .appcore-monthpicker__control{background-color:#f5f5f5;border-color:#ccc;cursor:not-allowed;pointer-events:none}.appcore-monthpicker--disabled .appcore-monthpicker__value{color:#a3a3a3}.appcore-monthpicker--sm .appcore-monthpicker__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-monthpicker--sm .appcore-monthpicker__control{height:32px;padding:0 .5rem}.appcore-monthpicker--sm .appcore-monthpicker__value{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-monthpicker--lg .appcore-monthpicker__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}.appcore-monthpicker--lg .appcore-monthpicker__control{height:48px;padding:0 .75rem}.appcore-monthpicker--lg .appcore-monthpicker__value{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { value: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], helperText: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], error: [{
                type: Input
            }], minValue: [{
                type: Input
            }], maxValue: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class DescriptionItemComponent {
    constructor() {
        this.label = 'Label:';
        this.value = 'Text';
        this.size = 'M';
        this.type = 'Horizontal';
        // Label icon
        this.showLabelIcon = false;
        this.labelIcon = 'info';
        // Content icons
        this.showContentIcon1 = false;
        this.contentIcon1 = 'open_in_new';
        this.showContentIcon2 = false;
        this.contentIcon2 = 'content_copy';
        // Badge
        this.showBadge = false;
        this.badgeLabel = 'Badge';
        // Prefix avatar (left side for 2Column / Display)
        this.showPrefixAvatar = false;
        this.prefixAvatarLabel = 'KS';
        // Content avatar (inside content row before value)
        this.showContentAvatar = false;
        this.contentAvatarLabel = 'KS';
        // Suffix avatar (after the body)
        this.showSuffixAvatar = false;
        this.suffixAvatarLabel = 'KS';
    }
    get iconSize() {
        return this.size === 'L' ? 'md' : 'sm';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DescriptionItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: DescriptionItemComponent, isStandalone: true, selector: "appcore-description-item", inputs: { label: "label", value: "value", size: "size", type: "type", showLabelIcon: "showLabelIcon", labelIcon: "labelIcon", showContentIcon1: "showContentIcon1", contentIcon1: "contentIcon1", showContentIcon2: "showContentIcon2", contentIcon2: "contentIcon2", showBadge: "showBadge", badgeLabel: "badgeLabel", showPrefixAvatar: "showPrefixAvatar", prefixAvatarLabel: "prefixAvatarLabel", showContentAvatar: "showContentAvatar", contentAvatarLabel: "contentAvatarLabel", showSuffixAvatar: "showSuffixAvatar", suffixAvatarLabel: "suffixAvatarLabel" }, ngImport: i0, template: `
    <div
      class="appcore-description-item"
      [ngClass]="[
        'appcore-description-item--type-' + type,
        'appcore-description-item--size-' + size
      ]"
    >
      <!-- Prefix Avatar (left side, used in 2Column and Display types) -->
      <div *ngIf="showPrefixAvatar" class="appcore-description-item__avatar appcore-description-item__avatar--prefix">
        <span>{{ prefixAvatarLabel }}</span>
      </div>

      <!-- Main body -->
      <div class="appcore-description-item__body">

        <!-- Label row -->
        <div class="appcore-description-item__label-wrapper">
          <app-icon
            *ngIf="showLabelIcon"
            [icon]="labelIcon"
            iconSet="material"
            [size]="iconSize"
            class="appcore-description-item__icon"
          ></app-icon>
          <span class="appcore-description-item__label">{{ label }}</span>
        </div>

        <!-- Content row -->
        <div class="appcore-description-item__content">
          <!-- Content avatar (appears before value text) -->
          <div
            *ngIf="showContentAvatar"
            class="appcore-description-item__avatar appcore-description-item__avatar--content"
          >
            <span>{{ contentAvatarLabel }}</span>
          </div>

          <span class="appcore-description-item__value">{{ value }}</span>

          <app-icon
            *ngIf="showContentIcon1"
            [icon]="contentIcon1"
            iconSet="material"
            [size]="iconSize"
            class="appcore-description-item__icon"
          ></app-icon>

          <app-icon
            *ngIf="showContentIcon2"
            [icon]="contentIcon2"
            iconSet="material"
            [size]="iconSize"
            class="appcore-description-item__icon"
          ></app-icon>

          <app-badge
            *ngIf="showBadge"
            [label]="badgeLabel"
            badgeStyle="Toned"
            size="S"
          ></app-badge>
        </div>
      </div>

      <!-- Suffix Avatar (after content, all types) -->
      <div *ngIf="showSuffixAvatar" class="appcore-description-item__avatar appcore-description-item__avatar--suffix">
        <span>{{ suffixAvatarLabel }}</span>
      </div>
    </div>
  `, isInline: true, styles: [".appcore-description-item{display:flex;align-items:center;font-family:Inter,sans-serif;box-sizing:border-box}.appcore-description-item__body{display:flex;min-width:0;flex:1}.appcore-description-item__label-wrapper{display:flex;flex-direction:row;align-items:center;gap:.25rem;flex-shrink:0}.appcore-description-item__label{color:#525252;font-weight:400;white-space:nowrap}.appcore-description-item__content{display:flex;flex-direction:row;align-items:center;gap:.25rem;flex:1;min-width:0}.appcore-description-item__value{color:#111;font-weight:500}.appcore-description-item__icon{flex-shrink:0;color:#525252}.appcore-description-item__avatar{border-radius:50%;background:#f5f5f5;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:12px;font-weight:500;color:#525252;font-family:Inter,sans-serif}.appcore-description-item__avatar--prefix,.appcore-description-item__avatar--suffix{width:2.5rem;height:2.5rem}.appcore-description-item__avatar--content{width:1.5rem;height:1.5rem;font-size:.625rem}.appcore-description-item--type-Horizontal{flex-direction:row;gap:.25rem}.appcore-description-item--type-Horizontal .appcore-description-item__body{flex-direction:row;align-items:center;gap:.25rem}.appcore-description-item--type-Vertical{flex-direction:column;align-items:flex-start}.appcore-description-item--type-Vertical .appcore-description-item__body{flex-direction:column;align-items:flex-start;gap:.25rem;width:100%}.appcore-description-item--type-2Column{flex-direction:row;align-items:center;gap:.5rem}.appcore-description-item--type-2Column .appcore-description-item__body{flex-direction:column;align-items:flex-start;gap:.125rem}.appcore-description-item--type-Display{flex-direction:row;align-items:stretch;gap:.5rem}.appcore-description-item--type-Display .appcore-description-item__body{flex-direction:column;align-items:flex-start;gap:.25rem;flex:1}.appcore-description-item--type-Display .appcore-description-item__avatar--prefix{width:2.5rem;height:auto;align-self:stretch}.appcore-description-item--size-S .appcore-description-item__label,.appcore-description-item--size-S .appcore-description-item__value{font-size:12px;line-height:1rem}.appcore-description-item--size-M .appcore-description-item__label,.appcore-description-item--size-M .appcore-description-item__value{font-size:14px;line-height:1.125rem}.appcore-description-item--size-L .appcore-description-item__label,.appcore-description-item--size-L .appcore-description-item__value{font-size:16px;line-height:1.25rem}.appcore-description-item--type-Display.appcore-description-item--size-S .appcore-description-item__value{font-size:24px;font-weight:600;line-height:2rem}.appcore-description-item--type-Display.appcore-description-item--size-M .appcore-description-item__value,.appcore-description-item--type-Display.appcore-description-item--size-L .appcore-description-item__value{font-size:32px;font-weight:600;line-height:2.5rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }, { kind: "component", type: BadgeComponent, selector: "app-badge", inputs: ["label", "type", "badgeStyle", "size", "showPrefixIcon", "showSuffixIcon", "prefixIcon", "prefixIconSet", "prefixIconSrc", "suffixIcon", "suffixIconSet", "suffixIconSrc"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DescriptionItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-description-item', standalone: true, imports: [CommonModule, IconComponent, BadgeComponent], template: `
    <div
      class="appcore-description-item"
      [ngClass]="[
        'appcore-description-item--type-' + type,
        'appcore-description-item--size-' + size
      ]"
    >
      <!-- Prefix Avatar (left side, used in 2Column and Display types) -->
      <div *ngIf="showPrefixAvatar" class="appcore-description-item__avatar appcore-description-item__avatar--prefix">
        <span>{{ prefixAvatarLabel }}</span>
      </div>

      <!-- Main body -->
      <div class="appcore-description-item__body">

        <!-- Label row -->
        <div class="appcore-description-item__label-wrapper">
          <app-icon
            *ngIf="showLabelIcon"
            [icon]="labelIcon"
            iconSet="material"
            [size]="iconSize"
            class="appcore-description-item__icon"
          ></app-icon>
          <span class="appcore-description-item__label">{{ label }}</span>
        </div>

        <!-- Content row -->
        <div class="appcore-description-item__content">
          <!-- Content avatar (appears before value text) -->
          <div
            *ngIf="showContentAvatar"
            class="appcore-description-item__avatar appcore-description-item__avatar--content"
          >
            <span>{{ contentAvatarLabel }}</span>
          </div>

          <span class="appcore-description-item__value">{{ value }}</span>

          <app-icon
            *ngIf="showContentIcon1"
            [icon]="contentIcon1"
            iconSet="material"
            [size]="iconSize"
            class="appcore-description-item__icon"
          ></app-icon>

          <app-icon
            *ngIf="showContentIcon2"
            [icon]="contentIcon2"
            iconSet="material"
            [size]="iconSize"
            class="appcore-description-item__icon"
          ></app-icon>

          <app-badge
            *ngIf="showBadge"
            [label]="badgeLabel"
            badgeStyle="Toned"
            size="S"
          ></app-badge>
        </div>
      </div>

      <!-- Suffix Avatar (after content, all types) -->
      <div *ngIf="showSuffixAvatar" class="appcore-description-item__avatar appcore-description-item__avatar--suffix">
        <span>{{ suffixAvatarLabel }}</span>
      </div>
    </div>
  `, styles: [".appcore-description-item{display:flex;align-items:center;font-family:Inter,sans-serif;box-sizing:border-box}.appcore-description-item__body{display:flex;min-width:0;flex:1}.appcore-description-item__label-wrapper{display:flex;flex-direction:row;align-items:center;gap:.25rem;flex-shrink:0}.appcore-description-item__label{color:#525252;font-weight:400;white-space:nowrap}.appcore-description-item__content{display:flex;flex-direction:row;align-items:center;gap:.25rem;flex:1;min-width:0}.appcore-description-item__value{color:#111;font-weight:500}.appcore-description-item__icon{flex-shrink:0;color:#525252}.appcore-description-item__avatar{border-radius:50%;background:#f5f5f5;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:12px;font-weight:500;color:#525252;font-family:Inter,sans-serif}.appcore-description-item__avatar--prefix,.appcore-description-item__avatar--suffix{width:2.5rem;height:2.5rem}.appcore-description-item__avatar--content{width:1.5rem;height:1.5rem;font-size:.625rem}.appcore-description-item--type-Horizontal{flex-direction:row;gap:.25rem}.appcore-description-item--type-Horizontal .appcore-description-item__body{flex-direction:row;align-items:center;gap:.25rem}.appcore-description-item--type-Vertical{flex-direction:column;align-items:flex-start}.appcore-description-item--type-Vertical .appcore-description-item__body{flex-direction:column;align-items:flex-start;gap:.25rem;width:100%}.appcore-description-item--type-2Column{flex-direction:row;align-items:center;gap:.5rem}.appcore-description-item--type-2Column .appcore-description-item__body{flex-direction:column;align-items:flex-start;gap:.125rem}.appcore-description-item--type-Display{flex-direction:row;align-items:stretch;gap:.5rem}.appcore-description-item--type-Display .appcore-description-item__body{flex-direction:column;align-items:flex-start;gap:.25rem;flex:1}.appcore-description-item--type-Display .appcore-description-item__avatar--prefix{width:2.5rem;height:auto;align-self:stretch}.appcore-description-item--size-S .appcore-description-item__label,.appcore-description-item--size-S .appcore-description-item__value{font-size:12px;line-height:1rem}.appcore-description-item--size-M .appcore-description-item__label,.appcore-description-item--size-M .appcore-description-item__value{font-size:14px;line-height:1.125rem}.appcore-description-item--size-L .appcore-description-item__label,.appcore-description-item--size-L .appcore-description-item__value{font-size:16px;line-height:1.25rem}.appcore-description-item--type-Display.appcore-description-item--size-S .appcore-description-item__value{font-size:24px;font-weight:600;line-height:2rem}.appcore-description-item--type-Display.appcore-description-item--size-M .appcore-description-item__value,.appcore-description-item--type-Display.appcore-description-item--size-L .appcore-description-item__value{font-size:32px;font-weight:600;line-height:2.5rem}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], value: [{
                type: Input
            }], size: [{
                type: Input
            }], type: [{
                type: Input
            }], showLabelIcon: [{
                type: Input
            }], labelIcon: [{
                type: Input
            }], showContentIcon1: [{
                type: Input
            }], contentIcon1: [{
                type: Input
            }], showContentIcon2: [{
                type: Input
            }], contentIcon2: [{
                type: Input
            }], showBadge: [{
                type: Input
            }], badgeLabel: [{
                type: Input
            }], showPrefixAvatar: [{
                type: Input
            }], prefixAvatarLabel: [{
                type: Input
            }], showContentAvatar: [{
                type: Input
            }], contentAvatarLabel: [{
                type: Input
            }], showSuffixAvatar: [{
                type: Input
            }], suffixAvatarLabel: [{
                type: Input
            }] } });

class DescriptionListComponent {
    constructor() {
        this.items = [];
        /** How items are arranged: 'vertical' stacks them, 'horizontal' places them in a row */
        this.layout = 'vertical';
        /** Default item layout type — can be overridden per-item via item.type */
        this.itemType = 'Horizontal';
        /** Default size for all items — can be overridden per-item via item.size */
        this.size = 'M';
        this.title = '';
        this.divider = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DescriptionListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: DescriptionListComponent, isStandalone: true, selector: "appcore-description-list", inputs: { items: "items", layout: "layout", itemType: "itemType", size: "size", title: "title", divider: "divider" }, ngImport: i0, template: `
    <div
      class="appcore-description-list"
      [ngClass]="[
        'appcore-description-list--layout-' + layout,
        'appcore-description-list--size-' + size,
        divider ? 'appcore-description-list--divider' : ''
      ]"
    >
      <span *ngIf="title" class="appcore-description-list__title">{{ title }}</span>

      <div class="appcore-description-list__items">
        <div *ngFor="let item of items" class="appcore-description-list__item">
          <appcore-description-item
            [label]="item.label"
            [value]="item.value"
            [size]="item.size || size"
            [type]="item.type || itemType"
            [showLabelIcon]="item.showLabelIcon || false"
            [labelIcon]="item.labelIcon || 'info'"
            [showContentIcon1]="item.showContentIcon1 || false"
            [contentIcon1]="item.contentIcon1 || 'open_in_new'"
            [showContentIcon2]="item.showContentIcon2 || false"
            [contentIcon2]="item.contentIcon2 || 'content_copy'"
            [showBadge]="item.showBadge || false"
            [badgeLabel]="item.badgeLabel || ''"
            [showPrefixAvatar]="item.showPrefixAvatar || false"
            [prefixAvatarLabel]="item.prefixAvatarLabel || 'KS'"
            [showContentAvatar]="item.showContentAvatar || false"
            [contentAvatarLabel]="item.contentAvatarLabel || 'KS'"
            [showSuffixAvatar]="item.showSuffixAvatar || false"
            [suffixAvatarLabel]="item.suffixAvatarLabel || 'KS'"
          ></appcore-description-item>
        </div>
      </div>
    </div>
  `, isInline: true, styles: [".appcore-description-list{display:flex;flex-direction:column;font-family:Inter,sans-serif;box-sizing:border-box;padding:1.5rem}.appcore-description-list__title{display:block;font-weight:500;color:#111;margin-bottom:2.5rem}.appcore-description-list__items,.appcore-description-list__item{display:flex}.appcore-description-list--layout-vertical .appcore-description-list__items{flex-direction:column;gap:.5rem}.appcore-description-list--layout-horizontal .appcore-description-list__items{flex-direction:row;align-items:center;gap:1.5rem}.appcore-description-list--divider .appcore-description-list__item{padding-bottom:.5rem;border-bottom:1px solid rgb(204,204,204)}.appcore-description-list--divider .appcore-description-list__item:first-child{border-top:1px solid rgb(204,204,204);padding-top:.5rem}.appcore-description-list--size-S .appcore-description-list__title{font-size:14px;line-height:1.4}.appcore-description-list--size-M .appcore-description-list__title{font-size:16px;line-height:1.5}.appcore-description-list--size-L .appcore-description-list__title{font-size:18px;line-height:1.5}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: DescriptionItemComponent, selector: "appcore-description-item", inputs: ["label", "value", "size", "type", "showLabelIcon", "labelIcon", "showContentIcon1", "contentIcon1", "showContentIcon2", "contentIcon2", "showBadge", "badgeLabel", "showPrefixAvatar", "prefixAvatarLabel", "showContentAvatar", "contentAvatarLabel", "showSuffixAvatar", "suffixAvatarLabel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DescriptionListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-description-list', standalone: true, imports: [CommonModule, DescriptionItemComponent], template: `
    <div
      class="appcore-description-list"
      [ngClass]="[
        'appcore-description-list--layout-' + layout,
        'appcore-description-list--size-' + size,
        divider ? 'appcore-description-list--divider' : ''
      ]"
    >
      <span *ngIf="title" class="appcore-description-list__title">{{ title }}</span>

      <div class="appcore-description-list__items">
        <div *ngFor="let item of items" class="appcore-description-list__item">
          <appcore-description-item
            [label]="item.label"
            [value]="item.value"
            [size]="item.size || size"
            [type]="item.type || itemType"
            [showLabelIcon]="item.showLabelIcon || false"
            [labelIcon]="item.labelIcon || 'info'"
            [showContentIcon1]="item.showContentIcon1 || false"
            [contentIcon1]="item.contentIcon1 || 'open_in_new'"
            [showContentIcon2]="item.showContentIcon2 || false"
            [contentIcon2]="item.contentIcon2 || 'content_copy'"
            [showBadge]="item.showBadge || false"
            [badgeLabel]="item.badgeLabel || ''"
            [showPrefixAvatar]="item.showPrefixAvatar || false"
            [prefixAvatarLabel]="item.prefixAvatarLabel || 'KS'"
            [showContentAvatar]="item.showContentAvatar || false"
            [contentAvatarLabel]="item.contentAvatarLabel || 'KS'"
            [showSuffixAvatar]="item.showSuffixAvatar || false"
            [suffixAvatarLabel]="item.suffixAvatarLabel || 'KS'"
          ></appcore-description-item>
        </div>
      </div>
    </div>
  `, styles: [".appcore-description-list{display:flex;flex-direction:column;font-family:Inter,sans-serif;box-sizing:border-box;padding:1.5rem}.appcore-description-list__title{display:block;font-weight:500;color:#111;margin-bottom:2.5rem}.appcore-description-list__items,.appcore-description-list__item{display:flex}.appcore-description-list--layout-vertical .appcore-description-list__items{flex-direction:column;gap:.5rem}.appcore-description-list--layout-horizontal .appcore-description-list__items{flex-direction:row;align-items:center;gap:1.5rem}.appcore-description-list--divider .appcore-description-list__item{padding-bottom:.5rem;border-bottom:1px solid rgb(204,204,204)}.appcore-description-list--divider .appcore-description-list__item:first-child{border-top:1px solid rgb(204,204,204);padding-top:.5rem}.appcore-description-list--size-S .appcore-description-list__title{font-size:14px;line-height:1.4}.appcore-description-list--size-M .appcore-description-list__title{font-size:16px;line-height:1.5}.appcore-description-list--size-L .appcore-description-list__title{font-size:18px;line-height:1.5}\n"] }]
        }], propDecorators: { items: [{
                type: Input
            }], layout: [{
                type: Input
            }], itemType: [{
                type: Input
            }], size: [{
                type: Input
            }], title: [{
                type: Input
            }], divider: [{
                type: Input
            }] } });

class DialogueBoxComponent {
    constructor() {
        this.visible = true;
        this.state = 'Default';
        this.size = 'M';
        this.label = 'Label';
        this.description = 'Description';
        this.cancelLabel = 'Cancel';
        this.confirmLabel = 'Button';
        this.closeOnOverlayClick = false;
        this.close = new EventEmitter();
        this.cancel = new EventEmitter();
        this.confirm = new EventEmitter();
    }
    get stateIcon() {
        switch (this.state) {
            case 'Success': return 'check_circle';
            case 'Warning': return 'warning';
            case 'Error': return 'error';
            default: return 'info';
        }
    }
    onOverlayClick() {
        if (this.closeOnOverlayClick) {
            this.close.emit();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DialogueBoxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: DialogueBoxComponent, isStandalone: true, selector: "appcore-dialogue-box", inputs: { visible: "visible", state: "state", size: "size", label: "label", description: "description", cancelLabel: "cancelLabel", confirmLabel: "confirmLabel", closeOnOverlayClick: "closeOnOverlayClick" }, outputs: { close: "close", cancel: "cancel", confirm: "confirm" }, ngImport: i0, template: `
    <div class="appcore-dialogue-box" [class.appcore-dialogue-box--visible]="visible">
      <!-- Overlay -->
      <div class="appcore-dialogue-box__overlay" (click)="onOverlayClick()"></div>

      <!-- Modal -->
      <div
        class="appcore-dialogue-box__modal"
        [ngClass]="'appcore-dialogue-box__modal--' + size"
        role="dialog"
        aria-modal="true"
      >
        <!-- Content -->
        <div class="appcore-dialogue-box__content">
          <!-- Header -->
          <div class="appcore-dialogue-box__header">
            <div class="appcore-dialogue-box__title">
              <!-- Avatar / State Icon -->
              <div
                class="appcore-dialogue-box__avatar"
                [ngClass]="'appcore-dialogue-box__avatar--' + state"
              >
                <app-icon
                  *ngIf="state !== 'Default'"
                  [icon]="stateIcon"
                  iconSet="material"
                  size="md"
                ></app-icon>
              </div>

              <!-- Label + Description -->
              <div class="appcore-dialogue-box__title-content">
                <div class="appcore-dialogue-box__text">
                  <span class="appcore-dialogue-box__label">{{ label }}</span>
                  <span *ngIf="description" class="appcore-dialogue-box__description">{{ description }}</span>
                </div>
              </div>
            </div>

            <!-- Close button -->
            <button
              type="button"
              class="appcore-dialogue-box__close"
              (click)="close.emit()"
              aria-label="Close"
            >
              <app-icon icon="close" iconSet="material" size="sm"></app-icon>
            </button>
          </div>

          <!-- Body slot -->
          <div class="appcore-dialogue-box__body">
            <ng-content></ng-content>
          </div>
        </div>

        <!-- CTAs footer -->
        <div class="appcore-dialogue-box__ctas">
          <div class="appcore-dialogue-box__button-set">
            <appcore-button
              type="secondary"
              size="small"
              [label]="cancelLabel"
              (click)="cancel.emit()"
            ></appcore-button>
            <appcore-button
              type="primary"
              size="small"
              [label]="confirmLabel"
              (click)="confirm.emit()"
            ></appcore-button>
          </div>
        </div>
      </div>
    </div>
  `, isInline: true, styles: [".appcore-dialogue-box{display:none;position:fixed;inset:0;z-index:1000}.appcore-dialogue-box--visible{display:block}.appcore-dialogue-box__overlay{position:absolute;inset:0;background-color:#1119}.appcore-dialogue-box__modal{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:640px;background-color:#fff;border-radius:.5rem;display:flex;flex-direction:column;overflow:hidden}.appcore-dialogue-box__modal--S{height:200px}.appcore-dialogue-box__modal--M{height:360px}.appcore-dialogue-box__modal--L{height:480px}.appcore-dialogue-box__modal--XL{height:640px}.appcore-dialogue-box__content{display:flex;flex-direction:column;align-items:stretch;gap:.5rem;padding:1rem;flex:1;overflow:hidden}.appcore-dialogue-box__header{display:flex;flex-direction:row;justify-content:space-between;align-items:flex-start;width:100%}.appcore-dialogue-box__title{display:flex;flex-direction:row;align-items:flex-start;gap:1.5rem;flex:1}.appcore-dialogue-box__avatar{width:40px;height:40px;border-radius:100px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background-color:#e7eef3}.appcore-dialogue-box__avatar ::ng-deep .material-symbols-rounded{font-size:20px}.appcore-dialogue-box__avatar--Default{background-color:#e7eef3}.appcore-dialogue-box__avatar--Success{background-color:#efe}.appcore-dialogue-box__avatar--Success ::ng-deep .material-symbols-rounded{color:#238823}.appcore-dialogue-box__avatar--Warning{background-color:#fff7e0}.appcore-dialogue-box__avatar--Warning ::ng-deep .material-symbols-rounded{color:#ffbf00}.appcore-dialogue-box__avatar--Error{background-color:#ffeeef}.appcore-dialogue-box__avatar--Error ::ng-deep .material-symbols-rounded{color:#d2222d}.appcore-dialogue-box__title-content{display:flex;flex-direction:column;flex:1;gap:4rem}.appcore-dialogue-box__text{display:flex;flex-direction:column;gap:.25rem}.appcore-dialogue-box__label{font-family:Inter,sans-serif;font-size:16px;font-weight:500;line-height:1.25em;color:#3d3d3d}.appcore-dialogue-box__description{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.4285em;color:#3d3d3d}.appcore-dialogue-box__close{flex-shrink:0;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;border:none;background:transparent;cursor:pointer;padding:0;border-radius:.25rem;color:#525252}.appcore-dialogue-box__close:hover{background-color:#ebebeb}.appcore-dialogue-box__close ::ng-deep .material-symbols-rounded{font-size:16px;color:#525252!important}.appcore-dialogue-box__body{flex:1;overflow-y:auto}.appcore-dialogue-box__ctas{display:flex;flex-direction:row;justify-content:flex-end;align-items:center;padding:1rem .75rem;gap:4rem;border-top:1px solid rgb(204,204,204);background-color:#fff;border-radius:0 0 .5rem .5rem}.appcore-dialogue-box__button-set{display:flex;flex-direction:row;gap:.5rem}.appcore-dialogue-box__button-set ::ng-deep .appcore-button{width:120px;min-width:120px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }, { kind: "component", type: ButtonComponent, selector: "appcore-button", inputs: ["buttonText", "label", "size", "state", "type", "nativeType", "showLeftIcon", "showRightIcon", "leftIconName", "rightIconName", "leftIconSet", "rightIconSet", "leftIconSrc", "rightIconSrc"], outputs: ["buttonClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: DialogueBoxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-dialogue-box', standalone: true, imports: [CommonModule, IconComponent, ButtonComponent], template: `
    <div class="appcore-dialogue-box" [class.appcore-dialogue-box--visible]="visible">
      <!-- Overlay -->
      <div class="appcore-dialogue-box__overlay" (click)="onOverlayClick()"></div>

      <!-- Modal -->
      <div
        class="appcore-dialogue-box__modal"
        [ngClass]="'appcore-dialogue-box__modal--' + size"
        role="dialog"
        aria-modal="true"
      >
        <!-- Content -->
        <div class="appcore-dialogue-box__content">
          <!-- Header -->
          <div class="appcore-dialogue-box__header">
            <div class="appcore-dialogue-box__title">
              <!-- Avatar / State Icon -->
              <div
                class="appcore-dialogue-box__avatar"
                [ngClass]="'appcore-dialogue-box__avatar--' + state"
              >
                <app-icon
                  *ngIf="state !== 'Default'"
                  [icon]="stateIcon"
                  iconSet="material"
                  size="md"
                ></app-icon>
              </div>

              <!-- Label + Description -->
              <div class="appcore-dialogue-box__title-content">
                <div class="appcore-dialogue-box__text">
                  <span class="appcore-dialogue-box__label">{{ label }}</span>
                  <span *ngIf="description" class="appcore-dialogue-box__description">{{ description }}</span>
                </div>
              </div>
            </div>

            <!-- Close button -->
            <button
              type="button"
              class="appcore-dialogue-box__close"
              (click)="close.emit()"
              aria-label="Close"
            >
              <app-icon icon="close" iconSet="material" size="sm"></app-icon>
            </button>
          </div>

          <!-- Body slot -->
          <div class="appcore-dialogue-box__body">
            <ng-content></ng-content>
          </div>
        </div>

        <!-- CTAs footer -->
        <div class="appcore-dialogue-box__ctas">
          <div class="appcore-dialogue-box__button-set">
            <appcore-button
              type="secondary"
              size="small"
              [label]="cancelLabel"
              (click)="cancel.emit()"
            ></appcore-button>
            <appcore-button
              type="primary"
              size="small"
              [label]="confirmLabel"
              (click)="confirm.emit()"
            ></appcore-button>
          </div>
        </div>
      </div>
    </div>
  `, styles: [".appcore-dialogue-box{display:none;position:fixed;inset:0;z-index:1000}.appcore-dialogue-box--visible{display:block}.appcore-dialogue-box__overlay{position:absolute;inset:0;background-color:#1119}.appcore-dialogue-box__modal{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:640px;background-color:#fff;border-radius:.5rem;display:flex;flex-direction:column;overflow:hidden}.appcore-dialogue-box__modal--S{height:200px}.appcore-dialogue-box__modal--M{height:360px}.appcore-dialogue-box__modal--L{height:480px}.appcore-dialogue-box__modal--XL{height:640px}.appcore-dialogue-box__content{display:flex;flex-direction:column;align-items:stretch;gap:.5rem;padding:1rem;flex:1;overflow:hidden}.appcore-dialogue-box__header{display:flex;flex-direction:row;justify-content:space-between;align-items:flex-start;width:100%}.appcore-dialogue-box__title{display:flex;flex-direction:row;align-items:flex-start;gap:1.5rem;flex:1}.appcore-dialogue-box__avatar{width:40px;height:40px;border-radius:100px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background-color:#e7eef3}.appcore-dialogue-box__avatar ::ng-deep .material-symbols-rounded{font-size:20px}.appcore-dialogue-box__avatar--Default{background-color:#e7eef3}.appcore-dialogue-box__avatar--Success{background-color:#efe}.appcore-dialogue-box__avatar--Success ::ng-deep .material-symbols-rounded{color:#238823}.appcore-dialogue-box__avatar--Warning{background-color:#fff7e0}.appcore-dialogue-box__avatar--Warning ::ng-deep .material-symbols-rounded{color:#ffbf00}.appcore-dialogue-box__avatar--Error{background-color:#ffeeef}.appcore-dialogue-box__avatar--Error ::ng-deep .material-symbols-rounded{color:#d2222d}.appcore-dialogue-box__title-content{display:flex;flex-direction:column;flex:1;gap:4rem}.appcore-dialogue-box__text{display:flex;flex-direction:column;gap:.25rem}.appcore-dialogue-box__label{font-family:Inter,sans-serif;font-size:16px;font-weight:500;line-height:1.25em;color:#3d3d3d}.appcore-dialogue-box__description{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.4285em;color:#3d3d3d}.appcore-dialogue-box__close{flex-shrink:0;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;border:none;background:transparent;cursor:pointer;padding:0;border-radius:.25rem;color:#525252}.appcore-dialogue-box__close:hover{background-color:#ebebeb}.appcore-dialogue-box__close ::ng-deep .material-symbols-rounded{font-size:16px;color:#525252!important}.appcore-dialogue-box__body{flex:1;overflow-y:auto}.appcore-dialogue-box__ctas{display:flex;flex-direction:row;justify-content:flex-end;align-items:center;padding:1rem .75rem;gap:4rem;border-top:1px solid rgb(204,204,204);background-color:#fff;border-radius:0 0 .5rem .5rem}.appcore-dialogue-box__button-set{display:flex;flex-direction:row;gap:.5rem}.appcore-dialogue-box__button-set ::ng-deep .appcore-button{width:120px;min-width:120px}\n"] }]
        }], propDecorators: { visible: [{
                type: Input
            }], state: [{
                type: Input
            }], size: [{
                type: Input
            }], label: [{
                type: Input
            }], description: [{
                type: Input
            }], cancelLabel: [{
                type: Input
            }], confirmLabel: [{
                type: Input
            }], closeOnOverlayClick: [{
                type: Input
            }], close: [{
                type: Output
            }], cancel: [{
                type: Output
            }], confirm: [{
                type: Output
            }] } });

const DEFAULT_TC_LINKS = [
    'Terms & Conditions',
    'Privacy Statements',
    'Data Processing',
    'Legal Entities',
    'Accessibility',
    'Do Not Share My Personal Data',
    'Cookie Settings',
];
const DEFAULT_WLMP_MENU_LINKS = [
    'About Us', 'Services', 'Solutions', 'Contact Us', 'Blog',
];
class FooterComponent {
    constructor() {
        this.platform = 'TC';
        this.tcLinks = [...DEFAULT_TC_LINKS];
        this.wlmpMenuLinks = [...DEFAULT_WLMP_MENU_LINKS];
        this.tagline = 'We provide the tools, resources and people to simplify the delivery of cloud solutions.';
        this.contactEmail = 'sales@techdata.com';
        this.copyrightText = '⓪ Tech Data Corporation, 2021 Tech Data and Tech Data logo are registered trademarks of Tech Data Corporation in the United States and Other countries. All other trademarks are the property of their respective owners.';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: FooterComponent, isStandalone: true, selector: "app-footer", inputs: { platform: "platform", tcLinks: "tcLinks", wlmpMenuLinks: "wlmpMenuLinks", tagline: "tagline", contactEmail: "contactEmail", copyrightText: "copyrightText" }, ngImport: i0, template: `
    <!-- ===== T&C PLATFORM ===== -->
    <footer *ngIf="platform === 'TC'" class="footer footer--tc">
      <span class="footer__tc-brand">TD SYNNEX</span>
      <ng-container *ngFor="let link of tcLinks; let last = last">
        <span class="footer__separator">|</span>
        <a class="footer__tc-link" href="#">{{ link }}</a>
      </ng-container>
    </footer>

    <!-- ===== WLMP PLATFORM ===== -->
    <footer *ngIf="platform === 'WLMP'" class="footer footer--wlmp">
      <div class="footer__wlmp-top">
        <div class="footer__wlmp-top-row">
          <div class="footer__wlmp-logo">
            <span class="footer__logo-wordmark">StreamOne Ion</span>
          </div>
          <p class="footer__tagline">{{ tagline }}</p>
          <div class="footer__contact">
            <span class="material-symbols-rounded footer__contact-icon">mail</span>
            <span class="footer__contact-email">{{ contactEmail }}</span>
          </div>
        </div>
        <nav class="footer__wlmp-menu">
          <a *ngFor="let link of wlmpMenuLinks" class="footer__wlmp-menu-link" href="#">{{ link }}</a>
        </nav>
      </div>
      <p class="footer__copyright">{{ copyrightText }}</p>
    </footer>
  `, isInline: true, styles: [".footer{font-family:Inter,sans-serif;width:100%;box-sizing:border-box}.footer--tc{display:flex;flex-direction:row;justify-content:center;align-items:center;flex-wrap:wrap;gap:8px;padding:11px 24px;background-color:#f5f5f5}.footer__tc-brand{font-size:14px;font-weight:400;color:#0c558c;white-space:nowrap}.footer__separator{font-size:14px;font-weight:400;color:#0c558c}.footer__tc-link{font-size:14px;font-weight:400;color:#0c558c;text-decoration:none;white-space:nowrap;cursor:pointer}.footer__tc-link:hover{text-decoration:underline}.footer--wlmp{display:flex;flex-direction:column;align-items:stretch;gap:8px;padding-bottom:8px;background-color:#fff}.footer__wlmp-top{display:flex;flex-direction:column;align-items:center;gap:24px;padding:32px 24px;background-color:#3674b2;width:100%;box-sizing:border-box}.footer__wlmp-top-row{display:flex;flex-direction:row;justify-content:space-between;align-items:center;width:100%;gap:32px}.footer__wlmp-logo{flex-shrink:0}.footer__logo-wordmark{font-family:Inter,sans-serif;font-size:18px;font-weight:700;color:#fff;letter-spacing:-.5px;white-space:nowrap}.footer__tagline{font-size:14px;font-weight:500;color:#fff;line-height:1.286em;margin:0;flex:1;text-align:center}.footer__contact{display:flex;flex-direction:row;align-items:center;justify-content:center;gap:8px;flex-shrink:0}.footer__contact-icon{font-size:32px;color:#fff}.footer__contact-email{font-size:14px;font-weight:400;color:#fff;line-height:1.286em}.footer__wlmp-menu{display:flex;flex-direction:row;align-items:center;gap:40px}.footer__wlmp-menu-link{font-size:14px;font-weight:400;color:#fff;text-decoration:none;line-height:1.286em;cursor:pointer}.footer__wlmp-menu-link:hover{text-decoration:underline}.footer__copyright{font-size:12px;font-weight:400;color:#3d3d3d;line-height:1.333em;text-align:center;margin:0;padding:0 24px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatIconModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-footer', standalone: true, imports: [CommonModule, MatIconModule], template: `
    <!-- ===== T&C PLATFORM ===== -->
    <footer *ngIf="platform === 'TC'" class="footer footer--tc">
      <span class="footer__tc-brand">TD SYNNEX</span>
      <ng-container *ngFor="let link of tcLinks; let last = last">
        <span class="footer__separator">|</span>
        <a class="footer__tc-link" href="#">{{ link }}</a>
      </ng-container>
    </footer>

    <!-- ===== WLMP PLATFORM ===== -->
    <footer *ngIf="platform === 'WLMP'" class="footer footer--wlmp">
      <div class="footer__wlmp-top">
        <div class="footer__wlmp-top-row">
          <div class="footer__wlmp-logo">
            <span class="footer__logo-wordmark">StreamOne Ion</span>
          </div>
          <p class="footer__tagline">{{ tagline }}</p>
          <div class="footer__contact">
            <span class="material-symbols-rounded footer__contact-icon">mail</span>
            <span class="footer__contact-email">{{ contactEmail }}</span>
          </div>
        </div>
        <nav class="footer__wlmp-menu">
          <a *ngFor="let link of wlmpMenuLinks" class="footer__wlmp-menu-link" href="#">{{ link }}</a>
        </nav>
      </div>
      <p class="footer__copyright">{{ copyrightText }}</p>
    </footer>
  `, styles: [".footer{font-family:Inter,sans-serif;width:100%;box-sizing:border-box}.footer--tc{display:flex;flex-direction:row;justify-content:center;align-items:center;flex-wrap:wrap;gap:8px;padding:11px 24px;background-color:#f5f5f5}.footer__tc-brand{font-size:14px;font-weight:400;color:#0c558c;white-space:nowrap}.footer__separator{font-size:14px;font-weight:400;color:#0c558c}.footer__tc-link{font-size:14px;font-weight:400;color:#0c558c;text-decoration:none;white-space:nowrap;cursor:pointer}.footer__tc-link:hover{text-decoration:underline}.footer--wlmp{display:flex;flex-direction:column;align-items:stretch;gap:8px;padding-bottom:8px;background-color:#fff}.footer__wlmp-top{display:flex;flex-direction:column;align-items:center;gap:24px;padding:32px 24px;background-color:#3674b2;width:100%;box-sizing:border-box}.footer__wlmp-top-row{display:flex;flex-direction:row;justify-content:space-between;align-items:center;width:100%;gap:32px}.footer__wlmp-logo{flex-shrink:0}.footer__logo-wordmark{font-family:Inter,sans-serif;font-size:18px;font-weight:700;color:#fff;letter-spacing:-.5px;white-space:nowrap}.footer__tagline{font-size:14px;font-weight:500;color:#fff;line-height:1.286em;margin:0;flex:1;text-align:center}.footer__contact{display:flex;flex-direction:row;align-items:center;justify-content:center;gap:8px;flex-shrink:0}.footer__contact-icon{font-size:32px;color:#fff}.footer__contact-email{font-size:14px;font-weight:400;color:#fff;line-height:1.286em}.footer__wlmp-menu{display:flex;flex-direction:row;align-items:center;gap:40px}.footer__wlmp-menu-link{font-size:14px;font-weight:400;color:#fff;text-decoration:none;line-height:1.286em;cursor:pointer}.footer__wlmp-menu-link:hover{text-decoration:underline}.footer__copyright{font-size:12px;font-weight:400;color:#3d3d3d;line-height:1.333em;text-align:center;margin:0;padding:0 24px}\n"] }]
        }], propDecorators: { platform: [{
                type: Input
            }], tcLinks: [{
                type: Input
            }], wlmpMenuLinks: [{
                type: Input
            }], tagline: [{
                type: Input
            }], contactEmail: [{
                type: Input
            }], copyrightText: [{
                type: Input
            }] } });

class HeaderComponent {
    constructor() {
        this.type = 'H1';
        this.title = 'Header Label';
        this.subtitle = 'Text';
        this.showBreadcrumb = false;
        this.showImage = false;
        this.showBackIcon = true;
        this.showLogo = false;
        this.showText = true;
        this.showBadge1 = false;
        this.showBadge2 = false;
        this.showBadge3 = false;
        this.showBadge4 = false;
        this.showSearch = false;
        this.showButtonSet = false;
        this.showComboButton = false;
        this.showActionBar = false;
        this.showIconButton1 = false;
        this.showIconButton2 = false;
        this.showIconButton3 = false;
        this.showAvatar = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: HeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: HeaderComponent, isStandalone: true, selector: "appcore-header", inputs: { type: "type", title: "title", subtitle: "subtitle", showBreadcrumb: "showBreadcrumb", showImage: "showImage", showBackIcon: "showBackIcon", showLogo: "showLogo", showText: "showText", showBadge1: "showBadge1", showBadge2: "showBadge2", showBadge3: "showBadge3", showBadge4: "showBadge4", showSearch: "showSearch", showButtonSet: "showButtonSet", showComboButton: "showComboButton", showActionBar: "showActionBar", showIconButton1: "showIconButton1", showIconButton2: "showIconButton2", showIconButton3: "showIconButton3", showAvatar: "showAvatar" }, ngImport: i0, template: `
    <div class="appcore-header" [ngClass]="'appcore-header--' + type.toLowerCase()">

      <!-- Back Icon -->
      <button *ngIf="showBackIcon" class="appcore-header__back-btn" aria-label="Back">
        <app-icon icon="chevron_left" iconSet="material" size="sm"></app-icon>
      </button>

      <!-- Logo slot -->
      <div *ngIf="showLogo" class="appcore-header__logo">
        <ng-content select="[logo]"></ng-content>
      </div>

      <!-- Image slot -->
      <div *ngIf="showImage" class="appcore-header__image">
        <ng-content select="[image]"></ng-content>
      </div>

      <!-- Main: Breadcrumb OR Title+Subtitle -->
      <div class="appcore-header__main">
        <div *ngIf="showBreadcrumb" class="appcore-header__breadcrumb">
          <ng-content select="[breadcrumb]"></ng-content>
        </div>
        <div *ngIf="showText" class="appcore-header__text">
          <div class="appcore-header__title-wrap">
            <span class="appcore-header__title">{{ title }}</span>
          </div>
          <span *ngIf="subtitle" class="appcore-header__subtitle">{{ subtitle }}</span>
        </div>
      </div>

      <!-- Right-side actions -->
      <div class="appcore-header__actions">
        <div *ngIf="showBadge1" class="appcore-header__slot">
          <ng-content select="[badge1]"></ng-content>
        </div>
        <div *ngIf="showBadge2" class="appcore-header__slot">
          <ng-content select="[badge2]"></ng-content>
        </div>
        <div *ngIf="showBadge3" class="appcore-header__slot">
          <ng-content select="[badge3]"></ng-content>
        </div>
        <div *ngIf="showBadge4" class="appcore-header__slot">
          <ng-content select="[badge4]"></ng-content>
        </div>
        <div *ngIf="showSearch" class="appcore-header__slot">
          <ng-content select="[search]"></ng-content>
        </div>
        <div *ngIf="showButtonSet" class="appcore-header__slot">
          <ng-content select="[buttonSet]"></ng-content>
        </div>
        <div *ngIf="showComboButton" class="appcore-header__slot">
          <ng-content select="[comboButton]"></ng-content>
        </div>
        <div *ngIf="showActionBar" class="appcore-header__slot">
          <ng-content select="[actionBar]"></ng-content>
        </div>
        <div *ngIf="showIconButton1" class="appcore-header__slot">
          <ng-content select="[iconButton1]"></ng-content>
        </div>
        <div *ngIf="showIconButton2" class="appcore-header__slot">
          <ng-content select="[iconButton2]"></ng-content>
        </div>
        <div *ngIf="showIconButton3" class="appcore-header__slot">
          <ng-content select="[iconButton3]"></ng-content>
        </div>
        <div *ngIf="showAvatar" class="appcore-header__slot">
          <ng-content select="[avatar]"></ng-content>
        </div>
      </div>

    </div>
  `, isInline: true, styles: [".appcore-header{display:flex;flex-direction:row;align-items:center;gap:12px;width:100%;background:#fff;font-family:Inter,sans-serif}.appcore-header__back-btn{display:flex;align-items:center;justify-content:center;flex-shrink:0;padding:0;background:none;border:none;cursor:pointer;color:#3d3d3d}.appcore-header__logo,.appcore-header__image{display:flex;align-items:center;flex-shrink:0}.appcore-header__main{display:flex;flex-direction:column;justify-content:flex-end;gap:4px;flex:1;min-width:0}.appcore-header__breadcrumb{display:flex;align-items:center}.appcore-header__text{display:flex;flex-direction:column;gap:4px}.appcore-header__title-wrap{display:flex;flex-direction:row;align-items:center;gap:8px}.appcore-header__title{color:#3d3d3d;text-transform:capitalize;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.appcore-header__subtitle{color:#525252;font-weight:400}.appcore-header__actions{display:flex;flex-direction:row;align-items:center;gap:8px;flex-shrink:0}.appcore-header__slot{display:flex;align-items:center}.appcore-header--h1 .appcore-header__title{font-size:24px;font-weight:600;line-height:1.333em}.appcore-header--h1 .appcore-header__subtitle{font-size:14px;line-height:1.286em}.appcore-header--h2 .appcore-header__title{font-size:20px;font-weight:600;line-height:1.4em}.appcore-header--h2 .appcore-header__subtitle{font-size:14px;line-height:1.286em}.appcore-header--h3 .appcore-header__title{font-size:16px;font-weight:600;line-height:1.5em}.appcore-header--h3 .appcore-header__subtitle{font-size:14px;line-height:1.286em}.appcore-header--h4 .appcore-header__title{font-size:14px;font-weight:600;line-height:1.429em}.appcore-header--h4 .appcore-header__subtitle{font-size:12px;line-height:1.333em}.appcore-header--h5 .appcore-header__title{font-size:12px;font-weight:500;line-height:1.333em}.appcore-header--h5 .appcore-header__subtitle{font-size:12px;line-height:1.333em}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: HeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-header', standalone: true, imports: [CommonModule, IconComponent], template: `
    <div class="appcore-header" [ngClass]="'appcore-header--' + type.toLowerCase()">

      <!-- Back Icon -->
      <button *ngIf="showBackIcon" class="appcore-header__back-btn" aria-label="Back">
        <app-icon icon="chevron_left" iconSet="material" size="sm"></app-icon>
      </button>

      <!-- Logo slot -->
      <div *ngIf="showLogo" class="appcore-header__logo">
        <ng-content select="[logo]"></ng-content>
      </div>

      <!-- Image slot -->
      <div *ngIf="showImage" class="appcore-header__image">
        <ng-content select="[image]"></ng-content>
      </div>

      <!-- Main: Breadcrumb OR Title+Subtitle -->
      <div class="appcore-header__main">
        <div *ngIf="showBreadcrumb" class="appcore-header__breadcrumb">
          <ng-content select="[breadcrumb]"></ng-content>
        </div>
        <div *ngIf="showText" class="appcore-header__text">
          <div class="appcore-header__title-wrap">
            <span class="appcore-header__title">{{ title }}</span>
          </div>
          <span *ngIf="subtitle" class="appcore-header__subtitle">{{ subtitle }}</span>
        </div>
      </div>

      <!-- Right-side actions -->
      <div class="appcore-header__actions">
        <div *ngIf="showBadge1" class="appcore-header__slot">
          <ng-content select="[badge1]"></ng-content>
        </div>
        <div *ngIf="showBadge2" class="appcore-header__slot">
          <ng-content select="[badge2]"></ng-content>
        </div>
        <div *ngIf="showBadge3" class="appcore-header__slot">
          <ng-content select="[badge3]"></ng-content>
        </div>
        <div *ngIf="showBadge4" class="appcore-header__slot">
          <ng-content select="[badge4]"></ng-content>
        </div>
        <div *ngIf="showSearch" class="appcore-header__slot">
          <ng-content select="[search]"></ng-content>
        </div>
        <div *ngIf="showButtonSet" class="appcore-header__slot">
          <ng-content select="[buttonSet]"></ng-content>
        </div>
        <div *ngIf="showComboButton" class="appcore-header__slot">
          <ng-content select="[comboButton]"></ng-content>
        </div>
        <div *ngIf="showActionBar" class="appcore-header__slot">
          <ng-content select="[actionBar]"></ng-content>
        </div>
        <div *ngIf="showIconButton1" class="appcore-header__slot">
          <ng-content select="[iconButton1]"></ng-content>
        </div>
        <div *ngIf="showIconButton2" class="appcore-header__slot">
          <ng-content select="[iconButton2]"></ng-content>
        </div>
        <div *ngIf="showIconButton3" class="appcore-header__slot">
          <ng-content select="[iconButton3]"></ng-content>
        </div>
        <div *ngIf="showAvatar" class="appcore-header__slot">
          <ng-content select="[avatar]"></ng-content>
        </div>
      </div>

    </div>
  `, styles: [".appcore-header{display:flex;flex-direction:row;align-items:center;gap:12px;width:100%;background:#fff;font-family:Inter,sans-serif}.appcore-header__back-btn{display:flex;align-items:center;justify-content:center;flex-shrink:0;padding:0;background:none;border:none;cursor:pointer;color:#3d3d3d}.appcore-header__logo,.appcore-header__image{display:flex;align-items:center;flex-shrink:0}.appcore-header__main{display:flex;flex-direction:column;justify-content:flex-end;gap:4px;flex:1;min-width:0}.appcore-header__breadcrumb{display:flex;align-items:center}.appcore-header__text{display:flex;flex-direction:column;gap:4px}.appcore-header__title-wrap{display:flex;flex-direction:row;align-items:center;gap:8px}.appcore-header__title{color:#3d3d3d;text-transform:capitalize;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.appcore-header__subtitle{color:#525252;font-weight:400}.appcore-header__actions{display:flex;flex-direction:row;align-items:center;gap:8px;flex-shrink:0}.appcore-header__slot{display:flex;align-items:center}.appcore-header--h1 .appcore-header__title{font-size:24px;font-weight:600;line-height:1.333em}.appcore-header--h1 .appcore-header__subtitle{font-size:14px;line-height:1.286em}.appcore-header--h2 .appcore-header__title{font-size:20px;font-weight:600;line-height:1.4em}.appcore-header--h2 .appcore-header__subtitle{font-size:14px;line-height:1.286em}.appcore-header--h3 .appcore-header__title{font-size:16px;font-weight:600;line-height:1.5em}.appcore-header--h3 .appcore-header__subtitle{font-size:14px;line-height:1.286em}.appcore-header--h4 .appcore-header__title{font-size:14px;font-weight:600;line-height:1.429em}.appcore-header--h4 .appcore-header__subtitle{font-size:12px;line-height:1.333em}.appcore-header--h5 .appcore-header__title{font-size:12px;font-weight:500;line-height:1.333em}.appcore-header--h5 .appcore-header__subtitle{font-size:12px;line-height:1.333em}\n"] }]
        }], propDecorators: { type: [{
                type: Input
            }], title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], showBreadcrumb: [{
                type: Input
            }], showImage: [{
                type: Input
            }], showBackIcon: [{
                type: Input
            }], showLogo: [{
                type: Input
            }], showText: [{
                type: Input
            }], showBadge1: [{
                type: Input
            }], showBadge2: [{
                type: Input
            }], showBadge3: [{
                type: Input
            }], showBadge4: [{
                type: Input
            }], showSearch: [{
                type: Input
            }], showButtonSet: [{
                type: Input
            }], showComboButton: [{
                type: Input
            }], showActionBar: [{
                type: Input
            }], showIconButton1: [{
                type: Input
            }], showIconButton2: [{
                type: Input
            }], showIconButton3: [{
                type: Input
            }], showAvatar: [{
                type: Input
            }] } });

class ContentLoaderDotsComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ContentLoaderDotsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: ContentLoaderDotsComponent, isStandalone: true, selector: "appcore-content-loader-dots", ngImport: i0, template: `
    <div class="appcore-dots-loader" role="status" aria-label="Loading">
      <span class="appcore-dots-loader__dot appcore-dots-loader__dot--1"></span>
      <span class="appcore-dots-loader__dot appcore-dots-loader__dot--2"></span>
      <span class="appcore-dots-loader__dot appcore-dots-loader__dot--3"></span>
      <span class="appcore-dots-loader__dot appcore-dots-loader__dot--4"></span>
    </div>
  `, isInline: true, styles: ["@keyframes appcore-dot-pulse{0%,to{width:8px;height:8px;background-color:#cedde8}50%{width:12px;height:12px;background-color:#0c558c}}.appcore-dots-loader{display:inline-flex;align-items:center;gap:4px;padding:16px}.appcore-dots-loader__dot{display:block;width:8px;height:8px;border-radius:50%;background-color:#cedde8;animation:appcore-dot-pulse 1.2s ease-in-out infinite}.appcore-dots-loader__dot--1{animation-delay:0s}.appcore-dots-loader__dot--2{animation-delay:.2s}.appcore-dots-loader__dot--3{animation-delay:.4s}.appcore-dots-loader__dot--4{animation-delay:.6s}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ContentLoaderDotsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-content-loader-dots', standalone: true, imports: [CommonModule], template: `
    <div class="appcore-dots-loader" role="status" aria-label="Loading">
      <span class="appcore-dots-loader__dot appcore-dots-loader__dot--1"></span>
      <span class="appcore-dots-loader__dot appcore-dots-loader__dot--2"></span>
      <span class="appcore-dots-loader__dot appcore-dots-loader__dot--3"></span>
      <span class="appcore-dots-loader__dot appcore-dots-loader__dot--4"></span>
    </div>
  `, styles: ["@keyframes appcore-dot-pulse{0%,to{width:8px;height:8px;background-color:#cedde8}50%{width:12px;height:12px;background-color:#0c558c}}.appcore-dots-loader{display:inline-flex;align-items:center;gap:4px;padding:16px}.appcore-dots-loader__dot{display:block;width:8px;height:8px;border-radius:50%;background-color:#cedde8;animation:appcore-dot-pulse 1.2s ease-in-out infinite}.appcore-dots-loader__dot--1{animation-delay:0s}.appcore-dots-loader__dot--2{animation-delay:.2s}.appcore-dots-loader__dot--3{animation-delay:.4s}.appcore-dots-loader__dot--4{animation-delay:.6s}\n"] }]
        }] });

class InlineLoaderComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: InlineLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: InlineLoaderComponent, isStandalone: true, selector: "appcore-inline-loader", ngImport: i0, template: `
    <span class="appcore-inline-loader" role="status" aria-label="Loading">
      <span class="appcore-inline-loader__track"></span>
      <span class="appcore-inline-loader__arc"></span>
    </span>
  `, isInline: true, styles: ["@keyframes appcore-spin{to{transform:rotate(360deg)}}.appcore-inline-loader{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;position:relative;padding:2px}.appcore-inline-loader__track{position:absolute;width:20px;height:20px;border-radius:50%;background-color:#f5f5f5}.appcore-inline-loader__arc{position:absolute;width:20px;height:20px;border-radius:50%;border:3px solid rgb(206,221,232);border-top-color:#0c558c;animation:appcore-spin .8s linear infinite}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: InlineLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-inline-loader', standalone: true, template: `
    <span class="appcore-inline-loader" role="status" aria-label="Loading">
      <span class="appcore-inline-loader__track"></span>
      <span class="appcore-inline-loader__arc"></span>
    </span>
  `, styles: ["@keyframes appcore-spin{to{transform:rotate(360deg)}}.appcore-inline-loader{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;position:relative;padding:2px}.appcore-inline-loader__track{position:absolute;width:20px;height:20px;border-radius:50%;background-color:#f5f5f5}.appcore-inline-loader__arc{position:absolute;width:20px;height:20px;border-radius:50%;border:3px solid rgb(206,221,232);border-top-color:#0c558c;animation:appcore-spin .8s linear infinite}\n"] }]
        }] });

class InlineLoaderWithTextComponent {
    constructor() {
        this.state = 'Active';
        this.label = 'Label';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: InlineLoaderWithTextComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: InlineLoaderWithTextComponent, isStandalone: true, selector: "appcore-inline-loader-with-text", inputs: { state: "state", label: "label" }, ngImport: i0, template: `
    <span class="appcore-inline-loader-text" [ngClass]="'appcore-inline-loader-text--' + state" role="status">
      <!-- Active: spinner -->
      <appcore-inline-loader *ngIf="state === 'Active'"></appcore-inline-loader>

      <!-- Success: check_circle icon -->
      <span *ngIf="state === 'Success'" class="appcore-inline-loader-text__icon appcore-inline-loader-text__icon--success">
        <span class="material-symbols-rounded">check_circle</span>
      </span>

      <!-- Error: error icon -->
      <span *ngIf="state === 'Error'" class="appcore-inline-loader-text__icon appcore-inline-loader-text__icon--error">
        <span class="material-symbols-rounded">error</span>
      </span>

      <span class="appcore-inline-loader-text__label">{{ label }}</span>
    </span>
  `, isInline: true, styles: [".appcore-inline-loader-text{display:inline-flex;align-items:center;gap:4px}.appcore-inline-loader-text__label{font-family:Inter,sans-serif;font-weight:400;font-size:14px;line-height:18px;color:#3d3d3d}.appcore-inline-loader-text__icon{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px}.appcore-inline-loader-text__icon .material-symbols-rounded{font-size:24px}.appcore-inline-loader-text__icon--success .material-symbols-rounded{color:#238823}.appcore-inline-loader-text__icon--error .material-symbols-rounded{color:#d2222d}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: InlineLoaderComponent, selector: "appcore-inline-loader" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: InlineLoaderWithTextComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-inline-loader-with-text', standalone: true, imports: [CommonModule, InlineLoaderComponent], template: `
    <span class="appcore-inline-loader-text" [ngClass]="'appcore-inline-loader-text--' + state" role="status">
      <!-- Active: spinner -->
      <appcore-inline-loader *ngIf="state === 'Active'"></appcore-inline-loader>

      <!-- Success: check_circle icon -->
      <span *ngIf="state === 'Success'" class="appcore-inline-loader-text__icon appcore-inline-loader-text__icon--success">
        <span class="material-symbols-rounded">check_circle</span>
      </span>

      <!-- Error: error icon -->
      <span *ngIf="state === 'Error'" class="appcore-inline-loader-text__icon appcore-inline-loader-text__icon--error">
        <span class="material-symbols-rounded">error</span>
      </span>

      <span class="appcore-inline-loader-text__label">{{ label }}</span>
    </span>
  `, styles: [".appcore-inline-loader-text{display:inline-flex;align-items:center;gap:4px}.appcore-inline-loader-text__label{font-family:Inter,sans-serif;font-weight:400;font-size:14px;line-height:18px;color:#3d3d3d}.appcore-inline-loader-text__icon{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px}.appcore-inline-loader-text__icon .material-symbols-rounded{font-size:24px}.appcore-inline-loader-text__icon--success .material-symbols-rounded{color:#238823}.appcore-inline-loader-text__icon--error .material-symbols-rounded{color:#d2222d}\n"] }]
        }], propDecorators: { state: [{
                type: Input
            }], label: [{
                type: Input
            }] } });

class OverlayComponent {
    constructor() {
        this.visible = true;
        this.type = 'Light';
        this.overlayClick = new EventEmitter();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: OverlayComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: OverlayComponent, isStandalone: true, selector: "appcore-overlay", inputs: { visible: "visible", type: "type" }, outputs: { overlayClick: "overlayClick" }, ngImport: i0, template: `
    <div
      class="appcore-overlay"
      [class.appcore-overlay--visible]="visible"
      [ngClass]="'appcore-overlay--' + type"
      role="presentation"
      (click)="overlayClick.emit()"
    ></div>
  `, isInline: true, styles: [".appcore-overlay{display:none;position:fixed;inset:0;z-index:900}.appcore-overlay--visible{display:block}.appcore-overlay--Light{background-color:#1116}.appcore-overlay--Dark{background-color:#111111b3}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: OverlayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-overlay', standalone: true, imports: [CommonModule], template: `
    <div
      class="appcore-overlay"
      [class.appcore-overlay--visible]="visible"
      [ngClass]="'appcore-overlay--' + type"
      role="presentation"
      (click)="overlayClick.emit()"
    ></div>
  `, styles: [".appcore-overlay{display:none;position:fixed;inset:0;z-index:900}.appcore-overlay--visible{display:block}.appcore-overlay--Light{background-color:#1116}.appcore-overlay--Dark{background-color:#111111b3}\n"] }]
        }], propDecorators: { visible: [{
                type: Input
            }], type: [{
                type: Input
            }], overlayClick: [{
                type: Output
            }] } });

class PageLoaderComponent {
    constructor() {
        this.visible = true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: PageLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: PageLoaderComponent, isStandalone: true, selector: "appcore-page-loader", inputs: { visible: "visible" }, ngImport: i0, template: `
    <div class="appcore-page-loader" [class.appcore-page-loader--visible]="visible" role="status" aria-label="Loading">
      <div class="appcore-page-loader__backdrop"></div>
      <div class="appcore-page-loader__spinner">
        <div class="appcore-page-loader__track"></div>
        <div class="appcore-page-loader__arc"></div>
      </div>
    </div>
  `, isInline: true, styles: ["@keyframes appcore-spin{to{transform:rotate(360deg)}}.appcore-page-loader{display:none;position:fixed;inset:0;z-index:1000;align-items:center;justify-content:center}.appcore-page-loader--visible{display:flex}.appcore-page-loader__backdrop{position:absolute;inset:0;background-color:#11111180}.appcore-page-loader__spinner{position:relative;width:96px;height:96px;display:flex;align-items:center;justify-content:center;z-index:1}.appcore-page-loader__track{position:absolute;width:80px;height:80px;border-radius:50%;background-color:#fff}.appcore-page-loader__arc{position:absolute;width:80px;height:80px;border-radius:50%;border:8px solid rgb(206,221,232);border-top-color:#0c558c;animation:appcore-spin .8s linear infinite}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: PageLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-page-loader', standalone: true, imports: [CommonModule], template: `
    <div class="appcore-page-loader" [class.appcore-page-loader--visible]="visible" role="status" aria-label="Loading">
      <div class="appcore-page-loader__backdrop"></div>
      <div class="appcore-page-loader__spinner">
        <div class="appcore-page-loader__track"></div>
        <div class="appcore-page-loader__arc"></div>
      </div>
    </div>
  `, styles: ["@keyframes appcore-spin{to{transform:rotate(360deg)}}.appcore-page-loader{display:none;position:fixed;inset:0;z-index:1000;align-items:center;justify-content:center}.appcore-page-loader--visible{display:flex}.appcore-page-loader__backdrop{position:absolute;inset:0;background-color:#11111180}.appcore-page-loader__spinner{position:relative;width:96px;height:96px;display:flex;align-items:center;justify-content:center;z-index:1}.appcore-page-loader__track{position:absolute;width:80px;height:80px;border-radius:50%;background-color:#fff}.appcore-page-loader__arc{position:absolute;width:80px;height:80px;border-radius:50%;border:8px solid rgb(206,221,232);border-top-color:#0c558c;animation:appcore-spin .8s linear infinite}\n"] }]
        }], propDecorators: { visible: [{
                type: Input
            }] } });

class ModalComponent {
    constructor() {
        this.visible = true;
        this.size = 'S';
        this.title = 'Header Label';
        this.subtitle = 'Text';
        this.cancelLabel = 'Cancel';
        this.confirmLabel = 'Confirm';
        this.closeOnOverlayClick = false;
        this.close = new EventEmitter();
        this.cancel = new EventEmitter();
        this.confirm = new EventEmitter();
    }
    onOverlayClick() {
        if (this.closeOnOverlayClick) {
            this.close.emit();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: ModalComponent, isStandalone: true, selector: "appcore-modal", inputs: { visible: "visible", size: "size", title: "title", subtitle: "subtitle", cancelLabel: "cancelLabel", confirmLabel: "confirmLabel", closeOnOverlayClick: "closeOnOverlayClick" }, outputs: { close: "close", cancel: "cancel", confirm: "confirm" }, ngImport: i0, template: `
    <div class="appcore-modal" [class.appcore-modal--visible]="visible">
      <!-- Overlay -->
      <div class="appcore-modal__overlay" (click)="onOverlayClick()"></div>

      <!-- Modal panel -->
      <div
        class="appcore-modal__panel"
        [ngClass]="'appcore-modal__panel--' + size"
        role="dialog"
        aria-modal="true"
        [attr.aria-labelledby]="'modal-title'"
      >
        <!-- Content wrapper (header + body) -->
        <div class="appcore-modal__content">
          <!-- Header -->
          <div class="appcore-modal__header">
            <div class="appcore-modal__title-group">
              <span class="appcore-modal__title" id="modal-title">{{ title }}</span>
              <span *ngIf="subtitle" class="appcore-modal__subtitle">{{ subtitle }}</span>
            </div>

            <button
              type="button"
              class="appcore-modal__close"
              (click)="close.emit()"
              aria-label="Close modal"
            >
              <app-icon icon="close" iconSet="material" size="sm"></app-icon>
            </button>
          </div>

          <!-- Body slot -->
          <div class="appcore-modal__body">
            <ng-content></ng-content>
          </div>
        </div>

        <!-- Footer CTAs -->
        <div class="appcore-modal__footer">
          <div class="appcore-modal__button-set">
            <appcore-button
              type="secondary"
              size="small"
              [label]="cancelLabel"
              (click)="cancel.emit()"
            ></appcore-button>
            <appcore-button
              type="primary"
              size="small"
              [label]="confirmLabel"
              (click)="confirm.emit()"
            ></appcore-button>
          </div>
        </div>
      </div>
    </div>
  `, isInline: true, styles: [".appcore-modal{display:none;position:fixed;inset:0;z-index:1000}.appcore-modal--visible{display:block}.appcore-modal__overlay{position:absolute;inset:0;background-color:#1119}.appcore-modal__panel{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);background-color:#fff;border-radius:.5rem;display:flex;flex-direction:column;justify-content:space-between;overflow:hidden}.appcore-modal__panel--S{width:640px;height:480px}.appcore-modal__panel--M{width:640px;height:720px}.appcore-modal__panel--L{width:1200px;height:560px}.appcore-modal__panel--XL{width:1400px;height:720px}.appcore-modal__content{display:flex;flex-direction:column;align-items:stretch;gap:4px;flex:1;overflow:hidden}.appcore-modal__header{display:flex;flex-direction:row;align-items:center;gap:12px;padding:12px 16px 8px;border-bottom:1px solid rgb(204,204,204);background-color:#fff;flex-shrink:0}.appcore-modal__title-group{display:flex;flex-direction:column;gap:4px;flex:1}.appcore-modal__title{font-family:Inter,sans-serif;font-size:20px;font-weight:600;line-height:1.4em;color:#3d3d3d}.appcore-modal__subtitle{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.2857em;color:#525252}.appcore-modal__close{flex-shrink:0;width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;border:none;background:transparent;cursor:pointer;padding:0;border-radius:.5rem;color:#525252}.appcore-modal__close:hover{background-color:#ebebeb}.appcore-modal__close ::ng-deep .material-symbols-rounded{font-size:20px;color:#525252!important}.appcore-modal__body{flex:1;overflow-y:auto;padding:12px 16px}.appcore-modal__footer{display:flex;flex-direction:row;justify-content:flex-end;align-items:center;padding:16px 12px;border-top:1px solid rgb(204,204,204);background-color:#fff;flex-shrink:0}.appcore-modal__button-set{display:flex;flex-direction:row;gap:12px}.appcore-modal__button-set ::ng-deep .appcore-button{width:120px;min-width:120px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }, { kind: "component", type: ButtonComponent, selector: "appcore-button", inputs: ["buttonText", "label", "size", "state", "type", "nativeType", "showLeftIcon", "showRightIcon", "leftIconName", "rightIconName", "leftIconSet", "rightIconSet", "leftIconSrc", "rightIconSrc"], outputs: ["buttonClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-modal', standalone: true, imports: [CommonModule, IconComponent, ButtonComponent], template: `
    <div class="appcore-modal" [class.appcore-modal--visible]="visible">
      <!-- Overlay -->
      <div class="appcore-modal__overlay" (click)="onOverlayClick()"></div>

      <!-- Modal panel -->
      <div
        class="appcore-modal__panel"
        [ngClass]="'appcore-modal__panel--' + size"
        role="dialog"
        aria-modal="true"
        [attr.aria-labelledby]="'modal-title'"
      >
        <!-- Content wrapper (header + body) -->
        <div class="appcore-modal__content">
          <!-- Header -->
          <div class="appcore-modal__header">
            <div class="appcore-modal__title-group">
              <span class="appcore-modal__title" id="modal-title">{{ title }}</span>
              <span *ngIf="subtitle" class="appcore-modal__subtitle">{{ subtitle }}</span>
            </div>

            <button
              type="button"
              class="appcore-modal__close"
              (click)="close.emit()"
              aria-label="Close modal"
            >
              <app-icon icon="close" iconSet="material" size="sm"></app-icon>
            </button>
          </div>

          <!-- Body slot -->
          <div class="appcore-modal__body">
            <ng-content></ng-content>
          </div>
        </div>

        <!-- Footer CTAs -->
        <div class="appcore-modal__footer">
          <div class="appcore-modal__button-set">
            <appcore-button
              type="secondary"
              size="small"
              [label]="cancelLabel"
              (click)="cancel.emit()"
            ></appcore-button>
            <appcore-button
              type="primary"
              size="small"
              [label]="confirmLabel"
              (click)="confirm.emit()"
            ></appcore-button>
          </div>
        </div>
      </div>
    </div>
  `, styles: [".appcore-modal{display:none;position:fixed;inset:0;z-index:1000}.appcore-modal--visible{display:block}.appcore-modal__overlay{position:absolute;inset:0;background-color:#1119}.appcore-modal__panel{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);background-color:#fff;border-radius:.5rem;display:flex;flex-direction:column;justify-content:space-between;overflow:hidden}.appcore-modal__panel--S{width:640px;height:480px}.appcore-modal__panel--M{width:640px;height:720px}.appcore-modal__panel--L{width:1200px;height:560px}.appcore-modal__panel--XL{width:1400px;height:720px}.appcore-modal__content{display:flex;flex-direction:column;align-items:stretch;gap:4px;flex:1;overflow:hidden}.appcore-modal__header{display:flex;flex-direction:row;align-items:center;gap:12px;padding:12px 16px 8px;border-bottom:1px solid rgb(204,204,204);background-color:#fff;flex-shrink:0}.appcore-modal__title-group{display:flex;flex-direction:column;gap:4px;flex:1}.appcore-modal__title{font-family:Inter,sans-serif;font-size:20px;font-weight:600;line-height:1.4em;color:#3d3d3d}.appcore-modal__subtitle{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.2857em;color:#525252}.appcore-modal__close{flex-shrink:0;width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;border:none;background:transparent;cursor:pointer;padding:0;border-radius:.5rem;color:#525252}.appcore-modal__close:hover{background-color:#ebebeb}.appcore-modal__close ::ng-deep .material-symbols-rounded{font-size:20px;color:#525252!important}.appcore-modal__body{flex:1;overflow-y:auto;padding:12px 16px}.appcore-modal__footer{display:flex;flex-direction:row;justify-content:flex-end;align-items:center;padding:16px 12px;border-top:1px solid rgb(204,204,204);background-color:#fff;flex-shrink:0}.appcore-modal__button-set{display:flex;flex-direction:row;gap:12px}.appcore-modal__button-set ::ng-deep .appcore-button{width:120px;min-width:120px}\n"] }]
        }], propDecorators: { visible: [{
                type: Input
            }], size: [{
                type: Input
            }], title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], cancelLabel: [{
                type: Input
            }], confirmLabel: [{
                type: Input
            }], closeOnOverlayClick: [{
                type: Input
            }], close: [{
                type: Output
            }], cancel: [{
                type: Output
            }], confirm: [{
                type: Output
            }] } });

class NumericStepperComponent {
    constructor() {
        /** Which stepper layout to render. */
        this.variant = 'left-input';
        /** For center-input: whether the label sits above (vertical) or beside (horizontal) the control. */
        this.labelPosition = 'vertical';
        /** Visible label text. */
        this.label = 'Label';
        /** Shows the required asterisk (*) next to the label. */
        this.required = true;
        /** Current numeric value. */
        this.value = 0;
        /** Amount to increment/decrement per step. */
        this.step = 1;
        /** Disables all interaction. */
        this.disabled = false;
        /** Applies error border styling. */
        this.error = false;
        /** Emits the updated value after increment, decrement, or manual input. */
        this.valueChange = new EventEmitter();
        this.isFocused = false;
    }
    get displayValue() {
        return String(this.value).padStart(2, '0');
    }
    increment() {
        if (this.disabled)
            return;
        const next = this.value + this.step;
        if (this.max !== undefined && next > this.max)
            return;
        this.value = next;
        this.valueChange.emit(this.value);
    }
    decrement() {
        if (this.disabled)
            return;
        const next = this.value - this.step;
        if (this.min !== undefined && next < this.min)
            return;
        this.value = next;
        this.valueChange.emit(this.value);
    }
    onFocus() {
        this.isFocused = true;
    }
    onBlur(event) {
        this.isFocused = false;
        const input = event.target;
        const parsed = parseInt(input.value, 10);
        if (!isNaN(parsed)) {
            this.value = parsed;
            this.valueChange.emit(this.value);
        }
    }
    onInputChange(event) {
        const input = event.target;
        const parsed = parseInt(input.value, 10);
        if (!isNaN(parsed)) {
            this.value = parsed;
            this.valueChange.emit(this.value);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: NumericStepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: NumericStepperComponent, isStandalone: true, selector: "appcore-numeric-stepper", inputs: { variant: "variant", labelPosition: "labelPosition", label: "label", required: "required", value: "value", min: "min", max: "max", step: "step", disabled: "disabled", error: "error" }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <!-- Left-Input Numeric Stepper -->
    <div
      *ngIf="variant === 'left-input'"
      class="appcore-numeric-stepper appcore-numeric-stepper--left-input"
      [class.appcore-numeric-stepper--disabled]="disabled"
      [class.appcore-numeric-stepper--error]="error"
    >
      <div class="appcore-numeric-stepper__label">
        <span class="appcore-numeric-stepper__label-text">{{ label }}</span>
        <span *ngIf="required" class="appcore-numeric-stepper__required">*</span>
      </div>

      <div
        class="appcore-numeric-stepper__container"
        [class.appcore-numeric-stepper__container--focused]="isFocused"
      >
        <input
          class="appcore-numeric-stepper__input"
          type="text"
          inputmode="numeric"
          [value]="displayValue"
          [disabled]="disabled"
          (focus)="onFocus()"
          (blur)="onBlur($event)"
          (input)="onInputChange($event)"
          (keydown.arrowup)="increment()"
          (keydown.arrowdown)="decrement()"
          [attr.aria-label]="label + ' value'"
        />

        <div class="appcore-numeric-stepper__actions">
          <button
            class="appcore-numeric-stepper__action-btn"
            type="button"
            [disabled]="disabled || (min !== undefined && value <= min)"
            (click)="decrement()"
            aria-label="Decrement"
          >
            <!-- Minus icon -->
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path
                d="M4.57143 8.57143H11.4286C11.5905 8.57143 11.7262 8.51667 11.8357 8.40714C11.9452 8.29762 12 8.1619 12 8C12 7.8381 11.9452 7.70238 11.8357 7.59286C11.7262 7.48333 11.5905 7.42857 11.4286 7.42857H4.57143C4.40952 7.42857 4.27381 7.48333 4.16429 7.59286C4.05476 7.70238 4 7.8381 4 8C4 8.1619 4.05476 8.29762 4.16429 8.40714C4.27381 8.51667 4.40952 8.57143 4.57143 8.57143Z"
                fill="currentColor"
              />
            </svg>
          </button>
          <button
            class="appcore-numeric-stepper__action-btn"
            type="button"
            [disabled]="disabled || (max !== undefined && value >= max)"
            (click)="increment()"
            aria-label="Increment"
          >
            <!-- Plus icon -->
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path
                d="M7.42857 8.57143H4.57143C4.40952 8.57143 4.27381 8.51667 4.16429 8.40714C4.05476 8.29762 4 8.1619 4 8C4 7.8381 4.05476 7.70238 4.16429 7.59286C4.27381 7.48333 4.40952 7.42857 4.57143 7.42857H7.42857V4.57143C7.42857 4.40952 7.48333 4.27381 7.59286 4.16429C7.70238 4.05476 7.8381 4 8 4C8.1619 4 8.29762 4.05476 8.40714 4.16429C8.51667 4.27381 8.57143 4.40952 8.57143 4.57143V7.42857H11.4286C11.5905 7.42857 11.7262 7.48333 11.8357 7.59286C11.9452 7.70238 12 7.8381 12 8C12 8.1619 11.9452 8.29762 11.8357 8.40714C11.7262 8.51667 11.5905 8.57143 11.4286 8.57143H8.57143V11.4286C8.57143 11.5905 8.51667 11.7262 8.40714 11.8357C8.29762 11.9452 8.1619 12 8 12C7.8381 12 7.70238 11.9452 7.59286 11.8357C7.48333 11.7262 7.42857 11.5905 7.42857 11.4286V8.57143Z"
                fill="currentColor"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>

    <!-- Center-Input Numeric Stepper -->
    <div
      *ngIf="variant === 'center-input'"
      class="appcore-numeric-stepper appcore-numeric-stepper--center-input"
      [class.appcore-numeric-stepper--center-horizontal]="labelPosition === 'horizontal'"
      [class.appcore-numeric-stepper--disabled]="disabled"
      [class.appcore-numeric-stepper--error]="error"
    >
      <!-- Label wrapper (for horizontal: provides column layout for label) -->
      <div
        class="appcore-numeric-stepper__label-wrapper"
        [class.appcore-numeric-stepper__label-wrapper--horizontal]="labelPosition === 'horizontal'"
      >
        <div class="appcore-numeric-stepper__label">
          <span class="appcore-numeric-stepper__label-text">{{ label }}</span>
          <span *ngIf="required" class="appcore-numeric-stepper__required">*</span>
        </div>
      </div>

      <div
        class="appcore-numeric-stepper__container appcore-numeric-stepper__container--center"
        [class.appcore-numeric-stepper__container--focused]="isFocused"
      >
        <!-- Decrement -->
        <button
          class="appcore-numeric-stepper__action-btn appcore-numeric-stepper__action-btn--decrement"
          type="button"
          [disabled]="disabled || (min !== undefined && value <= min)"
          (click)="decrement()"
          aria-label="Decrement"
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M4.57143 8.57143H11.4286C11.5905 8.57143 11.7262 8.51667 11.8357 8.40714C11.9452 8.29762 12 8.1619 12 8C12 7.8381 11.9452 7.70238 11.8357 7.59286C11.7262 7.48333 11.5905 7.42857 11.4286 7.42857H4.57143C4.40952 7.42857 4.27381 7.48333 4.16429 7.59286C4.05476 7.70238 4 7.8381 4 8C4 8.1619 4.05476 8.29762 4.16429 8.40714C4.27381 8.51667 4.40952 8.57143 4.57143 8.57143Z"
              fill="currentColor"
            />
          </svg>
        </button>

        <!-- Value input -->
        <input
          class="appcore-numeric-stepper__input appcore-numeric-stepper__input--centered"
          type="text"
          inputmode="numeric"
          [value]="displayValue"
          [disabled]="disabled"
          (focus)="onFocus()"
          (blur)="onBlur($event)"
          (input)="onInputChange($event)"
          (keydown.arrowup)="increment()"
          (keydown.arrowdown)="decrement()"
          [attr.aria-label]="label + ' value'"
        />

        <!-- Increment -->
        <button
          class="appcore-numeric-stepper__action-btn appcore-numeric-stepper__action-btn--increment"
          type="button"
          [disabled]="disabled || (max !== undefined && value >= max)"
          (click)="increment()"
          aria-label="Increment"
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M7.42857 8.57143H4.57143C4.40952 8.57143 4.27381 8.51667 4.16429 8.40714C4.05476 8.29762 4 8.1619 4 8C4 7.8381 4.05476 7.70238 4.16429 7.59286C4.27381 7.48333 4.40952 7.42857 4.57143 7.42857H7.42857V4.57143C7.42857 4.40952 7.48333 4.27381 7.59286 4.16429C7.70238 4.05476 7.8381 4 8 4C8.1619 4 8.29762 4.05476 8.40714 4.16429C8.51667 4.27381 8.57143 4.40952 8.57143 4.57143V7.42857H11.4286C11.5905 7.42857 11.7262 7.48333 11.8357 7.59286C11.9452 7.70238 12 7.8381 12 8C12 8.1619 11.9452 8.29762 11.8357 8.40714C11.7262 8.51667 11.5905 8.57143 11.4286 8.57143H8.57143V11.4286C8.57143 11.5905 8.51667 11.7262 8.40714 11.8357C8.29762 11.9452 8.1619 12 8 12C7.8381 12 7.70238 11.9452 7.59286 11.8357C7.48333 11.7262 7.42857 11.5905 7.42857 11.4286V8.57143Z"
              fill="currentColor"
            />
          </svg>
        </button>
      </div>
    </div>
  `, isInline: true, styles: [".appcore-numeric-stepper{display:inline-flex;flex-direction:column;gap:4px;font-family:Inter,sans-serif}.appcore-numeric-stepper--left-input{width:160px}.appcore-numeric-stepper--center-input{width:fit-content}.appcore-numeric-stepper--center-horizontal{flex-direction:row;align-items:center;width:160px}.appcore-numeric-stepper__label-wrapper{display:flex;flex-direction:column;gap:4px;flex:1 1 auto;min-width:fit-content}.appcore-numeric-stepper__label-wrapper--horizontal{padding-right:0}.appcore-numeric-stepper__label{display:flex;flex-direction:row;align-items:flex-start;gap:4px;width:100%}.appcore-numeric-stepper--center-horizontal .appcore-numeric-stepper__label-wrapper--horizontal .appcore-numeric-stepper__label{padding-right:12px}.appcore-numeric-stepper__label-text{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.2857em;color:#3d3d3d}.appcore-numeric-stepper__required{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.2857em;color:#d2222d}.appcore-numeric-stepper__container{display:flex;flex-direction:row;align-items:center;gap:12px;padding:8px;background-color:#fff;border:1px solid #7A7A7A;border-radius:4px;width:100%;box-sizing:border-box;transition:border-color .15s ease,box-shadow .15s ease}.appcore-numeric-stepper__container--focused{border-color:#0c558c;box-shadow:0 0 0 2px #0c558c33}.appcore-numeric-stepper__container--center{justify-content:space-between}.appcore-numeric-stepper__input{flex:1 1 auto;min-width:0;border:none;outline:none;background:transparent;font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:20px;color:#3d3d3d;text-align:left;cursor:text;padding:0;-moz-appearance:textfield}.appcore-numeric-stepper__input::-webkit-outer-spin-button,.appcore-numeric-stepper__input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}.appcore-numeric-stepper__input--centered{flex:0 0 40px;width:40px;text-align:center}.appcore-numeric-stepper__input:disabled{cursor:not-allowed;color:#a3a3a3;background:transparent}.appcore-numeric-stepper:not(.appcore-numeric-stepper--disabled):not(.appcore-numeric-stepper--error) .appcore-numeric-stepper__container:hover:not(.appcore-numeric-stepper__container--focused){border-color:#616161}.appcore-numeric-stepper:not(.appcore-numeric-stepper--disabled):not(.appcore-numeric-stepper--error) .appcore-numeric-stepper__container:hover .appcore-numeric-stepper__input{color:#252525}.appcore-numeric-stepper:not(.appcore-numeric-stepper--disabled):not(.appcore-numeric-stepper--error) .appcore-numeric-stepper__container:hover .appcore-numeric-stepper__label-text{color:#252525}.appcore-numeric-stepper__actions{display:flex;flex-direction:row;align-items:center;gap:12px;flex-shrink:0}.appcore-numeric-stepper__action-btn{display:flex;align-items:center;justify-content:center;width:16px;height:16px;padding:0;border:none;background:transparent;cursor:pointer;flex-shrink:0;transition:opacity .15s ease}.appcore-numeric-stepper__action-btn--decrement{color:#d2222d}.appcore-numeric-stepper__action-btn--increment{color:#238823}.appcore-numeric-stepper--left-input .appcore-numeric-stepper__action-btn{color:#3d3d3d}.appcore-numeric-stepper--left-input .appcore-numeric-stepper__action-btn:hover:not(:disabled){color:#252525}.appcore-numeric-stepper__action-btn:disabled{cursor:not-allowed;opacity:.4}.appcore-numeric-stepper__action-btn:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:2px;border-radius:2px}.appcore-numeric-stepper--disabled{cursor:not-allowed}.appcore-numeric-stepper--disabled .appcore-numeric-stepper__label-text,.appcore-numeric-stepper--disabled .appcore-numeric-stepper__required{color:#a3a3a3}.appcore-numeric-stepper--disabled .appcore-numeric-stepper__container{background-color:#f5f5f5;border-color:#ccc;pointer-events:none}.appcore-numeric-stepper--disabled .appcore-numeric-stepper__input{color:#a3a3a3}.appcore-numeric-stepper--disabled .appcore-numeric-stepper__action-btn{cursor:not-allowed;opacity:.4}.appcore-numeric-stepper--error .appcore-numeric-stepper__container{border-color:#d2222d}.appcore-numeric-stepper--error .appcore-numeric-stepper__container--focused{box-shadow:0 0 0 2px #d2222d33}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: NumericStepperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-numeric-stepper', standalone: true, imports: [CommonModule, FormsModule], template: `
    <!-- Left-Input Numeric Stepper -->
    <div
      *ngIf="variant === 'left-input'"
      class="appcore-numeric-stepper appcore-numeric-stepper--left-input"
      [class.appcore-numeric-stepper--disabled]="disabled"
      [class.appcore-numeric-stepper--error]="error"
    >
      <div class="appcore-numeric-stepper__label">
        <span class="appcore-numeric-stepper__label-text">{{ label }}</span>
        <span *ngIf="required" class="appcore-numeric-stepper__required">*</span>
      </div>

      <div
        class="appcore-numeric-stepper__container"
        [class.appcore-numeric-stepper__container--focused]="isFocused"
      >
        <input
          class="appcore-numeric-stepper__input"
          type="text"
          inputmode="numeric"
          [value]="displayValue"
          [disabled]="disabled"
          (focus)="onFocus()"
          (blur)="onBlur($event)"
          (input)="onInputChange($event)"
          (keydown.arrowup)="increment()"
          (keydown.arrowdown)="decrement()"
          [attr.aria-label]="label + ' value'"
        />

        <div class="appcore-numeric-stepper__actions">
          <button
            class="appcore-numeric-stepper__action-btn"
            type="button"
            [disabled]="disabled || (min !== undefined && value <= min)"
            (click)="decrement()"
            aria-label="Decrement"
          >
            <!-- Minus icon -->
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path
                d="M4.57143 8.57143H11.4286C11.5905 8.57143 11.7262 8.51667 11.8357 8.40714C11.9452 8.29762 12 8.1619 12 8C12 7.8381 11.9452 7.70238 11.8357 7.59286C11.7262 7.48333 11.5905 7.42857 11.4286 7.42857H4.57143C4.40952 7.42857 4.27381 7.48333 4.16429 7.59286C4.05476 7.70238 4 7.8381 4 8C4 8.1619 4.05476 8.29762 4.16429 8.40714C4.27381 8.51667 4.40952 8.57143 4.57143 8.57143Z"
                fill="currentColor"
              />
            </svg>
          </button>
          <button
            class="appcore-numeric-stepper__action-btn"
            type="button"
            [disabled]="disabled || (max !== undefined && value >= max)"
            (click)="increment()"
            aria-label="Increment"
          >
            <!-- Plus icon -->
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path
                d="M7.42857 8.57143H4.57143C4.40952 8.57143 4.27381 8.51667 4.16429 8.40714C4.05476 8.29762 4 8.1619 4 8C4 7.8381 4.05476 7.70238 4.16429 7.59286C4.27381 7.48333 4.40952 7.42857 4.57143 7.42857H7.42857V4.57143C7.42857 4.40952 7.48333 4.27381 7.59286 4.16429C7.70238 4.05476 7.8381 4 8 4C8.1619 4 8.29762 4.05476 8.40714 4.16429C8.51667 4.27381 8.57143 4.40952 8.57143 4.57143V7.42857H11.4286C11.5905 7.42857 11.7262 7.48333 11.8357 7.59286C11.9452 7.70238 12 7.8381 12 8C12 8.1619 11.9452 8.29762 11.8357 8.40714C11.7262 8.51667 11.5905 8.57143 11.4286 8.57143H8.57143V11.4286C8.57143 11.5905 8.51667 11.7262 8.40714 11.8357C8.29762 11.9452 8.1619 12 8 12C7.8381 12 7.70238 11.9452 7.59286 11.8357C7.48333 11.7262 7.42857 11.5905 7.42857 11.4286V8.57143Z"
                fill="currentColor"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>

    <!-- Center-Input Numeric Stepper -->
    <div
      *ngIf="variant === 'center-input'"
      class="appcore-numeric-stepper appcore-numeric-stepper--center-input"
      [class.appcore-numeric-stepper--center-horizontal]="labelPosition === 'horizontal'"
      [class.appcore-numeric-stepper--disabled]="disabled"
      [class.appcore-numeric-stepper--error]="error"
    >
      <!-- Label wrapper (for horizontal: provides column layout for label) -->
      <div
        class="appcore-numeric-stepper__label-wrapper"
        [class.appcore-numeric-stepper__label-wrapper--horizontal]="labelPosition === 'horizontal'"
      >
        <div class="appcore-numeric-stepper__label">
          <span class="appcore-numeric-stepper__label-text">{{ label }}</span>
          <span *ngIf="required" class="appcore-numeric-stepper__required">*</span>
        </div>
      </div>

      <div
        class="appcore-numeric-stepper__container appcore-numeric-stepper__container--center"
        [class.appcore-numeric-stepper__container--focused]="isFocused"
      >
        <!-- Decrement -->
        <button
          class="appcore-numeric-stepper__action-btn appcore-numeric-stepper__action-btn--decrement"
          type="button"
          [disabled]="disabled || (min !== undefined && value <= min)"
          (click)="decrement()"
          aria-label="Decrement"
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M4.57143 8.57143H11.4286C11.5905 8.57143 11.7262 8.51667 11.8357 8.40714C11.9452 8.29762 12 8.1619 12 8C12 7.8381 11.9452 7.70238 11.8357 7.59286C11.7262 7.48333 11.5905 7.42857 11.4286 7.42857H4.57143C4.40952 7.42857 4.27381 7.48333 4.16429 7.59286C4.05476 7.70238 4 7.8381 4 8C4 8.1619 4.05476 8.29762 4.16429 8.40714C4.27381 8.51667 4.40952 8.57143 4.57143 8.57143Z"
              fill="currentColor"
            />
          </svg>
        </button>

        <!-- Value input -->
        <input
          class="appcore-numeric-stepper__input appcore-numeric-stepper__input--centered"
          type="text"
          inputmode="numeric"
          [value]="displayValue"
          [disabled]="disabled"
          (focus)="onFocus()"
          (blur)="onBlur($event)"
          (input)="onInputChange($event)"
          (keydown.arrowup)="increment()"
          (keydown.arrowdown)="decrement()"
          [attr.aria-label]="label + ' value'"
        />

        <!-- Increment -->
        <button
          class="appcore-numeric-stepper__action-btn appcore-numeric-stepper__action-btn--increment"
          type="button"
          [disabled]="disabled || (max !== undefined && value >= max)"
          (click)="increment()"
          aria-label="Increment"
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M7.42857 8.57143H4.57143C4.40952 8.57143 4.27381 8.51667 4.16429 8.40714C4.05476 8.29762 4 8.1619 4 8C4 7.8381 4.05476 7.70238 4.16429 7.59286C4.27381 7.48333 4.40952 7.42857 4.57143 7.42857H7.42857V4.57143C7.42857 4.40952 7.48333 4.27381 7.59286 4.16429C7.70238 4.05476 7.8381 4 8 4C8.1619 4 8.29762 4.05476 8.40714 4.16429C8.51667 4.27381 8.57143 4.40952 8.57143 4.57143V7.42857H11.4286C11.5905 7.42857 11.7262 7.48333 11.8357 7.59286C11.9452 7.70238 12 7.8381 12 8C12 8.1619 11.9452 8.29762 11.8357 8.40714C11.7262 8.51667 11.5905 8.57143 11.4286 8.57143H8.57143V11.4286C8.57143 11.5905 8.51667 11.7262 8.40714 11.8357C8.29762 11.9452 8.1619 12 8 12C7.8381 12 7.70238 11.9452 7.59286 11.8357C7.48333 11.7262 7.42857 11.5905 7.42857 11.4286V8.57143Z"
              fill="currentColor"
            />
          </svg>
        </button>
      </div>
    </div>
  `, styles: [".appcore-numeric-stepper{display:inline-flex;flex-direction:column;gap:4px;font-family:Inter,sans-serif}.appcore-numeric-stepper--left-input{width:160px}.appcore-numeric-stepper--center-input{width:fit-content}.appcore-numeric-stepper--center-horizontal{flex-direction:row;align-items:center;width:160px}.appcore-numeric-stepper__label-wrapper{display:flex;flex-direction:column;gap:4px;flex:1 1 auto;min-width:fit-content}.appcore-numeric-stepper__label-wrapper--horizontal{padding-right:0}.appcore-numeric-stepper__label{display:flex;flex-direction:row;align-items:flex-start;gap:4px;width:100%}.appcore-numeric-stepper--center-horizontal .appcore-numeric-stepper__label-wrapper--horizontal .appcore-numeric-stepper__label{padding-right:12px}.appcore-numeric-stepper__label-text{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.2857em;color:#3d3d3d}.appcore-numeric-stepper__required{font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:1.2857em;color:#d2222d}.appcore-numeric-stepper__container{display:flex;flex-direction:row;align-items:center;gap:12px;padding:8px;background-color:#fff;border:1px solid #7A7A7A;border-radius:4px;width:100%;box-sizing:border-box;transition:border-color .15s ease,box-shadow .15s ease}.appcore-numeric-stepper__container--focused{border-color:#0c558c;box-shadow:0 0 0 2px #0c558c33}.appcore-numeric-stepper__container--center{justify-content:space-between}.appcore-numeric-stepper__input{flex:1 1 auto;min-width:0;border:none;outline:none;background:transparent;font-family:Inter,sans-serif;font-size:14px;font-weight:400;line-height:20px;color:#3d3d3d;text-align:left;cursor:text;padding:0;-moz-appearance:textfield}.appcore-numeric-stepper__input::-webkit-outer-spin-button,.appcore-numeric-stepper__input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}.appcore-numeric-stepper__input--centered{flex:0 0 40px;width:40px;text-align:center}.appcore-numeric-stepper__input:disabled{cursor:not-allowed;color:#a3a3a3;background:transparent}.appcore-numeric-stepper:not(.appcore-numeric-stepper--disabled):not(.appcore-numeric-stepper--error) .appcore-numeric-stepper__container:hover:not(.appcore-numeric-stepper__container--focused){border-color:#616161}.appcore-numeric-stepper:not(.appcore-numeric-stepper--disabled):not(.appcore-numeric-stepper--error) .appcore-numeric-stepper__container:hover .appcore-numeric-stepper__input{color:#252525}.appcore-numeric-stepper:not(.appcore-numeric-stepper--disabled):not(.appcore-numeric-stepper--error) .appcore-numeric-stepper__container:hover .appcore-numeric-stepper__label-text{color:#252525}.appcore-numeric-stepper__actions{display:flex;flex-direction:row;align-items:center;gap:12px;flex-shrink:0}.appcore-numeric-stepper__action-btn{display:flex;align-items:center;justify-content:center;width:16px;height:16px;padding:0;border:none;background:transparent;cursor:pointer;flex-shrink:0;transition:opacity .15s ease}.appcore-numeric-stepper__action-btn--decrement{color:#d2222d}.appcore-numeric-stepper__action-btn--increment{color:#238823}.appcore-numeric-stepper--left-input .appcore-numeric-stepper__action-btn{color:#3d3d3d}.appcore-numeric-stepper--left-input .appcore-numeric-stepper__action-btn:hover:not(:disabled){color:#252525}.appcore-numeric-stepper__action-btn:disabled{cursor:not-allowed;opacity:.4}.appcore-numeric-stepper__action-btn:focus-visible{outline:2px solid rgb(0,123,255);outline-offset:2px;border-radius:2px}.appcore-numeric-stepper--disabled{cursor:not-allowed}.appcore-numeric-stepper--disabled .appcore-numeric-stepper__label-text,.appcore-numeric-stepper--disabled .appcore-numeric-stepper__required{color:#a3a3a3}.appcore-numeric-stepper--disabled .appcore-numeric-stepper__container{background-color:#f5f5f5;border-color:#ccc;pointer-events:none}.appcore-numeric-stepper--disabled .appcore-numeric-stepper__input{color:#a3a3a3}.appcore-numeric-stepper--disabled .appcore-numeric-stepper__action-btn{cursor:not-allowed;opacity:.4}.appcore-numeric-stepper--error .appcore-numeric-stepper__container{border-color:#d2222d}.appcore-numeric-stepper--error .appcore-numeric-stepper__container--focused{box-shadow:0 0 0 2px #d2222d33}\n"] }]
        }], propDecorators: { variant: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], label: [{
                type: Input
            }], required: [{
                type: Input
            }], value: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], disabled: [{
                type: Input
            }], error: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

class ProgressStepperComponent {
    constructor() {
        this.steps = [];
        this.orientation = 'horizontal';
        this.type = 'default';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ProgressStepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: ProgressStepperComponent, isStandalone: true, selector: "app-progress-stepper", inputs: { steps: "steps", orientation: "orientation", type: "type" }, ngImport: i0, template: `
    <div
      class="stepper"
      [class.stepper--horizontal]="orientation === 'horizontal'"
      [class.stepper--vertical]="orientation === 'vertical'"
    >
      <div
        *ngFor="let step of steps; let i = index; let last = last"
        class="stepper__step"
      >
        <!-- Vertical layout: left track column (indicator + connector) + right label -->
        <ng-container *ngIf="orientation === 'vertical'">
          <div class="stepper__track-col">
            <div class="stepper__indicator" [ngClass]="'stepper__indicator--' + step.state">
              <ng-container *ngTemplateOutlet="indicatorContent; context: { $implicit: step, idx: i }"></ng-container>
            </div>
            <div *ngIf="!last" class="stepper__connector stepper__connector--vertical"></div>
          </div>
          <span class="stepper__label" [ngClass]="'stepper__label--' + step.state">{{ step.label }}</span>
        </ng-container>

        <!-- Horizontal layout: step-content (indicator + label) + connector -->
        <ng-container *ngIf="orientation === 'horizontal'">
          <div class="stepper__step-content">
            <div class="stepper__indicator" [ngClass]="'stepper__indicator--' + step.state">
              <ng-container *ngTemplateOutlet="indicatorContent; context: { $implicit: step, idx: i }"></ng-container>
            </div>
            <span class="stepper__label" [ngClass]="'stepper__label--' + step.state">{{ step.label }}</span>
          </div>
          <div *ngIf="!last" class="stepper__connector stepper__connector--horizontal"></div>
        </ng-container>
      </div>
    </div>

    <ng-template #indicatorContent let-step let-idx="idx">
      <ng-container [ngSwitch]="step.state">
        <mat-icon *ngSwitchCase="'done'" class="stepper__icon">check</mat-icon>
        <mat-icon *ngSwitchCase="'error'" class="stepper__icon">close</mat-icon>
        <ng-container *ngSwitchDefault>
          <mat-icon *ngIf="type === 'icon' && step.icon; else numTpl" class="stepper__icon">{{ step.icon }}</mat-icon>
          <ng-template #numTpl>
            <span class="stepper__number">{{ idx + 1 }}</span>
          </ng-template>
        </ng-container>
      </ng-container>
    </ng-template>
  `, isInline: true, styles: [".stepper{display:inline-flex}.stepper--horizontal{flex-direction:row;align-items:center}.stepper--vertical{flex-direction:column}.stepper__step{display:flex;align-items:center}.stepper--horizontal .stepper__step{flex-direction:row;align-items:center}.stepper--vertical .stepper__step{flex-direction:row;align-items:flex-start;gap:12px}.stepper__step-content{display:flex;flex-direction:row;align-items:center;gap:8px}.stepper__track-col{display:flex;flex-direction:column;align-items:center;flex-shrink:0}.stepper__indicator{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-sizing:border-box}.stepper__indicator--not-done{border:2px solid rgb(163,163,163);background:transparent}.stepper__indicator--not-done .stepper__number,.stepper__indicator--not-done .stepper__icon{color:#a3a3a3}.stepper__indicator--current{background:#0c558c;border:2px solid rgb(12,85,140)}.stepper__indicator--current .stepper__number,.stepper__indicator--current .stepper__icon{color:#fff}.stepper__indicator--done{background:#238823;border:2px solid rgb(35,136,35)}.stepper__indicator--done .stepper__icon{color:#fff}.stepper__indicator--partially-done{border:2px solid rgb(255,191,0);background:transparent}.stepper__indicator--partially-done .stepper__number,.stepper__indicator--partially-done .stepper__icon{color:#ffbf00}.stepper__indicator--error{background:#d2222d;border:2px solid rgb(210,34,45)}.stepper__indicator--error .stepper__icon{color:#fff}.stepper__number{font-family:Inter,sans-serif;font-size:16px;font-weight:500;line-height:1}.stepper__icon{font-size:18px!important;width:18px!important;height:18px!important;line-height:1!important}.stepper__connector{background:#ccc;flex-shrink:0}.stepper__connector--horizontal{width:100px;height:1px}.stepper__connector--vertical{width:1px;height:44px}.stepper__label{font-family:Inter,sans-serif;font-size:16px;line-height:1.25}.stepper--vertical .stepper__label{padding-top:6px}.stepper__label--current{font-weight:500;color:#3d3d3d}.stepper__label--not-done{font-weight:400;color:#a3a3a3}.stepper__label--done{font-weight:500;color:#3d3d3d}.stepper__label--partially-done{font-weight:400;color:#ffbf00}.stepper__label--error{font-weight:400;color:#d2222d}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: i1.NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: i1.NgSwitchDefault, selector: "[ngSwitchDefault]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ProgressStepperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-progress-stepper', standalone: true, imports: [CommonModule, MatIconModule], template: `
    <div
      class="stepper"
      [class.stepper--horizontal]="orientation === 'horizontal'"
      [class.stepper--vertical]="orientation === 'vertical'"
    >
      <div
        *ngFor="let step of steps; let i = index; let last = last"
        class="stepper__step"
      >
        <!-- Vertical layout: left track column (indicator + connector) + right label -->
        <ng-container *ngIf="orientation === 'vertical'">
          <div class="stepper__track-col">
            <div class="stepper__indicator" [ngClass]="'stepper__indicator--' + step.state">
              <ng-container *ngTemplateOutlet="indicatorContent; context: { $implicit: step, idx: i }"></ng-container>
            </div>
            <div *ngIf="!last" class="stepper__connector stepper__connector--vertical"></div>
          </div>
          <span class="stepper__label" [ngClass]="'stepper__label--' + step.state">{{ step.label }}</span>
        </ng-container>

        <!-- Horizontal layout: step-content (indicator + label) + connector -->
        <ng-container *ngIf="orientation === 'horizontal'">
          <div class="stepper__step-content">
            <div class="stepper__indicator" [ngClass]="'stepper__indicator--' + step.state">
              <ng-container *ngTemplateOutlet="indicatorContent; context: { $implicit: step, idx: i }"></ng-container>
            </div>
            <span class="stepper__label" [ngClass]="'stepper__label--' + step.state">{{ step.label }}</span>
          </div>
          <div *ngIf="!last" class="stepper__connector stepper__connector--horizontal"></div>
        </ng-container>
      </div>
    </div>

    <ng-template #indicatorContent let-step let-idx="idx">
      <ng-container [ngSwitch]="step.state">
        <mat-icon *ngSwitchCase="'done'" class="stepper__icon">check</mat-icon>
        <mat-icon *ngSwitchCase="'error'" class="stepper__icon">close</mat-icon>
        <ng-container *ngSwitchDefault>
          <mat-icon *ngIf="type === 'icon' && step.icon; else numTpl" class="stepper__icon">{{ step.icon }}</mat-icon>
          <ng-template #numTpl>
            <span class="stepper__number">{{ idx + 1 }}</span>
          </ng-template>
        </ng-container>
      </ng-container>
    </ng-template>
  `, styles: [".stepper{display:inline-flex}.stepper--horizontal{flex-direction:row;align-items:center}.stepper--vertical{flex-direction:column}.stepper__step{display:flex;align-items:center}.stepper--horizontal .stepper__step{flex-direction:row;align-items:center}.stepper--vertical .stepper__step{flex-direction:row;align-items:flex-start;gap:12px}.stepper__step-content{display:flex;flex-direction:row;align-items:center;gap:8px}.stepper__track-col{display:flex;flex-direction:column;align-items:center;flex-shrink:0}.stepper__indicator{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-sizing:border-box}.stepper__indicator--not-done{border:2px solid rgb(163,163,163);background:transparent}.stepper__indicator--not-done .stepper__number,.stepper__indicator--not-done .stepper__icon{color:#a3a3a3}.stepper__indicator--current{background:#0c558c;border:2px solid rgb(12,85,140)}.stepper__indicator--current .stepper__number,.stepper__indicator--current .stepper__icon{color:#fff}.stepper__indicator--done{background:#238823;border:2px solid rgb(35,136,35)}.stepper__indicator--done .stepper__icon{color:#fff}.stepper__indicator--partially-done{border:2px solid rgb(255,191,0);background:transparent}.stepper__indicator--partially-done .stepper__number,.stepper__indicator--partially-done .stepper__icon{color:#ffbf00}.stepper__indicator--error{background:#d2222d;border:2px solid rgb(210,34,45)}.stepper__indicator--error .stepper__icon{color:#fff}.stepper__number{font-family:Inter,sans-serif;font-size:16px;font-weight:500;line-height:1}.stepper__icon{font-size:18px!important;width:18px!important;height:18px!important;line-height:1!important}.stepper__connector{background:#ccc;flex-shrink:0}.stepper__connector--horizontal{width:100px;height:1px}.stepper__connector--vertical{width:1px;height:44px}.stepper__label{font-family:Inter,sans-serif;font-size:16px;line-height:1.25}.stepper--vertical .stepper__label{padding-top:6px}.stepper__label--current{font-weight:500;color:#3d3d3d}.stepper__label--not-done{font-weight:400;color:#a3a3a3}.stepper__label--done{font-weight:500;color:#3d3d3d}.stepper__label--partially-done{font-weight:400;color:#ffbf00}.stepper__label--error{font-weight:400;color:#d2222d}\n"] }]
        }], propDecorators: { steps: [{
                type: Input
            }], orientation: [{
                type: Input
            }], type: [{
                type: Input
            }] } });

class RadioButtonComponent {
    constructor() {
        /** Visible text label next to the radio button. */
        this.label = '';
        /** aria-label applied when no visible label is provided. */
        this.ariaLabel = '';
        /** Whether this radio button is selected. */
        this.checked = false;
        /** Groups radio buttons together — only one per name can be selected. */
        this.name = '';
        /** Value emitted when this option is selected. */
        this.value = '';
        /** Disables interaction. */
        this.disabled = false;
        /** Visual size of the radio button. */
        this.size = 'md';
        /** HTML id forwarded to the native input. */
        this.inputId = '';
        /** Emits this radio button's value when selected. */
        this.valueChange = new EventEmitter();
    }
    onNativeChange() {
        if (!this.disabled) {
            this.checked = true;
            this.valueChange.emit(this.value);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: RadioButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: RadioButtonComponent, isStandalone: true, selector: "appcore-radio-button", inputs: { label: "label", ariaLabel: "ariaLabel", checked: "checked", name: "name", value: "value", disabled: "disabled", size: "size", inputId: "inputId" }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <label
      class="appcore-radio"
      [ngClass]="[
        'appcore-radio--size-' + size,
        disabled ? 'appcore-radio--disabled' : ''
      ]"
    >
      <span class="appcore-radio__control">
        <input
          type="radio"
          class="appcore-radio__input"
          [name]="name"
          [value]="value"
          [checked]="checked"
          [disabled]="disabled"
          [attr.id]="inputId || null"
          [attr.aria-label]="!label ? ariaLabel || null : null"
          (change)="onNativeChange()"
        />
        <span class="appcore-radio__circle" aria-hidden="true"></span>
      </span>
      <span *ngIf="label" class="appcore-radio__label">{{ label }}</span>
    </label>
  `, isInline: true, styles: [".appcore-radio{display:inline-flex;align-items:center;gap:.25rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-radio--disabled{cursor:not-allowed}.appcore-radio--disabled .appcore-radio__label{color:#a3a3a3}.appcore-radio--disabled .appcore-radio__control{opacity:.5}.appcore-radio__control{position:relative;width:16px;height:16px;flex-shrink:0}.appcore-radio__input{position:absolute;inset:0;opacity:0;margin:0;width:100%;height:100%;cursor:pointer;z-index:1}.appcore-radio__input:disabled{cursor:not-allowed}.appcore-radio__circle{position:absolute;inset:0;border:1.5px solid rgb(82,82,82);border-radius:50%;background-color:#fff;transition:border-color .15s ease,background-color .15s ease,box-shadow .15s ease;pointer-events:none}.appcore-radio:hover:not(.appcore-radio--disabled) .appcore-radio__input:not(:checked)+.appcore-radio__circle{border-color:#0c558c}.appcore-radio__input:focus-visible+.appcore-radio__circle{box-shadow:0 0 0 2px #007bff}.appcore-radio__input:checked+.appcore-radio__circle{background-color:#0c558c;border-color:#0c558c}.appcore-radio__input:checked+.appcore-radio__circle:after{content:\"\";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:6px;height:6px;border-radius:50%;background-color:#fff}.appcore-radio__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#111}.appcore-radio--size-md .appcore-radio__label{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio--size-lg .appcore-radio__control{width:20px;height:20px}.appcore-radio--size-lg .appcore-radio__input:checked+.appcore-radio__circle:after{width:8px;height:8px}.appcore-radio--size-lg .appcore-radio__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio-group{display:inline-flex;flex-direction:column;gap:.5rem;font-family:Inter,sans-serif}.appcore-radio-group--horizontal{flex-direction:row;align-items:flex-end;gap:2.5rem}.appcore-radio-group--horizontal .appcore-radio-group__items{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-radio-group--horizontal-next-row{flex-direction:column}.appcore-radio-group--horizontal-next-row .appcore-radio-group__items{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-radio-group--vertical{flex-direction:column}.appcore-radio-group__header{display:flex;flex-direction:column;gap:.25rem}.appcore-radio-group__label{font-size:12px;line-height:18px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111}.appcore-radio-group__description{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#525252}.appcore-radio-group__items{display:flex;flex-direction:column;gap:.75rem}.appcore-radio-group--size-md .appcore-radio-group__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500}.appcore-radio-group--size-md .appcore-radio-group__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio-group--size-lg .appcore-radio-group__label{font-size:16px;line-height:22px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500}.appcore-radio-group--size-lg .appcore-radio-group__description{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: RadioButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-radio-button', standalone: true, imports: [CommonModule], template: `
    <label
      class="appcore-radio"
      [ngClass]="[
        'appcore-radio--size-' + size,
        disabled ? 'appcore-radio--disabled' : ''
      ]"
    >
      <span class="appcore-radio__control">
        <input
          type="radio"
          class="appcore-radio__input"
          [name]="name"
          [value]="value"
          [checked]="checked"
          [disabled]="disabled"
          [attr.id]="inputId || null"
          [attr.aria-label]="!label ? ariaLabel || null : null"
          (change)="onNativeChange()"
        />
        <span class="appcore-radio__circle" aria-hidden="true"></span>
      </span>
      <span *ngIf="label" class="appcore-radio__label">{{ label }}</span>
    </label>
  `, styles: [".appcore-radio{display:inline-flex;align-items:center;gap:.25rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-radio--disabled{cursor:not-allowed}.appcore-radio--disabled .appcore-radio__label{color:#a3a3a3}.appcore-radio--disabled .appcore-radio__control{opacity:.5}.appcore-radio__control{position:relative;width:16px;height:16px;flex-shrink:0}.appcore-radio__input{position:absolute;inset:0;opacity:0;margin:0;width:100%;height:100%;cursor:pointer;z-index:1}.appcore-radio__input:disabled{cursor:not-allowed}.appcore-radio__circle{position:absolute;inset:0;border:1.5px solid rgb(82,82,82);border-radius:50%;background-color:#fff;transition:border-color .15s ease,background-color .15s ease,box-shadow .15s ease;pointer-events:none}.appcore-radio:hover:not(.appcore-radio--disabled) .appcore-radio__input:not(:checked)+.appcore-radio__circle{border-color:#0c558c}.appcore-radio__input:focus-visible+.appcore-radio__circle{box-shadow:0 0 0 2px #007bff}.appcore-radio__input:checked+.appcore-radio__circle{background-color:#0c558c;border-color:#0c558c}.appcore-radio__input:checked+.appcore-radio__circle:after{content:\"\";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:6px;height:6px;border-radius:50%;background-color:#fff}.appcore-radio__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#111}.appcore-radio--size-md .appcore-radio__label{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio--size-lg .appcore-radio__control{width:20px;height:20px}.appcore-radio--size-lg .appcore-radio__input:checked+.appcore-radio__circle:after{width:8px;height:8px}.appcore-radio--size-lg .appcore-radio__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio-group{display:inline-flex;flex-direction:column;gap:.5rem;font-family:Inter,sans-serif}.appcore-radio-group--horizontal{flex-direction:row;align-items:flex-end;gap:2.5rem}.appcore-radio-group--horizontal .appcore-radio-group__items{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-radio-group--horizontal-next-row{flex-direction:column}.appcore-radio-group--horizontal-next-row .appcore-radio-group__items{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-radio-group--vertical{flex-direction:column}.appcore-radio-group__header{display:flex;flex-direction:column;gap:.25rem}.appcore-radio-group__label{font-size:12px;line-height:18px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111}.appcore-radio-group__description{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#525252}.appcore-radio-group__items{display:flex;flex-direction:column;gap:.75rem}.appcore-radio-group--size-md .appcore-radio-group__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500}.appcore-radio-group--size-md .appcore-radio-group__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio-group--size-lg .appcore-radio-group__label{font-size:16px;line-height:22px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500}.appcore-radio-group--size-lg .appcore-radio-group__description{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], checked: [{
                type: Input
            }], name: [{
                type: Input
            }], value: [{
                type: Input
            }], disabled: [{
                type: Input
            }], size: [{
                type: Input
            }], inputId: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

class RadioButtonGroupComponent {
    constructor() {
        /** Array of radio button options. */
        this.items = [];
        /** Currently selected value. */
        this.value = '';
        /** Group label displayed above the options. */
        this.groupLabel = '';
        /** Optional helper text below the group label. */
        this.groupDescription = '';
        /** Layout orientation of the radio buttons. */
        this.orientation = 'vertical';
        /** Size applied to all radio buttons in the group. */
        this.size = 'md';
        /** Disables all radio buttons in the group. */
        this.disabled = false;
        /** Emits the selected value when the user picks an option. */
        this.valueChange = new EventEmitter();
        this._labelId = `radio-group-label-${Math.random().toString(36).slice(2)}`;
        this._groupName = `radio-group-${Math.random().toString(36).slice(2)}`;
    }
    onItemChange(selectedValue) {
        this.value = selectedValue;
        this.valueChange.emit(selectedValue);
    }
    trackById(_index, item) {
        return item.id;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: RadioButtonGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: RadioButtonGroupComponent, isStandalone: true, selector: "appcore-radio-button-group", inputs: { items: "items", value: "value", groupLabel: "groupLabel", groupDescription: "groupDescription", orientation: "orientation", size: "size", disabled: "disabled" }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <div
      class="appcore-radio-group"
      [ngClass]="[
        'appcore-radio-group--' + orientation,
        'appcore-radio-group--size-' + size
      ]"
      role="radiogroup"
      [attr.aria-labelledby]="groupLabel ? _labelId : null"
    >
      <!-- Group header -->
      <div *ngIf="groupLabel || groupDescription" class="appcore-radio-group__header">
        <span
          *ngIf="groupLabel"
          class="appcore-radio-group__label"
          [id]="_labelId"
        >{{ groupLabel }}</span>
        <span *ngIf="groupDescription" class="appcore-radio-group__description">
          {{ groupDescription }}
        </span>
      </div>

      <!-- Items -->
      <div class="appcore-radio-group__items">
        <appcore-radio-button
          *ngFor="let item of items; trackBy: trackById"
          [label]="item.label"
          [value]="item.value"
          [checked]="item.value === value"
          [disabled]="disabled || !!item.disabled"
          [name]="_groupName"
          [size]="size"
          [inputId]="item.id"
          (valueChange)="onItemChange($event)"
        ></appcore-radio-button>
      </div>
    </div>
  `, isInline: true, styles: [".appcore-radio{display:inline-flex;align-items:center;gap:.25rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-radio--disabled{cursor:not-allowed}.appcore-radio--disabled .appcore-radio__label{color:#a3a3a3}.appcore-radio--disabled .appcore-radio__control{opacity:.5}.appcore-radio__control{position:relative;width:16px;height:16px;flex-shrink:0}.appcore-radio__input{position:absolute;inset:0;opacity:0;margin:0;width:100%;height:100%;cursor:pointer;z-index:1}.appcore-radio__input:disabled{cursor:not-allowed}.appcore-radio__circle{position:absolute;inset:0;border:1.5px solid rgb(82,82,82);border-radius:50%;background-color:#fff;transition:border-color .15s ease,background-color .15s ease,box-shadow .15s ease;pointer-events:none}.appcore-radio:hover:not(.appcore-radio--disabled) .appcore-radio__input:not(:checked)+.appcore-radio__circle{border-color:#0c558c}.appcore-radio__input:focus-visible+.appcore-radio__circle{box-shadow:0 0 0 2px #007bff}.appcore-radio__input:checked+.appcore-radio__circle{background-color:#0c558c;border-color:#0c558c}.appcore-radio__input:checked+.appcore-radio__circle:after{content:\"\";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:6px;height:6px;border-radius:50%;background-color:#fff}.appcore-radio__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#111}.appcore-radio--size-md .appcore-radio__label{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio--size-lg .appcore-radio__control{width:20px;height:20px}.appcore-radio--size-lg .appcore-radio__input:checked+.appcore-radio__circle:after{width:8px;height:8px}.appcore-radio--size-lg .appcore-radio__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio-group{display:inline-flex;flex-direction:column;gap:.5rem;font-family:Inter,sans-serif}.appcore-radio-group--horizontal{flex-direction:row;align-items:flex-end;gap:2.5rem}.appcore-radio-group--horizontal .appcore-radio-group__items{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-radio-group--horizontal-next-row{flex-direction:column}.appcore-radio-group--horizontal-next-row .appcore-radio-group__items{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-radio-group--vertical{flex-direction:column}.appcore-radio-group__header{display:flex;flex-direction:column;gap:.25rem}.appcore-radio-group__label{font-size:12px;line-height:18px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111}.appcore-radio-group__description{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#525252}.appcore-radio-group__items{display:flex;flex-direction:column;gap:.75rem}.appcore-radio-group--size-md .appcore-radio-group__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500}.appcore-radio-group--size-md .appcore-radio-group__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio-group--size-lg .appcore-radio-group__label{font-size:16px;line-height:22px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500}.appcore-radio-group--size-lg .appcore-radio-group__description{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: RadioButtonComponent, selector: "appcore-radio-button", inputs: ["label", "ariaLabel", "checked", "name", "value", "disabled", "size", "inputId"], outputs: ["valueChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: RadioButtonGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-radio-button-group', standalone: true, imports: [CommonModule, RadioButtonComponent], template: `
    <div
      class="appcore-radio-group"
      [ngClass]="[
        'appcore-radio-group--' + orientation,
        'appcore-radio-group--size-' + size
      ]"
      role="radiogroup"
      [attr.aria-labelledby]="groupLabel ? _labelId : null"
    >
      <!-- Group header -->
      <div *ngIf="groupLabel || groupDescription" class="appcore-radio-group__header">
        <span
          *ngIf="groupLabel"
          class="appcore-radio-group__label"
          [id]="_labelId"
        >{{ groupLabel }}</span>
        <span *ngIf="groupDescription" class="appcore-radio-group__description">
          {{ groupDescription }}
        </span>
      </div>

      <!-- Items -->
      <div class="appcore-radio-group__items">
        <appcore-radio-button
          *ngFor="let item of items; trackBy: trackById"
          [label]="item.label"
          [value]="item.value"
          [checked]="item.value === value"
          [disabled]="disabled || !!item.disabled"
          [name]="_groupName"
          [size]="size"
          [inputId]="item.id"
          (valueChange)="onItemChange($event)"
        ></appcore-radio-button>
      </div>
    </div>
  `, styles: [".appcore-radio{display:inline-flex;align-items:center;gap:.25rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-radio--disabled{cursor:not-allowed}.appcore-radio--disabled .appcore-radio__label{color:#a3a3a3}.appcore-radio--disabled .appcore-radio__control{opacity:.5}.appcore-radio__control{position:relative;width:16px;height:16px;flex-shrink:0}.appcore-radio__input{position:absolute;inset:0;opacity:0;margin:0;width:100%;height:100%;cursor:pointer;z-index:1}.appcore-radio__input:disabled{cursor:not-allowed}.appcore-radio__circle{position:absolute;inset:0;border:1.5px solid rgb(82,82,82);border-radius:50%;background-color:#fff;transition:border-color .15s ease,background-color .15s ease,box-shadow .15s ease;pointer-events:none}.appcore-radio:hover:not(.appcore-radio--disabled) .appcore-radio__input:not(:checked)+.appcore-radio__circle{border-color:#0c558c}.appcore-radio__input:focus-visible+.appcore-radio__circle{box-shadow:0 0 0 2px #007bff}.appcore-radio__input:checked+.appcore-radio__circle{background-color:#0c558c;border-color:#0c558c}.appcore-radio__input:checked+.appcore-radio__circle:after{content:\"\";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:6px;height:6px;border-radius:50%;background-color:#fff}.appcore-radio__label{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#111}.appcore-radio--size-md .appcore-radio__label{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio--size-lg .appcore-radio__control{width:20px;height:20px}.appcore-radio--size-lg .appcore-radio__input:checked+.appcore-radio__circle:after{width:8px;height:8px}.appcore-radio--size-lg .appcore-radio__label{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio-group{display:inline-flex;flex-direction:column;gap:.5rem;font-family:Inter,sans-serif}.appcore-radio-group--horizontal{flex-direction:row;align-items:flex-end;gap:2.5rem}.appcore-radio-group--horizontal .appcore-radio-group__items{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-radio-group--horizontal-next-row{flex-direction:column}.appcore-radio-group--horizontal-next-row .appcore-radio-group__items{flex-direction:row;flex-wrap:wrap;gap:1rem}.appcore-radio-group--vertical{flex-direction:column}.appcore-radio-group__header{display:flex;flex-direction:column;gap:.25rem}.appcore-radio-group__label{font-size:12px;line-height:18px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500;color:#111}.appcore-radio-group__description{font-size:12px;line-height:18px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400;color:#525252}.appcore-radio-group__items{display:flex;flex-direction:column;gap:.75rem}.appcore-radio-group--size-md .appcore-radio-group__label{font-size:14px;line-height:20px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500}.appcore-radio-group--size-md .appcore-radio-group__description{font-size:14px;line-height:20px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}.appcore-radio-group--size-lg .appcore-radio-group__label{font-size:16px;line-height:22px;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:500}.appcore-radio-group--size-lg .appcore-radio-group__description{font-size:16px;line-height:22px;font-weight:500;letter-spacing:.01em;font-family:Inter,sans-serif;font-weight:400}\n"] }]
        }], propDecorators: { items: [{
                type: Input
            }], value: [{
                type: Input
            }], groupLabel: [{
                type: Input
            }], groupDescription: [{
                type: Input
            }], orientation: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

class SegmentedControlItemComponent {
    constructor() {
        this.label = 'Label';
        this.size = 'M';
        this.state = 'default';
        this.showIcon = false;
        this.iconName = 'add';
        this.iconSet = 'material';
        this.itemClick = new EventEmitter();
    }
    onClick() {
        if (this.state !== 'disabled' && this.state !== 'disabled-selected') {
            this.itemClick.emit();
        }
    }
    onMouseEnter() {
        if (this.state === 'default') {
            this.state = 'hover';
        }
    }
    onMouseLeave() {
        if (this.state === 'hover') {
            this.state = 'default';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: SegmentedControlItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: SegmentedControlItemComponent, isStandalone: true, selector: "app-segmented-control-item", inputs: { label: "label", size: "size", state: "state", showIcon: "showIcon", iconName: "iconName", iconSet: "iconSet", iconSrc: "iconSrc" }, outputs: { itemClick: "itemClick" }, ngImport: i0, template: `
    <button
      class="appcore-segment-item"
      [ngClass]="[
        'appcore-segment-item--size-' + size,
        'appcore-segment-item--state-' + state
      ]"
      [disabled]="state === 'disabled' || state === 'disabled-selected'"
      (click)="onClick()"
      (mouseenter)="onMouseEnter()"
      (mouseleave)="onMouseLeave()"
    >
      <app-icon
        *ngIf="showIcon"
        class="appcore-segment-item__icon"
        [icon]="iconName"
        [iconSet]="iconSet"
        [src]="iconSrc"
        size="sm"
      ></app-icon>
      <span class="appcore-segment-item__label">{{ label }}</span>
    </button>
  `, isInline: true, styles: [".appcore-segment-item{display:inline-flex;align-items:center;justify-content:center;gap:4px;border:none;border-radius:4px;cursor:pointer;font-family:Inter,sans-serif;transition:background-color .15s ease,color .15s ease;white-space:nowrap}.appcore-segment-item--size-S{padding:4px 8px;font-size:12px;line-height:16px}.appcore-segment-item--size-S .appcore-segment-item__label{font-size:12px;line-height:16px}.appcore-segment-item--size-M{padding:8px 12px;font-size:12px;line-height:16px}.appcore-segment-item--size-M .appcore-segment-item__label{font-size:12px;line-height:16px}.appcore-segment-item--size-L{padding:8px 12px;font-size:14px;line-height:18px}.appcore-segment-item--size-L .appcore-segment-item__label{font-size:14px;line-height:18px}.appcore-segment-item--state-default{background-color:#fff;color:#3d3d3d;font-weight:400}.appcore-segment-item--state-hover{background-color:#f5f5f5;color:#252525;font-weight:400}.appcore-segment-item--state-selected{background-color:#cedde8;color:#0c558c;font-weight:500}.appcore-segment-item--state-disabled{background-color:#fff;color:#a3a3a3;font-weight:400;cursor:not-allowed;pointer-events:none}.appcore-segment-item--state-disabled-selected{background-color:#f5f5f5;color:#a3a3a3;font-weight:500;cursor:not-allowed;pointer-events:none}.appcore-segment-item__icon{width:16px;height:16px;display:flex;align-items:center;justify-content:center}.appcore-segment-item__icon ::ng-deep .icon,.appcore-segment-item__icon ::ng-deep .material-symbols-rounded{color:inherit!important;font-size:16px!important;width:16px!important;height:16px!important}.appcore-segment-item__label{font-family:Inter,sans-serif;font-weight:inherit;color:inherit}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: SegmentedControlItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-segmented-control-item', standalone: true, imports: [CommonModule, IconComponent], template: `
    <button
      class="appcore-segment-item"
      [ngClass]="[
        'appcore-segment-item--size-' + size,
        'appcore-segment-item--state-' + state
      ]"
      [disabled]="state === 'disabled' || state === 'disabled-selected'"
      (click)="onClick()"
      (mouseenter)="onMouseEnter()"
      (mouseleave)="onMouseLeave()"
    >
      <app-icon
        *ngIf="showIcon"
        class="appcore-segment-item__icon"
        [icon]="iconName"
        [iconSet]="iconSet"
        [src]="iconSrc"
        size="sm"
      ></app-icon>
      <span class="appcore-segment-item__label">{{ label }}</span>
    </button>
  `, styles: [".appcore-segment-item{display:inline-flex;align-items:center;justify-content:center;gap:4px;border:none;border-radius:4px;cursor:pointer;font-family:Inter,sans-serif;transition:background-color .15s ease,color .15s ease;white-space:nowrap}.appcore-segment-item--size-S{padding:4px 8px;font-size:12px;line-height:16px}.appcore-segment-item--size-S .appcore-segment-item__label{font-size:12px;line-height:16px}.appcore-segment-item--size-M{padding:8px 12px;font-size:12px;line-height:16px}.appcore-segment-item--size-M .appcore-segment-item__label{font-size:12px;line-height:16px}.appcore-segment-item--size-L{padding:8px 12px;font-size:14px;line-height:18px}.appcore-segment-item--size-L .appcore-segment-item__label{font-size:14px;line-height:18px}.appcore-segment-item--state-default{background-color:#fff;color:#3d3d3d;font-weight:400}.appcore-segment-item--state-hover{background-color:#f5f5f5;color:#252525;font-weight:400}.appcore-segment-item--state-selected{background-color:#cedde8;color:#0c558c;font-weight:500}.appcore-segment-item--state-disabled{background-color:#fff;color:#a3a3a3;font-weight:400;cursor:not-allowed;pointer-events:none}.appcore-segment-item--state-disabled-selected{background-color:#f5f5f5;color:#a3a3a3;font-weight:500;cursor:not-allowed;pointer-events:none}.appcore-segment-item__icon{width:16px;height:16px;display:flex;align-items:center;justify-content:center}.appcore-segment-item__icon ::ng-deep .icon,.appcore-segment-item__icon ::ng-deep .material-symbols-rounded{color:inherit!important;font-size:16px!important;width:16px!important;height:16px!important}.appcore-segment-item__label{font-family:Inter,sans-serif;font-weight:inherit;color:inherit}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], size: [{
                type: Input
            }], state: [{
                type: Input
            }], showIcon: [{
                type: Input
            }], iconName: [{
                type: Input
            }], iconSet: [{
                type: Input
            }], iconSrc: [{
                type: Input
            }], itemClick: [{
                type: Output
            }] } });

class SegmentedControlComponent {
    constructor() {
        this.items = [
            { label: 'Label' },
            { label: 'Label' },
            { label: 'Label' }
        ];
        this.size = 'M';
        this.selectedIndex = 0;
        this.disabled = false;
        this.selectedIndexChange = new EventEmitter();
        this._selectedIndex = 0;
    }
    ngOnChanges() {
        this._selectedIndex = this.selectedIndex;
    }
    getState(index) {
        const isSelected = this._selectedIndex === index;
        const isDisabled = this.disabled || !!this.items[index]?.disabled;
        if (isDisabled && isSelected)
            return 'disabled-selected';
        if (isDisabled)
            return 'disabled';
        if (isSelected)
            return 'selected';
        return 'default';
    }
    onItemClick(index) {
        if (!this.disabled && !this.items[index]?.disabled) {
            this._selectedIndex = index;
            this.selectedIndexChange.emit(index);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: SegmentedControlComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: SegmentedControlComponent, isStandalone: true, selector: "app-segmented-control", inputs: { items: "items", size: "size", selectedIndex: "selectedIndex", disabled: "disabled" }, outputs: { selectedIndexChange: "selectedIndexChange" }, usesOnChanges: true, ngImport: i0, template: `
    <div class="appcore-segmented-control" [ngClass]="'appcore-segmented-control--size-' + size">
      <app-segmented-control-item
        *ngFor="let item of items; let i = index"
        [label]="item.label"
        [size]="size"
        [state]="getState(i)"
        [showIcon]="!!item.icon || !!item.iconSrc"
        [iconName]="item.icon || 'add'"
        [iconSet]="item.iconSet || 'material'"
        [iconSrc]="item.iconSrc"
        (itemClick)="onItemClick(i)"
      ></app-segmented-control-item>
    </div>
  `, isInline: true, styles: [".appcore-segmented-control{display:inline-flex;flex-direction:row;align-items:center;gap:4px;padding:4px;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:8px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: SegmentedControlItemComponent, selector: "app-segmented-control-item", inputs: ["label", "size", "state", "showIcon", "iconName", "iconSet", "iconSrc"], outputs: ["itemClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: SegmentedControlComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-segmented-control', standalone: true, imports: [CommonModule, SegmentedControlItemComponent], template: `
    <div class="appcore-segmented-control" [ngClass]="'appcore-segmented-control--size-' + size">
      <app-segmented-control-item
        *ngFor="let item of items; let i = index"
        [label]="item.label"
        [size]="size"
        [state]="getState(i)"
        [showIcon]="!!item.icon || !!item.iconSrc"
        [iconName]="item.icon || 'add'"
        [iconSet]="item.iconSet || 'material'"
        [iconSrc]="item.iconSrc"
        (itemClick)="onItemClick(i)"
      ></app-segmented-control-item>
    </div>
  `, styles: [".appcore-segmented-control{display:inline-flex;flex-direction:row;align-items:center;gap:4px;padding:4px;background-color:#fff;border:1px solid rgb(204,204,204);border-radius:8px}\n"] }]
        }], propDecorators: { items: [{
                type: Input
            }], size: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], disabled: [{
                type: Input
            }], selectedIndexChange: [{
                type: Output
            }] } });

const DEFAULT_BACK_BUTTON_NAV_ITEMS = [
    { label: 'Overview', level: 1 },
    { label: 'Customer Reports', level: 1 },
    { label: 'Customer Invoices', level: 1 },
    { label: 'General', level: 1, hasChildren: true },
    {
        label: 'Cloud Billing',
        level: 1,
        hasChildren: true,
        isExpanded: true,
        children: [
            { label: 'Cloud Providers', level: 2 },
            { label: 'Cloud Accounts', level: 2 },
            { label: 'Tax Profile', level: 2 },
            { label: 'Credits', level: 2 },
            { label: 'Charges & Discounts', level: 2 },
            { label: 'Detailed Billing Exports', level: 2 },
        ]
    },
];
const DEFAULT_HEADER_NAV_ITEMS = [
    { label: 'All Products', level: 1 },
    { label: 'My Products', level: 1 },
    { label: 'Product Settings', level: 1, hasChildren: true },
];
class SideNavBarComponent {
    constructor() {
        this.navStyle = 'with-back-button';
        this.backButtonLabel = 'All Customers';
        this.headerTitle = 'Products';
        this.headerIcon = 'category';
        this.activeItem = '';
        this.navItems = [];
        this.backClick = new EventEmitter();
        this.itemClick = new EventEmitter();
    }
    ngOnInit() {
        if (this.navItems.length === 0) {
            this.navItems = this.navStyle === 'with-back-button'
                ? [...DEFAULT_BACK_BUTTON_NAV_ITEMS]
                : [...DEFAULT_HEADER_NAV_ITEMS];
        }
    }
    onBackClick() {
        this.backClick.emit();
    }
    onItemClick(item) {
        if (item.hasChildren) {
            item.isExpanded = !item.isExpanded;
        }
        this.activeItem = item.label;
        this.itemClick.emit(item);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: SideNavBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: SideNavBarComponent, isStandalone: true, selector: "app-side-nav-bar", inputs: { navStyle: "navStyle", backButtonLabel: "backButtonLabel", headerTitle: "headerTitle", headerIcon: "headerIcon", activeItem: "activeItem", navItems: "navItems" }, outputs: { backClick: "backClick", itemClick: "itemClick" }, ngImport: i0, template: `
    <aside class="side-nav" [ngClass]="'side-nav--' + navStyle">

      <!-- ===== WITH BACK BUTTON STYLE ===== -->
      <ng-container *ngIf="navStyle === 'with-back-button'">
        <button class="side-nav__back-btn" (click)="onBackClick()">
          <span class="material-symbols-rounded side-nav__back-icon">chevron_left</span>
          <span class="side-nav__back-label">{{ backButtonLabel }}</span>
        </button>

        <div class="side-nav__tree">
          <ng-container *ngFor="let item of navItems">
            <ng-container *ngTemplateOutlet="treeItem; context: { $implicit: item }"></ng-container>
          </ng-container>
        </div>
      </ng-container>

      <!-- ===== WITH HEADER STYLE ===== -->
      <ng-container *ngIf="navStyle === 'with-header'">
        <div class="side-nav__header">
          <div class="side-nav__header-icon-wrap">
            <span class="material-symbols-rounded side-nav__header-icon">{{ headerIcon }}</span>
          </div>
          <div class="side-nav__header-text">
            <span class="side-nav__header-title">{{ headerTitle }}</span>
          </div>
        </div>

        <div class="side-nav__tree">
          <ng-container *ngFor="let item of navItems">
            <ng-container *ngTemplateOutlet="treeItem; context: { $implicit: item }"></ng-container>
          </ng-container>
        </div>
      </ng-container>

    </aside>

    <!-- Tree item template -->
    <ng-template #treeItem let-item>
      <div
        class="side-nav__item"
        [class.side-nav__item--level-2]="item.level === 2"
        [class.side-nav__item--active]="item.label === activeItem"
        (click)="onItemClick(item)"
      >
        <span class="side-nav__item-label">{{ item.label }}</span>
        <span
          *ngIf="item.hasChildren"
          class="material-symbols-rounded side-nav__item-chevron"
        >{{ item.isExpanded ? 'expand_less' : 'expand_more' }}</span>
      </div>

      <!-- Children (shown when expanded) -->
      <ng-container *ngIf="item.isExpanded && item.children">
        <ng-container *ngFor="let child of item.children">
          <ng-container *ngTemplateOutlet="treeItem; context: { $implicit: child }"></ng-container>
        </ng-container>
      </ng-container>
    </ng-template>
  `, isInline: true, styles: [".side-nav{display:flex;flex-direction:column;align-items:stretch;gap:16px;padding:24px;width:240px;min-height:400px;box-sizing:border-box;background-color:#e7eef3;font-family:Inter,sans-serif}.side-nav__back-btn{display:flex;flex-direction:row;justify-content:center;align-items:center;gap:8px;padding:8px 16px;background-color:#e7eef3;border:1px solid #0C558C;border-radius:4px;cursor:pointer;width:100%;box-sizing:border-box}.side-nav__back-btn:hover{background-color:#0c558c0f}.side-nav__back-icon{font-size:16px;color:#0c558c}.side-nav__back-label{font-size:12px;font-weight:500;color:#0c558c;text-transform:uppercase;letter-spacing:.02em;line-height:1.333em}.side-nav__header{display:flex;flex-direction:row;align-items:center;gap:12px;background-color:#fff;padding:8px 12px;border-radius:4px;width:100%;box-sizing:border-box}.side-nav__header-icon-wrap{display:flex;align-items:center;justify-content:center;width:32px;height:32px;background-color:#f5f5f5;border-radius:4px;flex-shrink:0}.side-nav__header-icon{font-size:20px;color:#3d3d3d}.side-nav__header-text{display:flex;flex-direction:column;gap:4px;flex:1}.side-nav__header-title{font-size:16px;font-weight:600;line-height:1.5em;color:#3d3d3d;text-transform:uppercase;letter-spacing:.02em}.side-nav__tree{display:flex;flex-direction:column;width:100%}.side-nav__item{display:flex;flex-direction:row;justify-content:center;align-items:center;gap:4px;padding:12px 8px;width:100%;box-sizing:border-box;cursor:pointer;border-radius:4px;background-color:#e7eef3;transition:background-color .15s}.side-nav__item:hover{background-color:#0c558c0d}.side-nav__item--active{background-color:#0c558c14}.side-nav__item--active .side-nav__item-label{color:#0c558c;font-weight:600}.side-nav__item--level-2{padding:12px 8px 12px 30px;border-left:1px solid #CCCCCC;border-radius:0}.side-nav__item-label{font-size:14px;font-weight:400;color:#3d3d3d;line-height:1.286em;flex:1;text-align:left}.side-nav__item-chevron{font-size:18px;color:#3d3d3d;flex-shrink:0}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MatIconModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: SideNavBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-side-nav-bar', standalone: true, imports: [CommonModule, MatIconModule], template: `
    <aside class="side-nav" [ngClass]="'side-nav--' + navStyle">

      <!-- ===== WITH BACK BUTTON STYLE ===== -->
      <ng-container *ngIf="navStyle === 'with-back-button'">
        <button class="side-nav__back-btn" (click)="onBackClick()">
          <span class="material-symbols-rounded side-nav__back-icon">chevron_left</span>
          <span class="side-nav__back-label">{{ backButtonLabel }}</span>
        </button>

        <div class="side-nav__tree">
          <ng-container *ngFor="let item of navItems">
            <ng-container *ngTemplateOutlet="treeItem; context: { $implicit: item }"></ng-container>
          </ng-container>
        </div>
      </ng-container>

      <!-- ===== WITH HEADER STYLE ===== -->
      <ng-container *ngIf="navStyle === 'with-header'">
        <div class="side-nav__header">
          <div class="side-nav__header-icon-wrap">
            <span class="material-symbols-rounded side-nav__header-icon">{{ headerIcon }}</span>
          </div>
          <div class="side-nav__header-text">
            <span class="side-nav__header-title">{{ headerTitle }}</span>
          </div>
        </div>

        <div class="side-nav__tree">
          <ng-container *ngFor="let item of navItems">
            <ng-container *ngTemplateOutlet="treeItem; context: { $implicit: item }"></ng-container>
          </ng-container>
        </div>
      </ng-container>

    </aside>

    <!-- Tree item template -->
    <ng-template #treeItem let-item>
      <div
        class="side-nav__item"
        [class.side-nav__item--level-2]="item.level === 2"
        [class.side-nav__item--active]="item.label === activeItem"
        (click)="onItemClick(item)"
      >
        <span class="side-nav__item-label">{{ item.label }}</span>
        <span
          *ngIf="item.hasChildren"
          class="material-symbols-rounded side-nav__item-chevron"
        >{{ item.isExpanded ? 'expand_less' : 'expand_more' }}</span>
      </div>

      <!-- Children (shown when expanded) -->
      <ng-container *ngIf="item.isExpanded && item.children">
        <ng-container *ngFor="let child of item.children">
          <ng-container *ngTemplateOutlet="treeItem; context: { $implicit: child }"></ng-container>
        </ng-container>
      </ng-container>
    </ng-template>
  `, styles: [".side-nav{display:flex;flex-direction:column;align-items:stretch;gap:16px;padding:24px;width:240px;min-height:400px;box-sizing:border-box;background-color:#e7eef3;font-family:Inter,sans-serif}.side-nav__back-btn{display:flex;flex-direction:row;justify-content:center;align-items:center;gap:8px;padding:8px 16px;background-color:#e7eef3;border:1px solid #0C558C;border-radius:4px;cursor:pointer;width:100%;box-sizing:border-box}.side-nav__back-btn:hover{background-color:#0c558c0f}.side-nav__back-icon{font-size:16px;color:#0c558c}.side-nav__back-label{font-size:12px;font-weight:500;color:#0c558c;text-transform:uppercase;letter-spacing:.02em;line-height:1.333em}.side-nav__header{display:flex;flex-direction:row;align-items:center;gap:12px;background-color:#fff;padding:8px 12px;border-radius:4px;width:100%;box-sizing:border-box}.side-nav__header-icon-wrap{display:flex;align-items:center;justify-content:center;width:32px;height:32px;background-color:#f5f5f5;border-radius:4px;flex-shrink:0}.side-nav__header-icon{font-size:20px;color:#3d3d3d}.side-nav__header-text{display:flex;flex-direction:column;gap:4px;flex:1}.side-nav__header-title{font-size:16px;font-weight:600;line-height:1.5em;color:#3d3d3d;text-transform:uppercase;letter-spacing:.02em}.side-nav__tree{display:flex;flex-direction:column;width:100%}.side-nav__item{display:flex;flex-direction:row;justify-content:center;align-items:center;gap:4px;padding:12px 8px;width:100%;box-sizing:border-box;cursor:pointer;border-radius:4px;background-color:#e7eef3;transition:background-color .15s}.side-nav__item:hover{background-color:#0c558c0d}.side-nav__item--active{background-color:#0c558c14}.side-nav__item--active .side-nav__item-label{color:#0c558c;font-weight:600}.side-nav__item--level-2{padding:12px 8px 12px 30px;border-left:1px solid #CCCCCC;border-radius:0}.side-nav__item-label{font-size:14px;font-weight:400;color:#3d3d3d;line-height:1.286em;flex:1;text-align:left}.side-nav__item-chevron{font-size:18px;color:#3d3d3d;flex-shrink:0}\n"] }]
        }], propDecorators: { navStyle: [{
                type: Input
            }], backButtonLabel: [{
                type: Input
            }], headerTitle: [{
                type: Input
            }], headerIcon: [{
                type: Input
            }], activeItem: [{
                type: Input
            }], navItems: [{
                type: Input
            }], backClick: [{
                type: Output
            }], itemClick: [{
                type: Output
            }] } });

class ToggleComponent {
    constructor() {
        /** Visible text label next to the toggle. */
        this.label = '';
        /** Whether the toggle is on. */
        this.checked = false;
        /** Disables interaction. */
        this.disabled = false;
        /** Visual size of the toggle. */
        this.size = 'md';
        /** Emits the new checked value when the user toggles. */
        this.checkedChange = new EventEmitter();
    }
    onNativeChange(event) {
        const input = event.target;
        this.checked = input.checked;
        this.checkedChange.emit(input.checked);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: ToggleComponent, isStandalone: true, selector: "appcore-toggle", inputs: { label: "label", checked: "checked", disabled: "disabled", size: "size" }, outputs: { checkedChange: "checkedChange" }, ngImport: i0, template: `
    <label
      class="appcore-toggle"
      [ngClass]="[
        'appcore-toggle--size-' + size,
        disabled ? 'appcore-toggle--disabled' : '',
        checked ? 'appcore-toggle--on' : ''
      ]"
    >
      <span *ngIf="label" class="appcore-toggle__label">{{ label }}</span>
      <span class="appcore-toggle__track" aria-hidden="true">
        <span class="appcore-toggle__knob"></span>
      </span>
      <input
        type="checkbox"
        class="appcore-toggle__input"
        [checked]="checked"
        [disabled]="disabled"
        (change)="onNativeChange($event)"
      />
    </label>
  `, isInline: true, styles: [".appcore-toggle{display:inline-flex;align-items:center;gap:.5rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-toggle--disabled{cursor:not-allowed}.appcore-toggle--disabled .appcore-toggle__label{color:#a3a3a3}.appcore-toggle__input{position:absolute;opacity:0;width:0;height:0;pointer-events:none}.appcore-toggle__label{font-family:Inter,sans-serif;font-weight:400;color:#3d3d3d}.appcore-toggle__track{position:relative;flex-shrink:0;border-radius:100px;background-color:#f5f5f5;border:1px solid rgb(204,204,204);transition:background-color .2s ease,border-color .2s ease;box-sizing:border-box}.appcore-toggle__knob{position:absolute;border-radius:50%;background-color:#fff;box-shadow:0 1px 3px #0003;transition:transform .2s ease;top:50%;transform:translateY(-50%)}.appcore-toggle--on:not(.appcore-toggle--disabled) .appcore-toggle__track{background-color:#0c558c;border-color:#0c558c}.appcore-toggle:focus-within .appcore-toggle__track{outline:2px solid rgb(0,123,255);outline-offset:2px}.appcore-toggle--size-sm .appcore-toggle__label{font-size:12px;line-height:16px}.appcore-toggle--size-sm .appcore-toggle__track{width:28px;height:18px}.appcore-toggle--size-sm .appcore-toggle__knob{width:14px;height:14px;left:2px;transform:translate(0) translateY(-50%)}.appcore-toggle--size-sm.appcore-toggle--on .appcore-toggle__knob{transform:translate(10px) translateY(-50%)}.appcore-toggle--size-md .appcore-toggle__label{font-size:12px;line-height:16px}.appcore-toggle--size-md .appcore-toggle__track{width:40px;height:24px}.appcore-toggle--size-md .appcore-toggle__knob{width:20px;height:20px;left:2px;transform:translate(0) translateY(-50%)}.appcore-toggle--size-md.appcore-toggle--on .appcore-toggle__knob{transform:translate(16px) translateY(-50%)}.appcore-toggle--size-lg .appcore-toggle__label{font-size:14px;line-height:18px}.appcore-toggle--size-lg .appcore-toggle__track{width:56px;height:32px}.appcore-toggle--size-lg .appcore-toggle__knob{width:28px;height:28px;left:2px;transform:translate(0) translateY(-50%)}.appcore-toggle--size-lg.appcore-toggle--on .appcore-toggle__knob{transform:translate(24px) translateY(-50%)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'appcore-toggle', standalone: true, imports: [CommonModule], template: `
    <label
      class="appcore-toggle"
      [ngClass]="[
        'appcore-toggle--size-' + size,
        disabled ? 'appcore-toggle--disabled' : '',
        checked ? 'appcore-toggle--on' : ''
      ]"
    >
      <span *ngIf="label" class="appcore-toggle__label">{{ label }}</span>
      <span class="appcore-toggle__track" aria-hidden="true">
        <span class="appcore-toggle__knob"></span>
      </span>
      <input
        type="checkbox"
        class="appcore-toggle__input"
        [checked]="checked"
        [disabled]="disabled"
        (change)="onNativeChange($event)"
      />
    </label>
  `, styles: [".appcore-toggle{display:inline-flex;align-items:center;gap:.5rem;cursor:pointer;font-family:Inter,sans-serif;-webkit-user-select:none;user-select:none}.appcore-toggle--disabled{cursor:not-allowed}.appcore-toggle--disabled .appcore-toggle__label{color:#a3a3a3}.appcore-toggle__input{position:absolute;opacity:0;width:0;height:0;pointer-events:none}.appcore-toggle__label{font-family:Inter,sans-serif;font-weight:400;color:#3d3d3d}.appcore-toggle__track{position:relative;flex-shrink:0;border-radius:100px;background-color:#f5f5f5;border:1px solid rgb(204,204,204);transition:background-color .2s ease,border-color .2s ease;box-sizing:border-box}.appcore-toggle__knob{position:absolute;border-radius:50%;background-color:#fff;box-shadow:0 1px 3px #0003;transition:transform .2s ease;top:50%;transform:translateY(-50%)}.appcore-toggle--on:not(.appcore-toggle--disabled) .appcore-toggle__track{background-color:#0c558c;border-color:#0c558c}.appcore-toggle:focus-within .appcore-toggle__track{outline:2px solid rgb(0,123,255);outline-offset:2px}.appcore-toggle--size-sm .appcore-toggle__label{font-size:12px;line-height:16px}.appcore-toggle--size-sm .appcore-toggle__track{width:28px;height:18px}.appcore-toggle--size-sm .appcore-toggle__knob{width:14px;height:14px;left:2px;transform:translate(0) translateY(-50%)}.appcore-toggle--size-sm.appcore-toggle--on .appcore-toggle__knob{transform:translate(10px) translateY(-50%)}.appcore-toggle--size-md .appcore-toggle__label{font-size:12px;line-height:16px}.appcore-toggle--size-md .appcore-toggle__track{width:40px;height:24px}.appcore-toggle--size-md .appcore-toggle__knob{width:20px;height:20px;left:2px;transform:translate(0) translateY(-50%)}.appcore-toggle--size-md.appcore-toggle--on .appcore-toggle__knob{transform:translate(16px) translateY(-50%)}.appcore-toggle--size-lg .appcore-toggle__label{font-size:14px;line-height:18px}.appcore-toggle--size-lg .appcore-toggle__track{width:56px;height:32px}.appcore-toggle--size-lg .appcore-toggle__knob{width:28px;height:28px;left:2px;transform:translate(0) translateY(-50%)}.appcore-toggle--size-lg.appcore-toggle--on .appcore-toggle__knob{transform:translate(24px) translateY(-50%)}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], checked: [{
                type: Input
            }], disabled: [{
                type: Input
            }], size: [{
                type: Input
            }], checkedChange: [{
                type: Output
            }] } });

class TreeViewItemComponent {
    constructor() {
        this.label = 'Label';
        this.level = 1;
        this.type = 'global';
        this.state = 'default';
        this.expanded = false;
        this.hasChildren = false;
        this.showPrefixIcon = true;
        this.prefixIcon = 'add';
        this.itemClick = new EventEmitter();
        this.expandToggle = new EventEmitter();
        this._hovered = false;
        this._pressed = false;
    }
    get itemClasses() {
        const base = 'appcore-tree-view-item';
        const classes = [
            `${base}--level-${this.level}`,
            `${base}--type-${this.type}`,
            `${base}--state-${this.effectiveState}`,
        ];
        if (this.state === 'disabled') {
            classes.push(`${base}--disabled`);
        }
        return classes.join(' ');
    }
    get effectiveState() {
        if (this.state === 'disabled')
            return 'disabled';
        if (this.state === 'selected')
            return 'selected';
        if (this._pressed)
            return 'pressed';
        if (this._hovered)
            return 'hover';
        return this.state;
    }
    onMouseEnter() {
        if (this.state !== 'disabled')
            this._hovered = true;
    }
    onMouseLeave() {
        this._hovered = false;
        this._pressed = false;
    }
    onMouseDown() {
        if (this.state !== 'disabled')
            this._pressed = true;
    }
    onMouseUp() {
        this._pressed = false;
    }
    onItemClick() {
        if (this.state === 'disabled')
            return;
        if (this.hasChildren) {
            this.expandToggle.emit();
        }
        this.itemClick.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: TreeViewItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.14", type: TreeViewItemComponent, isStandalone: true, selector: "app-tree-view-item", inputs: { label: "label", level: "level", type: "type", state: "state", expanded: "expanded", hasChildren: "hasChildren", showPrefixIcon: "showPrefixIcon", prefixIcon: "prefixIcon" }, outputs: { itemClick: "itemClick", expandToggle: "expandToggle" }, ngImport: i0, template: `
    <div
      class="appcore-tree-view-item"
      [class]="itemClasses"
      [attr.aria-selected]="state === 'selected'"
      [attr.aria-disabled]="state === 'disabled'"
      [attr.aria-expanded]="hasChildren ? expanded : null"
      (click)="onItemClick()"
      (mouseenter)="onMouseEnter()"
      (mouseleave)="onMouseLeave()"
      (mousedown)="onMouseDown()"
      (mouseup)="onMouseUp()"
    >
      @if (showPrefixIcon) {
        <app-icon
          class="appcore-tree-view-item__prefix-icon"
          [icon]="prefixIcon"
          iconSet="material"
          size="sm"
        ></app-icon>
      }
      <span class="appcore-tree-view-item__label">{{ label }}</span>
      @if (hasChildren) {
        <app-icon
          class="appcore-tree-view-item__chevron"
          [icon]="expanded ? 'expand_less' : 'expand_more'"
          iconSet="material"
          size="sm"
        ></app-icon>
      }
    </div>
  `, isInline: true, styles: [".appcore-tree-view-item{display:flex;flex-direction:row;align-items:center;gap:4px;padding:12px 8px;border-radius:.25rem;cursor:pointer;font-family:Inter,sans-serif;font-size:14px;line-height:18px;font-weight:400;transition:background-color .15s ease;-webkit-user-select:none;user-select:none}.appcore-tree-view-item--disabled{cursor:not-allowed;pointer-events:none}.appcore-tree-view-item--level-1{padding-left:8px}.appcore-tree-view-item--level-2{padding-left:30px}.appcore-tree-view-item--level-3{padding-left:52px}.appcore-tree-view-item--level-4{padding-left:74px}.appcore-tree-view-item--type-global{background-color:#e7eef3;color:#3d3d3d}.appcore-tree-view-item--type-global.appcore-tree-view-item--state-hover{background-color:#cedde8;color:#252525}.appcore-tree-view-item--type-global.appcore-tree-view-item--state-pressed{background-color:#e7eef3;color:#3d3d3d}.appcore-tree-view-item--type-global.appcore-tree-view-item--state-selected{background-color:#cedde8;color:#3d3d3d;font-weight:600}.appcore-tree-view-item--type-global.appcore-tree-view-item--state-disabled{background-color:#f5f5f5;color:#a3a3a3}.appcore-tree-view-item--type-local{background-color:#fff;color:#3d3d3d}.appcore-tree-view-item--type-local.appcore-tree-view-item--state-hover{background-color:#ebebeb;color:#252525}.appcore-tree-view-item--type-local.appcore-tree-view-item--state-pressed{background-color:#f5f5f5;color:#3d3d3d}.appcore-tree-view-item--type-local.appcore-tree-view-item--state-selected{background-color:#e7eef3;color:#3d3d3d;font-weight:600}.appcore-tree-view-item--type-local.appcore-tree-view-item--state-disabled{background-color:#f5f5f5;color:#a3a3a3}.appcore-tree-view-item__prefix-icon{flex-shrink:0;width:18px;height:18px;display:flex;align-items:center;justify-content:center}.appcore-tree-view-item__prefix-icon .material-symbols-rounded{font-size:18px!important;width:18px!important;height:18px!important}.appcore-tree-view-item__label{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.appcore-tree-view-item__chevron{flex-shrink:0;margin-left:auto;width:18px;height:18px;display:flex;align-items:center;justify-content:center}.appcore-tree-view-item__chevron .material-symbols-rounded{font-size:18px!important;width:18px!important;height:18px!important}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon", "src", "iconSet", "size", "alt", "color", "background"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: TreeViewItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-tree-view-item', standalone: true, imports: [CommonModule, IconComponent], template: `
    <div
      class="appcore-tree-view-item"
      [class]="itemClasses"
      [attr.aria-selected]="state === 'selected'"
      [attr.aria-disabled]="state === 'disabled'"
      [attr.aria-expanded]="hasChildren ? expanded : null"
      (click)="onItemClick()"
      (mouseenter)="onMouseEnter()"
      (mouseleave)="onMouseLeave()"
      (mousedown)="onMouseDown()"
      (mouseup)="onMouseUp()"
    >
      @if (showPrefixIcon) {
        <app-icon
          class="appcore-tree-view-item__prefix-icon"
          [icon]="prefixIcon"
          iconSet="material"
          size="sm"
        ></app-icon>
      }
      <span class="appcore-tree-view-item__label">{{ label }}</span>
      @if (hasChildren) {
        <app-icon
          class="appcore-tree-view-item__chevron"
          [icon]="expanded ? 'expand_less' : 'expand_more'"
          iconSet="material"
          size="sm"
        ></app-icon>
      }
    </div>
  `, styles: [".appcore-tree-view-item{display:flex;flex-direction:row;align-items:center;gap:4px;padding:12px 8px;border-radius:.25rem;cursor:pointer;font-family:Inter,sans-serif;font-size:14px;line-height:18px;font-weight:400;transition:background-color .15s ease;-webkit-user-select:none;user-select:none}.appcore-tree-view-item--disabled{cursor:not-allowed;pointer-events:none}.appcore-tree-view-item--level-1{padding-left:8px}.appcore-tree-view-item--level-2{padding-left:30px}.appcore-tree-view-item--level-3{padding-left:52px}.appcore-tree-view-item--level-4{padding-left:74px}.appcore-tree-view-item--type-global{background-color:#e7eef3;color:#3d3d3d}.appcore-tree-view-item--type-global.appcore-tree-view-item--state-hover{background-color:#cedde8;color:#252525}.appcore-tree-view-item--type-global.appcore-tree-view-item--state-pressed{background-color:#e7eef3;color:#3d3d3d}.appcore-tree-view-item--type-global.appcore-tree-view-item--state-selected{background-color:#cedde8;color:#3d3d3d;font-weight:600}.appcore-tree-view-item--type-global.appcore-tree-view-item--state-disabled{background-color:#f5f5f5;color:#a3a3a3}.appcore-tree-view-item--type-local{background-color:#fff;color:#3d3d3d}.appcore-tree-view-item--type-local.appcore-tree-view-item--state-hover{background-color:#ebebeb;color:#252525}.appcore-tree-view-item--type-local.appcore-tree-view-item--state-pressed{background-color:#f5f5f5;color:#3d3d3d}.appcore-tree-view-item--type-local.appcore-tree-view-item--state-selected{background-color:#e7eef3;color:#3d3d3d;font-weight:600}.appcore-tree-view-item--type-local.appcore-tree-view-item--state-disabled{background-color:#f5f5f5;color:#a3a3a3}.appcore-tree-view-item__prefix-icon{flex-shrink:0;width:18px;height:18px;display:flex;align-items:center;justify-content:center}.appcore-tree-view-item__prefix-icon .material-symbols-rounded{font-size:18px!important;width:18px!important;height:18px!important}.appcore-tree-view-item__label{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.appcore-tree-view-item__chevron{flex-shrink:0;margin-left:auto;width:18px;height:18px;display:flex;align-items:center;justify-content:center}.appcore-tree-view-item__chevron .material-symbols-rounded{font-size:18px!important;width:18px!important;height:18px!important}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], level: [{
                type: Input
            }], type: [{
                type: Input
            }], state: [{
                type: Input
            }], expanded: [{
                type: Input
            }], hasChildren: [{
                type: Input
            }], showPrefixIcon: [{
                type: Input
            }], prefixIcon: [{
                type: Input
            }], itemClick: [{
                type: Output
            }], expandToggle: [{
                type: Output
            }] } });

// ── Default demo data ─────────────────────────────────────────────────────────
const DEFAULT_NODES = [
    {
        label: 'Parent Item',
        children: [
            {
                label: 'Child Item',
                children: [
                    { label: 'Grandchild Item' },
                    { label: 'Grandchild Item' },
                ],
            },
            { label: 'Child Item' },
            { label: 'Child Item' },
        ],
    },
    { label: 'Parent Item' },
    { label: 'Parent Item' },
];
// ─────────────────────────────────────────────────────────────────────────────
class TreeViewComponent {
    constructor() {
        /**
         * Hierarchical node data. Provide your own `TreeViewNode[]`
         * — the component handles flattening and expansion internally.
         */
        this.nodes = DEFAULT_NODES;
        /** Visual theme: 'global' (blue-tinted bg) or 'local' (white bg). */
        this.type = 'global';
        /** Show the leading icon on every row. */
        this.showIcons = true;
        /** ID of the currently selected node (matched on object reference via `_source`). */
        this.selectedNode = null;
        /** Emits when the user clicks a non-disabled node. */
        this.nodeSelect = new EventEmitter();
        /** Emits when a parent node is expanded or collapsed. */
        this.nodeToggle = new EventEmitter();
        // ── Material tree plumbing ─────────────────────────────────────────────────
        this.transformer = (node, level) => ({
            label: node.label,
            icon: node.icon,
            disabled: node.disabled,
            data: node.data,
            level,
            expandable: !!(node.children && node.children.length > 0),
            _source: node,
        });
        this.treeControl = new FlatTreeControl(flat => flat.level, flat => flat.expandable);
        this.flattener = new MatTreeFlattener(this.transformer, flat => flat.level, flat => flat.expandable, node => node.children ?? []);
        this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.flattener);
        // ── Template helpers ───────────────────────────────────────────────────────
        this.hasChild = (_, flat) => flat.expandable;
    }
    // ── Lifecycle ──────────────────────────────────────────────────────────────
    ngOnChanges(changes) {
        if (changes['nodes']) {
            this.dataSource.data = this.nodes;
        }
    }
    clampLevel(level) {
        return Math.min(Math.max(level, 1), 4);
    }
    stateOf(flat) {
        if (flat.disabled)
            return 'disabled';
        if (flat._source === this.selectedNode)
            return 'selected';
        return 'default';
    }
    // ── Event handlers ─────────────────────────────────────────────────────────
    onSelect(flat) {
        if (flat.disabled)
            return;
        this.selectedNode = flat._source;
        this.nodeSelect.emit(flat._source);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: TreeViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: TreeViewComponent, isStandalone: true, selector: "app-tree-view", inputs: { nodes: "nodes", type: "type", showIcons: "showIcons", selectedNode: "selectedNode" }, outputs: { nodeSelect: "nodeSelect", nodeToggle: "nodeToggle" }, usesOnChanges: true, ngImport: i0, template: `
    <mat-tree
      class="appcore-tree-view"
      [dataSource]="dataSource"
      [treeControl]="treeControl"
      role="tree"
    >
      <mat-tree-node
        *matTreeNodeDef="let flat"
        class="appcore-tree-view__node"
        matTreeNodePadding
        [matTreeNodePaddingIndent]="0"
      >
        <app-tree-view-item
          [label]="flat.label"
          [level]="clampLevel(flat.level + 1)"
          [type]="type"
          [state]="stateOf(flat)"
          [hasChildren]="false"
          [showPrefixIcon]="showIcons"
          [prefixIcon]="flat.icon || 'add'"
          (itemClick)="onSelect(flat)"
        ></app-tree-view-item>
      </mat-tree-node>

      <mat-tree-node
        *matTreeNodeDef="let flat; when: hasChild"
        class="appcore-tree-view__node"
        matTreeNodePadding
        [matTreeNodePaddingIndent]="0"
      >
        <app-tree-view-item
          [label]="flat.label"
          [level]="clampLevel(flat.level + 1)"
          [type]="type"
          [state]="stateOf(flat)"
          [hasChildren]="true"
          [expanded]="treeControl.isExpanded(flat)"
          [showPrefixIcon]="showIcons"
          [prefixIcon]="flat.icon || 'add'"
          (itemClick)="onSelect(flat)"
          (expandToggle)="treeControl.toggle(flat)"
        ></app-tree-view-item>
      </mat-tree-node>
    </mat-tree>
  `, isInline: true, styles: [".appcore-tree-view{display:flex;flex-direction:column;gap:2px;width:220px;background:transparent!important;padding:0!important;border-radius:.25rem}.appcore-tree-view .mat-tree-node,.appcore-tree-view .appcore-tree-view__node{min-height:unset!important;padding:0!important;display:block}.appcore-tree-view .mat-tree-node>app-tree-view-item,.appcore-tree-view .appcore-tree-view__node>app-tree-view-item{display:block;width:100%}.appcore-tree-view .mat-tree-node>app-tree-view-item .appcore-tree-view-item,.appcore-tree-view .appcore-tree-view__node>app-tree-view-item .appcore-tree-view-item{width:100%;box-sizing:border-box}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatTreeModule }, { kind: "directive", type: i1$2.MatTreeNodeDef, selector: "[matTreeNodeDef]", inputs: ["matTreeNodeDefWhen", "matTreeNode"] }, { kind: "directive", type: i1$2.MatTreeNodePadding, selector: "[matTreeNodePadding]", inputs: ["matTreeNodePadding", "matTreeNodePaddingIndent"] }, { kind: "component", type: i1$2.MatTree, selector: "mat-tree", exportAs: ["matTree"] }, { kind: "directive", type: i1$2.MatTreeNode, selector: "mat-tree-node", inputs: ["tabIndex", "disabled"], outputs: ["activation", "expandedChange"], exportAs: ["matTreeNode"] }, { kind: "component", type: TreeViewItemComponent, selector: "app-tree-view-item", inputs: ["label", "level", "type", "state", "expanded", "hasChildren", "showPrefixIcon", "prefixIcon"], outputs: ["itemClick", "expandToggle"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: TreeViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-tree-view', standalone: true, imports: [CommonModule, MatTreeModule, TreeViewItemComponent], template: `
    <mat-tree
      class="appcore-tree-view"
      [dataSource]="dataSource"
      [treeControl]="treeControl"
      role="tree"
    >
      <mat-tree-node
        *matTreeNodeDef="let flat"
        class="appcore-tree-view__node"
        matTreeNodePadding
        [matTreeNodePaddingIndent]="0"
      >
        <app-tree-view-item
          [label]="flat.label"
          [level]="clampLevel(flat.level + 1)"
          [type]="type"
          [state]="stateOf(flat)"
          [hasChildren]="false"
          [showPrefixIcon]="showIcons"
          [prefixIcon]="flat.icon || 'add'"
          (itemClick)="onSelect(flat)"
        ></app-tree-view-item>
      </mat-tree-node>

      <mat-tree-node
        *matTreeNodeDef="let flat; when: hasChild"
        class="appcore-tree-view__node"
        matTreeNodePadding
        [matTreeNodePaddingIndent]="0"
      >
        <app-tree-view-item
          [label]="flat.label"
          [level]="clampLevel(flat.level + 1)"
          [type]="type"
          [state]="stateOf(flat)"
          [hasChildren]="true"
          [expanded]="treeControl.isExpanded(flat)"
          [showPrefixIcon]="showIcons"
          [prefixIcon]="flat.icon || 'add'"
          (itemClick)="onSelect(flat)"
          (expandToggle)="treeControl.toggle(flat)"
        ></app-tree-view-item>
      </mat-tree-node>
    </mat-tree>
  `, styles: [".appcore-tree-view{display:flex;flex-direction:column;gap:2px;width:220px;background:transparent!important;padding:0!important;border-radius:.25rem}.appcore-tree-view .mat-tree-node,.appcore-tree-view .appcore-tree-view__node{min-height:unset!important;padding:0!important;display:block}.appcore-tree-view .mat-tree-node>app-tree-view-item,.appcore-tree-view .appcore-tree-view__node>app-tree-view-item{display:block;width:100%}.appcore-tree-view .mat-tree-node>app-tree-view-item .appcore-tree-view-item,.appcore-tree-view .appcore-tree-view__node>app-tree-view-item .appcore-tree-view-item{width:100%;box-sizing:border-box}\n"] }]
        }], propDecorators: { nodes: [{
                type: Input
            }], type: [{
                type: Input
            }], showIcons: [{
                type: Input
            }], selectedNode: [{
                type: Input
            }], nodeSelect: [{
                type: Output
            }], nodeToggle: [{
                type: Output
            }] } });

/*
 * Public API Surface of uilib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ActionbarComponent, AlertComponent, BadgeComponent, BadgeIndicatorComponent, BannerComponent, BreadcrumbComponent, ButtonComponent, CheckboxComponent, CheckboxGroupComponent, ColumnManagerComponent, ComboboxComponent, ContentLoaderDotsComponent, DatePickerComponent, DateRangePickerComponent, DescriptionItemComponent, DescriptionListComponent, DialogueBoxComponent, FooterComponent, HeaderComponent, IconComponent, InlineLoaderComponent, InlineLoaderWithTextComponent, ModalComponent, MonthPickerComponent, NavBarComponent, NumericStepperComponent, OverlayComponent, PageLoaderComponent, ProgressStepperComponent, RadioButtonComponent, RadioButtonGroupComponent, SegmentedControlComponent, SegmentedControlItemComponent, SideNavBarComponent, ToggleComponent, TreeViewComponent, TreeViewItemComponent, UilibComponent, UilibService };
//# sourceMappingURL=uilib.mjs.map
