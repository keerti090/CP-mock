import * as i0 from "@angular/core";
export type BadgeIndicatorType = 'Default' | 'Error' | 'Success' | 'Warning' | 'Inactive';
export type BadgeIndicatorStyle = 'Dot - Inline' | 'Dot - Overlapping' | 'With Text' | 'With Text - Overlapping';
export declare class BadgeIndicatorComponent {
    type: BadgeIndicatorType;
    indicatorStyle: BadgeIndicatorStyle;
    label: string;
    count: string;
    get styleKey(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeIndicatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeIndicatorComponent, "app-badge-indicator", never, { "type": { "alias": "type"; "required": false; }; "indicatorStyle": { "alias": "indicatorStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "count": { "alias": "count"; "required": false; }; }, {}, never, never, true, never>;
}
