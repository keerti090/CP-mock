import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type BannerType = 'Information' | 'Success' | 'Warning' | 'Error';
export declare class BannerComponent {
    type: BannerType;
    title: string;
    description: string;
    showIcon: boolean;
    dismissible: boolean;
    actionLabel: string;
    dismiss: EventEmitter<void>;
    action: EventEmitter<void>;
    get iconName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BannerComponent, "appcore-banner", never, { "type": { "alias": "type"; "required": false; }; "title": { "alias": "title"; "required": false; }; "description": { "alias": "description"; "required": false; }; "showIcon": { "alias": "showIcon"; "required": false; }; "dismissible": { "alias": "dismissible"; "required": false; }; "actionLabel": { "alias": "actionLabel"; "required": false; }; }, { "dismiss": "dismiss"; "action": "action"; }, never, never, true, never>;
}
