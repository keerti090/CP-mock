import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type ModalSize = 'S' | 'M' | 'L' | 'XL';
export declare class ModalComponent {
    visible: boolean;
    size: ModalSize;
    title: string;
    subtitle: string;
    cancelLabel: string;
    confirmLabel: string;
    closeOnOverlayClick: boolean;
    close: EventEmitter<void>;
    cancel: EventEmitter<void>;
    confirm: EventEmitter<void>;
    onOverlayClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModalComponent, "appcore-modal", never, { "visible": { "alias": "visible"; "required": false; }; "size": { "alias": "size"; "required": false; }; "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; }; "closeOnOverlayClick": { "alias": "closeOnOverlayClick"; "required": false; }; }, { "close": "close"; "cancel": "cancel"; "confirm": "confirm"; }, never, ["*"], true, never>;
}
