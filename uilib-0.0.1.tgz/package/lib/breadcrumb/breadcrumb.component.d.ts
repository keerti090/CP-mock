import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export interface BreadcrumbItem {
    label: string;
    href?: string;
}
export type BreadcrumbSize = 'S' | 'M' | 'L';
export declare class BreadcrumbComponent {
    items: BreadcrumbItem[];
    size: BreadcrumbSize;
    itemClick: EventEmitter<{
        item: BreadcrumbItem;
        index: number;
    }>;
    onItemClick(event: Event, item: BreadcrumbItem, index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbComponent, "app-breadcrumb", never, { "items": { "alias": "items"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, { "itemClick": "itemClick"; }, never, never, true, never>;
}
