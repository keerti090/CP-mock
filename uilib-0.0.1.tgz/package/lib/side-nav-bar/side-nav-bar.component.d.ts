import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type SideNavBarStyle = 'with-back-button' | 'with-header';
export interface TreeNavItem {
    label: string;
    level?: 1 | 2;
    hasChildren?: boolean;
    isExpanded?: boolean;
    children?: TreeNavItem[];
}
export declare class SideNavBarComponent {
    navStyle: SideNavBarStyle;
    backButtonLabel: string;
    headerTitle: string;
    headerIcon: string;
    activeItem: string;
    navItems: TreeNavItem[];
    backClick: EventEmitter<void>;
    itemClick: EventEmitter<TreeNavItem>;
    ngOnInit(): void;
    onBackClick(): void;
    onItemClick(item: TreeNavItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SideNavBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SideNavBarComponent, "app-side-nav-bar", never, { "navStyle": { "alias": "navStyle"; "required": false; }; "backButtonLabel": { "alias": "backButtonLabel"; "required": false; }; "headerTitle": { "alias": "headerTitle"; "required": false; }; "headerIcon": { "alias": "headerIcon"; "required": false; }; "activeItem": { "alias": "activeItem"; "required": false; }; "navItems": { "alias": "navItems"; "required": false; }; }, { "backClick": "backClick"; "itemClick": "itemClick"; }, never, never, true, never>;
}
