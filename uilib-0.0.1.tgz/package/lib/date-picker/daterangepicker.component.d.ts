import { EventEmitter, ElementRef, OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export type DateRangePickerSize = 'sm' | 'md' | 'lg';
export interface DateRange {
    start: Date | null;
    end: Date | null;
}
export declare class DateRangePickerComponent implements OnChanges {
    private elementRef;
    /** Currently selected date range. */
    value: DateRange | null;
    /** Field label rendered above the control. */
    label: string;
    /** Placeholder shown when no range is selected. */
    placeholder: string;
    /** Helper text shown below the control in the default state. */
    helperText: string;
    /** Error message shown when error=true. */
    errorMessage: string;
    /** Visual size of the picker. */
    size: DateRangePickerSize;
    /** Disables all interaction. */
    disabled: boolean;
    /** Shows error styling and errorMessage. */
    error: boolean;
    /** Earliest selectable date (inclusive). */
    minDate: Date | null;
    /** Latest selectable date (inclusive). */
    maxDate: Date | null;
    /** Emits the completed DateRange (or null when cleared). */
    valueChange: EventEmitter<DateRange | null>;
    readonly weekdays: string[];
    isOpen: boolean;
    leftViewYear: number;
    leftViewMonth: number;
    /** Pending start date — set on first click, waiting for the end click. */
    pendingStart: Date | null;
    /** Currently hovered date used for range preview during selection. */
    hoverDate: Date | null;
    constructor(elementRef: ElementRef);
    ngOnChanges(): void;
    onDocumentClick(event: Event): void;
    open(): void;
    close(): void;
    onControlClick(): void;
    cancelPending(): void;
    prevMonth(): void;
    nextMonth(): void;
    get rightViewMonth(): number;
    get rightViewYear(): number;
    selectDay(cell: CalendarCell): void;
    onDayHover(cell: CalendarCell): void;
    onDayLeave(): void;
    clear(event: Event): void;
    get hasValue(): boolean;
    get hasDisplayValue(): boolean;
    get displayValue(): string;
    get leftMonthYearLabel(): string;
    get rightMonthYearLabel(): string;
    get leftCalendarCells(): CalendarCell[];
    get rightCalendarCells(): CalendarCell[];
    private buildCalendarCells;
    private buildCell;
    formatDate(date: Date): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateRangePickerComponent, "appcore-daterangepicker", never, { "value": { "alias": "value"; "required": false; }; "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "helperText": { "alias": "helperText"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "error": { "alias": "error"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
interface CalendarCell {
    date: Date;
    inMonth: boolean;
    isToday: boolean;
    isDisabled: boolean;
    isRangeStart: boolean;
    isRangeEnd: boolean;
    isInRange: boolean;
}
export {};
