import { EventEmitter, ElementRef, OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export type DatePickerSize = 'sm' | 'md' | 'lg';
export declare class DatePickerComponent implements OnChanges {
    private elementRef;
    /** Currently selected date. */
    value: Date | null;
    /** Field label rendered above the control. */
    label: string;
    /** Placeholder shown when no date is selected. */
    placeholder: string;
    /** Helper text shown below the control in the default state. */
    helperText: string;
    /** Error message shown when error=true. */
    errorMessage: string;
    /** Visual size of the picker. */
    size: DatePickerSize;
    /** Disables all interaction. */
    disabled: boolean;
    /** Shows error styling and errorMessage. */
    error: boolean;
    /** Earliest selectable date (inclusive). */
    minDate: Date | null;
    /** Latest selectable date (inclusive). */
    maxDate: Date | null;
    /** Emits the selected Date (or null when cleared). */
    valueChange: EventEmitter<Date | null>;
    readonly weekdays: string[];
    isOpen: boolean;
    viewYear: number;
    viewMonth: number;
    constructor(elementRef: ElementRef);
    ngOnChanges(): void;
    onDocumentClick(event: Event): void;
    open(): void;
    close(): void;
    onControlClick(): void;
    prevMonth(): void;
    nextMonth(): void;
    selectDay(cell: CalendarCell): void;
    clear(event: Event): void;
    get monthYearLabel(): string;
    get calendarCells(): CalendarCell[];
    private buildCell;
    formatDate(date: Date): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatePickerComponent, "appcore-datepicker", never, { "value": { "alias": "value"; "required": false; }; "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "helperText": { "alias": "helperText"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "error": { "alias": "error"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
interface CalendarCell {
    date: Date;
    inMonth: boolean;
    isToday: boolean;
    isSelected: boolean;
    isDisabled: boolean;
}
export {};
