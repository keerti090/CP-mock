import { EventEmitter, ElementRef, OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export type MonthPickerSize = 'sm' | 'md' | 'lg';
export interface MonthValue {
    /** Full four-digit year, e.g. 2025 */
    year: number;
    /** Zero-based month index (0 = January … 11 = December) */
    month: number;
}
interface MonthCell {
    /** Short month label shown in the grid (e.g. "Jan") */
    label: string;
    /** Zero-based month index */
    month: number;
    isSelected: boolean;
    isCurrentMonth: boolean;
    isDisabled: boolean;
}
export declare class MonthPickerComponent implements OnChanges {
    private elementRef;
    /** Currently selected month/year. */
    value: MonthValue | null;
    /** Field label rendered above the control. */
    label: string;
    /** Placeholder shown when no month is selected. */
    placeholder: string;
    /** Helper text shown below the control in the default state. */
    helperText: string;
    /** Error message shown when error=true. */
    errorMessage: string;
    /** Visual size of the picker. */
    size: MonthPickerSize;
    /** Disables all interaction. */
    disabled: boolean;
    /** Shows error styling and errorMessage. */
    error: boolean;
    /** Earliest selectable month (inclusive). */
    minValue: MonthValue | null;
    /** Latest selectable month (inclusive). */
    maxValue: MonthValue | null;
    /** Emits the selected MonthValue (or null when cleared). */
    valueChange: EventEmitter<MonthValue | null>;
    readonly monthLabels: string[];
    isOpen: boolean;
    viewYear: number;
    constructor(elementRef: ElementRef);
    ngOnChanges(): void;
    onDocumentClick(event: Event): void;
    open(): void;
    close(): void;
    onControlClick(): void;
    prevYear(): void;
    nextYear(): void;
    selectMonth(cell: MonthCell): void;
    clear(event: Event): void;
    get monthCells(): MonthCell[];
    formatValue(v: MonthValue): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MonthPickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MonthPickerComponent, "appcore-monthpicker", never, { "value": { "alias": "value"; "required": false; }; "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "helperText": { "alias": "helperText"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "error": { "alias": "error"; "required": false; }; "minValue": { "alias": "minValue"; "required": false; }; "maxValue": { "alias": "maxValue"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
export {};
