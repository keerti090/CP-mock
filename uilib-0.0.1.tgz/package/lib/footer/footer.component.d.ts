import * as i0 from "@angular/core";
export type FooterPlatform = 'TC' | 'WLMP';
export declare class FooterComponent {
    platform: FooterPlatform;
    tcLinks: string[];
    wlmpMenuLinks: string[];
    tagline: string;
    contactEmail: string;
    copyrightText: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FooterComponent, "app-footer", never, { "platform": { "alias": "platform"; "required": false; }; "tcLinks": { "alias": "tcLinks"; "required": false; }; "wlmpMenuLinks": { "alias": "wlmpMenuLinks"; "required": false; }; "tagline": { "alias": "tagline"; "required": false; }; "contactEmail": { "alias": "contactEmail"; "required": false; }; "copyrightText": { "alias": "copyrightText"; "required": false; }; }, {}, never, never, true, never>;
}
