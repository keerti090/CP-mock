import { AfterContentInit, ElementRef, EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ButtonComponent implements AfterContentInit {
    buttonText: boolean;
    label: string;
    size: 'small' | 'medium' | 'large';
    state: 'default' | 'hover' | 'pressed' | 'disabled' | 'error' | 'success' | 'loading';
    type: 'primary' | 'secondary' | 'tertiary' | 'toned' | 'link';
    nativeType: 'button' | 'submit' | 'reset';
    buttonClick: EventEmitter<void>;
    showLeftIcon: boolean;
    showRightIcon: boolean;
    leftIconName: string;
    rightIconName: string;
    /** Icon set for left icon: 'material' (default) or 'asset' (assets/icons/<leftIconName>.svg). */
    leftIconSet: 'material' | 'asset';
    /** Icon set for right icon: 'material' (default) or 'asset'. */
    rightIconSet: 'material' | 'asset';
    /** Custom left icon URL. When set, overrides leftIconName/leftIconSet (use for external or custom SVGs). */
    leftIconSrc?: string;
    /** Custom right icon URL. When set, overrides rightIconName/rightIconSet. */
    rightIconSrc?: string;
    leftIcon?: ElementRef;
    rightIcon?: ElementRef;
    hasLeftIcon: boolean;
    hasRightIcon: boolean;
    ngAfterContentInit(): void;
    onHover(): void;
    onLeave(): void;
    onPressed(): void;
    onReleased(): void;
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "appcore-button", never, { "buttonText": { "alias": "buttonText"; "required": false; }; "label": { "alias": "label"; "required": false; }; "size": { "alias": "size"; "required": false; }; "state": { "alias": "state"; "required": false; }; "type": { "alias": "type"; "required": false; }; "nativeType": { "alias": "nativeType"; "required": false; }; "showLeftIcon": { "alias": "showLeftIcon"; "required": false; }; "showRightIcon": { "alias": "showRightIcon"; "required": false; }; "leftIconName": { "alias": "leftIconName"; "required": false; }; "rightIconName": { "alias": "rightIconName"; "required": false; }; "leftIconSet": { "alias": "leftIconSet"; "required": false; }; "rightIconSet": { "alias": "rightIconSet"; "required": false; }; "leftIconSrc": { "alias": "leftIconSrc"; "required": false; }; "rightIconSrc": { "alias": "rightIconSrc"; "required": false; }; }, { "buttonClick": "buttonClick"; }, ["leftIcon", "rightIcon"], ["[leftIconSwap]", "[rightIconSwap]"], true, never>;
}
