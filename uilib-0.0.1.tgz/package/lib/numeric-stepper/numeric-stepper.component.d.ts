import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type NumericStepperVariant = 'left-input' | 'center-input';
export type NumericStepperLabelPosition = 'vertical' | 'horizontal';
export declare class NumericStepperComponent {
    /** Which stepper layout to render. */
    variant: NumericStepperVariant;
    /** For center-input: whether the label sits above (vertical) or beside (horizontal) the control. */
    labelPosition: NumericStepperLabelPosition;
    /** Visible label text. */
    label: string;
    /** Shows the required asterisk (*) next to the label. */
    required: boolean;
    /** Current numeric value. */
    value: number;
    /** Minimum allowed value. */
    min?: number;
    /** Maximum allowed value. */
    max?: number;
    /** Amount to increment/decrement per step. */
    step: number;
    /** Disables all interaction. */
    disabled: boolean;
    /** Applies error border styling. */
    error: boolean;
    /** Emits the updated value after increment, decrement, or manual input. */
    valueChange: EventEmitter<number>;
    isFocused: boolean;
    get displayValue(): string;
    increment(): void;
    decrement(): void;
    onFocus(): void;
    onBlur(event: FocusEvent): void;
    onInputChange(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumericStepperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NumericStepperComponent, "appcore-numeric-stepper", never, { "variant": { "alias": "variant"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "label": { "alias": "label"; "required": false; }; "required": { "alias": "required"; "required": false; }; "value": { "alias": "value"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "error": { "alias": "error"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
