import * as i0 from "@angular/core";
export type BadgeType = 'Default' | 'Error' | 'Success' | 'Warning' | 'Information';
export type BadgeStyle = 'Outlined' | 'Toned' | 'Highlighted';
export type BadgeSize = 'S' | 'M' | 'L';
export declare class BadgeComponent {
    label: string;
    type: BadgeType;
    badgeStyle: BadgeStyle;
    size: BadgeSize;
    showPrefixIcon: boolean;
    showSuffixIcon: boolean;
    prefixIcon: string;
    prefixIconSet: 'material' | 'asset';
    prefixIconSrc?: string;
    suffixIcon: string;
    suffixIconSet: 'material' | 'asset';
    suffixIconSrc?: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeComponent, "app-badge", never, { "label": { "alias": "label"; "required": false; }; "type": { "alias": "type"; "required": false; }; "badgeStyle": { "alias": "badgeStyle"; "required": false; }; "size": { "alias": "size"; "required": false; }; "showPrefixIcon": { "alias": "showPrefixIcon"; "required": false; }; "showSuffixIcon": { "alias": "showSuffixIcon"; "required": false; }; "prefixIcon": { "alias": "prefixIcon"; "required": false; }; "prefixIconSet": { "alias": "prefixIconSet"; "required": false; }; "prefixIconSrc": { "alias": "prefixIconSrc"; "required": false; }; "suffixIcon": { "alias": "suffixIcon"; "required": false; }; "suffixIconSet": { "alias": "suffixIconSet"; "required": false; }; "suffixIconSrc": { "alias": "suffixIconSrc"; "required": false; }; }, {}, never, never, true, never>;
}
