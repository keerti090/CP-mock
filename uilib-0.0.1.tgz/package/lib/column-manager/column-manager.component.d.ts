import { EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import * as i0 from "@angular/core";
export interface ColumnManagerColumn {
    id: string;
    label: string;
    visible: boolean;
    locked?: boolean;
}
export interface ColumnManagerGroup {
    id: string;
    label: string;
    columns: ColumnManagerColumn[];
    collapsed?: boolean;
    locked?: boolean;
}
export declare class ColumnManagerComponent implements OnInit, OnChanges {
    /** List of column groups to manage. */
    groups: ColumnManagerGroup[];
    /** Panel title displayed in the header. */
    title: string;
    /** Whether to show the search input. */
    searchable: boolean;
    /** Emits on every visibility/order change (live updates). */
    groupsChange: EventEmitter<ColumnManagerGroup[]>;
    /** Emits when the user clicks Apply. */
    apply: EventEmitter<ColumnManagerGroup[]>;
    /** Emits when the user clicks Cancel or the close button. */
    cancel: EventEmitter<void>;
    searchQuery: string;
    internalGroups: ColumnManagerGroup[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    get allVisible(): boolean;
    get someVisible(): boolean;
    get visibleCount(): number;
    get totalCount(): number;
    isGroupAllVisible(group: ColumnManagerGroup): boolean;
    isGroupSomeVisible(group: ColumnManagerGroup): boolean;
    getGroupVisibleCount(group: ColumnManagerGroup): number;
    getFilteredColumns(group: ColumnManagerGroup): ColumnManagerColumn[];
    toggleAllColumns(visible: boolean): void;
    toggleGroup(group: ColumnManagerGroup, visible: boolean): void;
    toggleGroupCollapse(group: ColumnManagerGroup): void;
    onColumnVisibilityChange(): void;
    onGroupDrop(event: CdkDragDrop<ColumnManagerGroup[]>): void;
    onColumnDrop(event: CdkDragDrop<ColumnManagerColumn[]>, groupIndex: number): void;
    onApply(): void;
    onCancel(): void;
    private emitChange;
    private deepCopy;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnManagerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColumnManagerComponent, "appcore-column-manager", never, { "groups": { "alias": "groups"; "required": false; }; "title": { "alias": "title"; "required": false; }; "searchable": { "alias": "searchable"; "required": false; }; }, { "groupsChange": "groupsChange"; "apply": "apply"; "cancel": "cancel"; }, never, never, true, never>;
}
