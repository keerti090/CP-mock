import * as i0 from "@angular/core";
export declare class UilibService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<UilibService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UilibService>;
}
