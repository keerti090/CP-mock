import * as i0 from "@angular/core";
type ActionBarSize = 'xs' | 's' | 'm' | 'l' | 'xl';
type ActionBarType = 'icon' | 'text';
export interface ActionBarButtonConfig {
    icon: string;
    iconSet?: 'material' | 'asset';
}
export interface ActionBarTextButtonConfig {
    label: string;
    leftIconName?: string;
}
export declare class ActionbarComponent {
    /** Visual style for the bar – "icon" or "text". */
    type: ActionBarType;
    /** Size preset that controls spacing; mirrors the design spec (XS by default). */
    size: ActionBarSize;
    /** Whether to show the middle set. */
    showSet2: boolean;
    /** Whether to show the right-hand set. */
    showSet3: boolean;
    /** Whether to show the trailing kebab menu. */
    showKebabMenu: boolean;
    /** Icon buttons for the first group (icon mode). */
    set1: ActionBarButtonConfig[];
    /** Icon buttons for the second group (icon mode). */
    set2: ActionBarButtonConfig[];
    /** Icon buttons for the third group (icon mode). */
    set3: ActionBarButtonConfig[];
    /** Text buttons for the first group (text mode). */
    textSet1: ActionBarTextButtonConfig[];
    /** Text buttons for the second group (text mode). */
    textSet2: ActionBarTextButtonConfig[];
    /** Text buttons for the third group (text mode). */
    textSet3: ActionBarTextButtonConfig[];
    /** Map ActionBar size to ButtonComponent size (text variant starts from S). */
    get buttonSize(): 'small' | 'medium' | 'large';
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionbarComponent, "appcore-actionbar", never, { "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "showSet2": { "alias": "showSet2"; "required": false; }; "showSet3": { "alias": "showSet3"; "required": false; }; "showKebabMenu": { "alias": "showKebabMenu"; "required": false; }; "set1": { "alias": "set1"; "required": false; }; "set2": { "alias": "set2"; "required": false; }; "set3": { "alias": "set3"; "required": false; }; "textSet1": { "alias": "textSet1"; "required": false; }; "textSet2": { "alias": "textSet2"; "required": false; }; "textSet3": { "alias": "textSet3"; "required": false; }; }, {}, never, never, true, never>;
}
export {};
