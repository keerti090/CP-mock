import { EventEmitter, ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export interface ComboboxOption {
    value: string;
    label: string;
    disabled?: boolean;
}
export type ComboboxSize = 'sm' | 'md' | 'lg';
export declare class ComboboxComponent {
    private elementRef;
    /** List of selectable options. */
    options: ComboboxOption[];
    /** Currently selected value. */
    value: string;
    /** Placeholder shown when nothing is selected. */
    placeholder: string;
    /** Field label rendered above the control. */
    label: string;
    /** Helper text shown below the control in the default state. */
    helperText: string;
    /** Error message shown when error=true. */
    errorMessage: string;
    /** Visual size of the combobox. */
    size: ComboboxSize;
    /** Disables all interaction. */
    disabled: boolean;
    /** Shows error styling and errorMessage. */
    error: boolean;
    /** Allows typing to filter options. */
    searchable: boolean;
    /** Emits the new value string when selection changes. */
    valueChange: EventEmitter<string>;
    /** Emits the full option object when selection changes. */
    selectionChange: EventEmitter<ComboboxOption | null>;
    isOpen: boolean;
    searchText: string;
    constructor(elementRef: ElementRef);
    get selectedOption(): ComboboxOption | undefined;
    get filteredOptions(): ComboboxOption[];
    get inputValue(): string;
    onDocumentClick(event: Event): void;
    open(): void;
    close(): void;
    onControlClick(): void;
    onChevronClick(event: Event): void;
    onFocus(): void;
    onBlur(): void;
    onInput(event: Event): void;
    selectOption(option: ComboboxOption): void;
    clear(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComboboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ComboboxComponent, "appcore-combobox", never, { "options": { "alias": "options"; "required": false; }; "value": { "alias": "value"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "label": { "alias": "label"; "required": false; }; "helperText": { "alias": "helperText"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "error": { "alias": "error"; "required": false; }; "searchable": { "alias": "searchable"; "required": false; }; }, { "valueChange": "valueChange"; "selectionChange": "selectionChange"; }, never, never, true, never>;
}
