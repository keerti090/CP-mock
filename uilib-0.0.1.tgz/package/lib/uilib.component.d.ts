import * as i0 from "@angular/core";
export declare class UilibComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UilibComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UilibComponent, "lib-uilib", never, {}, {}, never, never, true, never>;
}
