import { DescriptionItemSize, DescriptionItemType } from './description-item.component';
import * as i0 from "@angular/core";
export type DescriptionListLayout = 'horizontal' | 'vertical';
export interface DescriptionListItem {
    label: string;
    value: string;
    size?: DescriptionItemSize;
    type?: DescriptionItemType;
    showLabelIcon?: boolean;
    labelIcon?: string;
    showContentIcon1?: boolean;
    contentIcon1?: string;
    showContentIcon2?: boolean;
    contentIcon2?: string;
    showBadge?: boolean;
    badgeLabel?: string;
    showPrefixAvatar?: boolean;
    prefixAvatarLabel?: string;
    showContentAvatar?: boolean;
    contentAvatarLabel?: string;
    showSuffixAvatar?: boolean;
    suffixAvatarLabel?: string;
}
export declare class DescriptionListComponent {
    items: DescriptionListItem[];
    /** How items are arranged: 'vertical' stacks them, 'horizontal' places them in a row */
    layout: DescriptionListLayout;
    /** Default item layout type — can be overridden per-item via item.type */
    itemType: DescriptionItemType;
    /** Default size for all items — can be overridden per-item via item.size */
    size: DescriptionItemSize;
    title: string;
    divider: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DescriptionListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DescriptionListComponent, "appcore-description-list", never, { "items": { "alias": "items"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "size": { "alias": "size"; "required": false; }; "title": { "alias": "title"; "required": false; }; "divider": { "alias": "divider"; "required": false; }; }, {}, never, never, true, never>;
}
