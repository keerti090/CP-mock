import * as i0 from "@angular/core";
export type DescriptionItemSize = 'S' | 'M' | 'L';
export type DescriptionItemType = 'Horizontal' | 'Vertical' | '2Column' | 'Display';
export declare class DescriptionItemComponent {
    label: string;
    value: string;
    size: DescriptionItemSize;
    type: DescriptionItemType;
    showLabelIcon: boolean;
    labelIcon: string;
    showContentIcon1: boolean;
    contentIcon1: string;
    showContentIcon2: boolean;
    contentIcon2: string;
    showBadge: boolean;
    badgeLabel: string;
    showPrefixAvatar: boolean;
    prefixAvatarLabel: string;
    showContentAvatar: boolean;
    contentAvatarLabel: string;
    showSuffixAvatar: boolean;
    suffixAvatarLabel: string;
    get iconSize(): 'sm' | 'md';
    static ɵfac: i0.ɵɵFactoryDeclaration<DescriptionItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DescriptionItemComponent, "appcore-description-item", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "size": { "alias": "size"; "required": false; }; "type": { "alias": "type"; "required": false; }; "showLabelIcon": { "alias": "showLabelIcon"; "required": false; }; "labelIcon": { "alias": "labelIcon"; "required": false; }; "showContentIcon1": { "alias": "showContentIcon1"; "required": false; }; "contentIcon1": { "alias": "contentIcon1"; "required": false; }; "showContentIcon2": { "alias": "showContentIcon2"; "required": false; }; "contentIcon2": { "alias": "contentIcon2"; "required": false; }; "showBadge": { "alias": "showBadge"; "required": false; }; "badgeLabel": { "alias": "badgeLabel"; "required": false; }; "showPrefixAvatar": { "alias": "showPrefixAvatar"; "required": false; }; "prefixAvatarLabel": { "alias": "prefixAvatarLabel"; "required": false; }; "showContentAvatar": { "alias": "showContentAvatar"; "required": false; }; "contentAvatarLabel": { "alias": "contentAvatarLabel"; "required": false; }; "showSuffixAvatar": { "alias": "showSuffixAvatar"; "required": false; }; "suffixAvatarLabel": { "alias": "suffixAvatarLabel"; "required": false; }; }, {}, never, never, true, never>;
}
