import { EventEmitter } from '@angular/core';
import { RadioButtonSize } from './radio-button.component';
import * as i0 from "@angular/core";
export interface RadioButtonItem {
    id: string;
    label: string;
    value: string;
    disabled?: boolean;
}
export type RadioGroupOrientation = 'vertical' | 'horizontal' | 'horizontal-next-row';
export declare class RadioButtonGroupComponent {
    /** Array of radio button options. */
    items: RadioButtonItem[];
    /** Currently selected value. */
    value: string;
    /** Group label displayed above the options. */
    groupLabel: string;
    /** Optional helper text below the group label. */
    groupDescription: string;
    /** Layout orientation of the radio buttons. */
    orientation: RadioGroupOrientation;
    /** Size applied to all radio buttons in the group. */
    size: RadioButtonSize;
    /** Disables all radio buttons in the group. */
    disabled: boolean;
    /** Emits the selected value when the user picks an option. */
    valueChange: EventEmitter<string>;
    readonly _labelId: string;
    readonly _groupName: string;
    onItemChange(selectedValue: string): void;
    trackById(_index: number, item: RadioButtonItem): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioButtonGroupComponent, "appcore-radio-button-group", never, { "items": { "alias": "items"; "required": false; }; "value": { "alias": "value"; "required": false; }; "groupLabel": { "alias": "groupLabel"; "required": false; }; "groupDescription": { "alias": "groupDescription"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
