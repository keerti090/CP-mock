import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type RadioButtonSize = 'sm' | 'md' | 'lg';
export declare class RadioButtonComponent {
    /** Visible text label next to the radio button. */
    label: string;
    /** aria-label applied when no visible label is provided. */
    ariaLabel: string;
    /** Whether this radio button is selected. */
    checked: boolean;
    /** Groups radio buttons together — only one per name can be selected. */
    name: string;
    /** Value emitted when this option is selected. */
    value: string;
    /** Disables interaction. */
    disabled: boolean;
    /** Visual size of the radio button. */
    size: RadioButtonSize;
    /** HTML id forwarded to the native input. */
    inputId: string;
    /** Emits this radio button's value when selected. */
    valueChange: EventEmitter<string>;
    onNativeChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioButtonComponent, "appcore-radio-button", never, { "label": { "alias": "label"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "name": { "alias": "name"; "required": false; }; "value": { "alias": "value"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "size": { "alias": "size"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
