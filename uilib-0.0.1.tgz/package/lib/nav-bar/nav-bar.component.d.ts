import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type NavBarPlatform = 'CCP' | 'WLMP' | 'CBOT';
export declare class NavBarComponent {
    platform: NavBarPlatform;
    navItems: string[];
    activeItem: string;
    cartCount: number;
    userName: string;
    marketplaceName: string;
    loggedInUser: string;
    navItemClick: EventEmitter<string>;
    onNavItemClick(item: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavBarComponent, "app-nav-bar", never, { "platform": { "alias": "platform"; "required": false; }; "navItems": { "alias": "navItems"; "required": false; }; "activeItem": { "alias": "activeItem"; "required": false; }; "cartCount": { "alias": "cartCount"; "required": false; }; "userName": { "alias": "userName"; "required": false; }; "marketplaceName": { "alias": "marketplaceName"; "required": false; }; "loggedInUser": { "alias": "loggedInUser"; "required": false; }; }, { "navItemClick": "navItemClick"; }, never, never, true, never>;
}
