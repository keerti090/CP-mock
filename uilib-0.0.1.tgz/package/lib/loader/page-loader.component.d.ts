import * as i0 from "@angular/core";
export declare class PageLoaderComponent {
    visible: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageLoaderComponent, "appcore-page-loader", never, { "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
