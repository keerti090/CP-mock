import * as i0 from "@angular/core";
export type InlineLoaderState = 'Active' | 'Success' | 'Error';
export declare class InlineLoaderWithTextComponent {
    state: InlineLoaderState;
    label: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<InlineLoaderWithTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InlineLoaderWithTextComponent, "appcore-inline-loader-with-text", never, { "state": { "alias": "state"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
