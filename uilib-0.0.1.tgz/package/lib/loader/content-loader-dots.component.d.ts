import * as i0 from "@angular/core";
export declare class ContentLoaderDotsComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentLoaderDotsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentLoaderDotsComponent, "appcore-content-loader-dots", never, {}, {}, never, never, true, never>;
}
