import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type OverlayType = 'Light' | 'Dark';
export declare class OverlayComponent {
    visible: boolean;
    type: OverlayType;
    overlayClick: EventEmitter<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OverlayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OverlayComponent, "appcore-overlay", never, { "visible": { "alias": "visible"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, { "overlayClick": "overlayClick"; }, never, never, true, never>;
}
