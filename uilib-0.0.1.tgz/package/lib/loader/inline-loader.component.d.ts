import * as i0 from "@angular/core";
export declare class InlineLoaderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<InlineLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InlineLoaderComponent, "appcore-inline-loader", never, {}, {}, never, never, true, never>;
}
