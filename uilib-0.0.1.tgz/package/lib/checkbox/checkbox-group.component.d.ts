import { EventEmitter } from '@angular/core';
import { CheckboxSize } from './checkbox.component';
import * as i0 from "@angular/core";
export interface CheckboxItem {
    id: string;
    label: string;
    checked: boolean;
    description?: string;
    disabled?: boolean;
}
export declare class CheckboxGroupComponent {
    /** Array of checkbox items to render. */
    items: CheckboxItem[];
    /** Group label displayed above the checkboxes. */
    groupLabel: string;
    /** Optional helper text below the group label. */
    groupDescription: string;
    /** Whether to show a "Select All" checkbox above the list. */
    showSelectAll: boolean;
    /** Label text for the select-all row. */
    selectAllLabel: string;
    /** Layout direction of the checkbox items. */
    orientation: 'vertical' | 'horizontal';
    /** Size applied to all checkboxes in the group. */
    size: CheckboxSize;
    /** Disables all checkboxes in the group. */
    disabled: boolean;
    /** Error message displayed below the group; also applies error styling to each checkbox. */
    error: string;
    /** Emits the full updated items array on any selection change. */
    selectionChange: EventEmitter<CheckboxItem[]>;
    readonly _labelId: string;
    get allChecked(): boolean;
    get someChecked(): boolean;
    onSelectAll(checked: boolean): void;
    onItemChange(item: CheckboxItem, checked: boolean): void;
    trackById(_index: number, item: CheckboxItem): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxGroupComponent, "appcore-checkbox-group", never, { "items": { "alias": "items"; "required": false; }; "groupLabel": { "alias": "groupLabel"; "required": false; }; "groupDescription": { "alias": "groupDescription"; "required": false; }; "showSelectAll": { "alias": "showSelectAll"; "required": false; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "error": { "alias": "error"; "required": false; }; }, { "selectionChange": "selectionChange"; }, never, never, true, never>;
}
