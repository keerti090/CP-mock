import { EventEmitter, ElementRef, AfterViewChecked } from '@angular/core';
import * as i0 from "@angular/core";
export type CheckboxSize = 'sm' | 'md' | 'lg';
export declare class CheckboxComponent implements AfterViewChecked {
    /** Visible text label next to the checkbox. */
    label: string;
    /** Optional helper text rendered below the label. */
    description: string;
    /** aria-label applied when no visible label is provided. */
    ariaLabel: string;
    /** Whether the checkbox is checked. */
    checked: boolean;
    /** Shows a dash/minus indicator — used for "select all" partial states. */
    indeterminate: boolean;
    /** Disables interaction. */
    disabled: boolean;
    /** Applies error styling (red border). */
    error: boolean;
    /** Visual size of the checkbox. */
    size: CheckboxSize;
    /** HTML id forwarded to the native input. */
    inputId: string;
    /** Emits the new checked value when the user toggles the checkbox. */
    checkedChange: EventEmitter<boolean>;
    checkboxEl?: ElementRef<HTMLInputElement>;
    ngAfterViewChecked(): void;
    onNativeChange(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "appcore-checkbox", never, { "label": { "alias": "label"; "required": false; }; "description": { "alias": "description"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "error": { "alias": "error"; "required": false; }; "size": { "alias": "size"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; }, { "checkedChange": "checkedChange"; }, never, never, true, never>;
}
