import { EventEmitter, OnChanges } from '@angular/core';
import { SegmentSize } from './segmented-control-item.component';
import * as i0 from "@angular/core";
export interface SegmentItem {
    label: string;
    icon?: string;
    iconSet?: 'material' | 'asset';
    iconSrc?: string;
    disabled?: boolean;
}
export declare class SegmentedControlComponent implements OnChanges {
    items: SegmentItem[];
    size: SegmentSize;
    selectedIndex: number;
    disabled: boolean;
    selectedIndexChange: EventEmitter<number>;
    private _selectedIndex;
    ngOnChanges(): void;
    getState(index: number): 'default' | 'selected' | 'disabled' | 'disabled-selected';
    onItemClick(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SegmentedControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SegmentedControlComponent, "app-segmented-control", never, { "items": { "alias": "items"; "required": false; }; "size": { "alias": "size"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "selectedIndexChange": "selectedIndexChange"; }, never, never, true, never>;
}
