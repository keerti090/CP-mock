import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type SegmentSize = 'S' | 'M' | 'L';
export type SegmentState = 'default' | 'hover' | 'selected' | 'disabled' | 'disabled-selected';
export declare class SegmentedControlItemComponent {
    label: string;
    size: SegmentSize;
    state: SegmentState;
    showIcon: boolean;
    iconName: string;
    iconSet: 'material' | 'asset';
    iconSrc?: string;
    itemClick: EventEmitter<void>;
    onClick(): void;
    onMouseEnter(): void;
    onMouseLeave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SegmentedControlItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SegmentedControlItemComponent, "app-segmented-control-item", never, { "label": { "alias": "label"; "required": false; }; "size": { "alias": "size"; "required": false; }; "state": { "alias": "state"; "required": false; }; "showIcon": { "alias": "showIcon"; "required": false; }; "iconName": { "alias": "iconName"; "required": false; }; "iconSet": { "alias": "iconSet"; "required": false; }; "iconSrc": { "alias": "iconSrc"; "required": false; }; }, { "itemClick": "itemClick"; }, never, never, true, never>;
}
