import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type TreeViewItemState = 'default' | 'hover' | 'pressed' | 'selected' | 'disabled';
export type TreeViewType = 'global' | 'local';
export type TreeViewLevel = 1 | 2 | 3 | 4;
export declare class TreeViewItemComponent {
    label: string;
    level: TreeViewLevel;
    type: TreeViewType;
    state: TreeViewItemState;
    expanded: boolean;
    hasChildren: boolean;
    showPrefixIcon: boolean;
    prefixIcon: string;
    itemClick: EventEmitter<void>;
    expandToggle: EventEmitter<void>;
    private _hovered;
    private _pressed;
    get itemClasses(): string;
    get effectiveState(): TreeViewItemState;
    onMouseEnter(): void;
    onMouseLeave(): void;
    onMouseDown(): void;
    onMouseUp(): void;
    onItemClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeViewItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TreeViewItemComponent, "app-tree-view-item", never, { "label": { "alias": "label"; "required": false; }; "level": { "alias": "level"; "required": false; }; "type": { "alias": "type"; "required": false; }; "state": { "alias": "state"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "hasChildren": { "alias": "hasChildren"; "required": false; }; "showPrefixIcon": { "alias": "showPrefixIcon"; "required": false; }; "prefixIcon": { "alias": "prefixIcon"; "required": false; }; }, { "itemClick": "itemClick"; "expandToggle": "expandToggle"; }, never, never, true, never>;
}
