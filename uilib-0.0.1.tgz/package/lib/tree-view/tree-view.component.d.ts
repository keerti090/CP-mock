import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource } from '@angular/material/tree';
import { TreeViewType } from './tree-view-item.component';
import * as i0 from "@angular/core";
export interface TreeViewNode {
    label: string;
    icon?: string;
    disabled?: boolean;
    children?: TreeViewNode[];
    /** Any extra data the consumer wants to carry through. */
    data?: unknown;
}
/** Flat node produced by MatTreeFlattener — internal use only. */
export interface TreeViewFlatNode {
    label: string;
    icon?: string;
    disabled?: boolean;
    data?: unknown;
    level: number;
    expandable: boolean;
    /** Reference back to the source node for selection tracking. */
    _source: TreeViewNode;
}
export declare class TreeViewComponent implements OnChanges {
    /**
     * Hierarchical node data. Provide your own `TreeViewNode[]`
     * — the component handles flattening and expansion internally.
     */
    nodes: TreeViewNode[];
    /** Visual theme: 'global' (blue-tinted bg) or 'local' (white bg). */
    type: TreeViewType;
    /** Show the leading icon on every row. */
    showIcons: boolean;
    /** ID of the currently selected node (matched on object reference via `_source`). */
    selectedNode: TreeViewNode | null;
    /** Emits when the user clicks a non-disabled node. */
    nodeSelect: EventEmitter<TreeViewNode>;
    /** Emits when a parent node is expanded or collapsed. */
    nodeToggle: EventEmitter<{
        node: TreeViewNode;
        expanded: boolean;
    }>;
    private transformer;
    treeControl: FlatTreeControl<TreeViewFlatNode, TreeViewFlatNode>;
    private flattener;
    dataSource: MatTreeFlatDataSource<TreeViewNode, TreeViewFlatNode, TreeViewFlatNode>;
    ngOnChanges(changes: SimpleChanges): void;
    hasChild: (_: number, flat: TreeViewFlatNode) => boolean;
    clampLevel(level: number): 1 | 2 | 3 | 4;
    stateOf(flat: TreeViewFlatNode): 'default' | 'selected' | 'disabled';
    onSelect(flat: TreeViewFlatNode): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TreeViewComponent, "app-tree-view", never, { "nodes": { "alias": "nodes"; "required": false; }; "type": { "alias": "type"; "required": false; }; "showIcons": { "alias": "showIcons"; "required": false; }; "selectedNode": { "alias": "selectedNode"; "required": false; }; }, { "nodeSelect": "nodeSelect"; "nodeToggle": "nodeToggle"; }, never, never, true, never>;
}
