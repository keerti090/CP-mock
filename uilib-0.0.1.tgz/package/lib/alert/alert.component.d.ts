import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type AlertType = 'Information' | 'Success' | 'Warning' | 'Error';
export declare class AlertComponent {
    type: AlertType;
    title: string;
    description: string;
    showIcon: boolean;
    dismissible: boolean;
    dismiss: EventEmitter<void>;
    get iconName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "appcore-alert", never, { "type": { "alias": "type"; "required": false; }; "title": { "alias": "title"; "required": false; }; "description": { "alias": "description"; "required": false; }; "showIcon": { "alias": "showIcon"; "required": false; }; "dismissible": { "alias": "dismissible"; "required": false; }; }, { "dismiss": "dismiss"; }, never, never, true, never>;
}
