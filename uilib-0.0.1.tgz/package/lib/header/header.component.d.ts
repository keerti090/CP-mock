import * as i0 from "@angular/core";
export type HeaderType = 'H1' | 'H2' | 'H3' | 'H4' | 'H5';
export declare class HeaderComponent {
    type: HeaderType;
    title: string;
    subtitle: string;
    showBreadcrumb: boolean;
    showImage: boolean;
    showBackIcon: boolean;
    showLogo: boolean;
    showText: boolean;
    showBadge1: boolean;
    showBadge2: boolean;
    showBadge3: boolean;
    showBadge4: boolean;
    showSearch: boolean;
    showButtonSet: boolean;
    showComboButton: boolean;
    showActionBar: boolean;
    showIconButton1: boolean;
    showIconButton2: boolean;
    showIconButton3: boolean;
    showAvatar: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderComponent, "appcore-header", never, { "type": { "alias": "type"; "required": false; }; "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "showBreadcrumb": { "alias": "showBreadcrumb"; "required": false; }; "showImage": { "alias": "showImage"; "required": false; }; "showBackIcon": { "alias": "showBackIcon"; "required": false; }; "showLogo": { "alias": "showLogo"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "showBadge1": { "alias": "showBadge1"; "required": false; }; "showBadge2": { "alias": "showBadge2"; "required": false; }; "showBadge3": { "alias": "showBadge3"; "required": false; }; "showBadge4": { "alias": "showBadge4"; "required": false; }; "showSearch": { "alias": "showSearch"; "required": false; }; "showButtonSet": { "alias": "showButtonSet"; "required": false; }; "showComboButton": { "alias": "showComboButton"; "required": false; }; "showActionBar": { "alias": "showActionBar"; "required": false; }; "showIconButton1": { "alias": "showIconButton1"; "required": false; }; "showIconButton2": { "alias": "showIconButton2"; "required": false; }; "showIconButton3": { "alias": "showIconButton3"; "required": false; }; "showAvatar": { "alias": "showAvatar"; "required": false; }; }, {}, never, ["[logo]", "[image]", "[breadcrumb]", "[badge1]", "[badge2]", "[badge3]", "[badge4]", "[search]", "[buttonSet]", "[comboButton]", "[actionBar]", "[iconButton1]", "[iconButton2]", "[iconButton3]", "[avatar]"], true, never>;
}
