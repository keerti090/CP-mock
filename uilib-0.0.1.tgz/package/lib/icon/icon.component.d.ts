import * as i0 from "@angular/core";
export declare class IconComponent {
    /** Icon name: for Material use names like "add", "search", "arrow_forward"; for asset use file name without .svg (e.g. "icon-search"). */
    icon: string;
    /**
     * Custom icon URL. When set, this is used as the img src and icon/iconSet are ignored.
     * Use for fully custom icons passed from outside (e.g. CDN, data URL, or app asset path).
     */
    src?: string;
    /**
     * 'material' = Material Symbols Rounded (default); 'asset' = SVG from assets/icons/
     * When using iconSet="material", the host app must load the font, e.g. in index.html:
     * <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
     */
    iconSet: 'material' | 'asset';
    size: 'sm' | 'md' | 'lg';
    alt?: string;
    color?: 'primary' | 'neutral' | 'default';
    background?: 'primary' | 'neutral' | 'default';
    /** Material Symbol name: strip "icon-" prefix so "icon-add" and "add" both work */
    get materialIconName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconComponent, "app-icon", never, { "icon": { "alias": "icon"; "required": false; }; "src": { "alias": "src"; "required": false; }; "iconSet": { "alias": "iconSet"; "required": false; }; "size": { "alias": "size"; "required": false; }; "alt": { "alias": "alt"; "required": false; }; "color": { "alias": "color"; "required": false; }; "background": { "alias": "background"; "required": false; }; }, {}, never, never, true, never>;
}
