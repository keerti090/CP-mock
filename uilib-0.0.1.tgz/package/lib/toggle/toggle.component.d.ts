import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type ToggleSize = 'sm' | 'md' | 'lg';
export declare class ToggleComponent {
    /** Visible text label next to the toggle. */
    label: string;
    /** Whether the toggle is on. */
    checked: boolean;
    /** Disables interaction. */
    disabled: boolean;
    /** Visual size of the toggle. */
    size: ToggleSize;
    /** Emits the new checked value when the user toggles. */
    checkedChange: EventEmitter<boolean>;
    onNativeChange(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToggleComponent, "appcore-toggle", never, { "label": { "alias": "label"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, { "checkedChange": "checkedChange"; }, never, never, true, never>;
}
