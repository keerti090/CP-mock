import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type DialogueBoxState = 'Default' | 'Success' | 'Warning' | 'Error';
export type DialogueBoxSize = 'S' | 'M' | 'L' | 'XL';
export declare class DialogueBoxComponent {
    visible: boolean;
    state: DialogueBoxState;
    size: DialogueBoxSize;
    label: string;
    description: string;
    cancelLabel: string;
    confirmLabel: string;
    closeOnOverlayClick: boolean;
    close: EventEmitter<void>;
    cancel: EventEmitter<void>;
    confirm: EventEmitter<void>;
    get stateIcon(): string;
    onOverlayClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogueBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogueBoxComponent, "appcore-dialogue-box", never, { "visible": { "alias": "visible"; "required": false; }; "state": { "alias": "state"; "required": false; }; "size": { "alias": "size"; "required": false; }; "label": { "alias": "label"; "required": false; }; "description": { "alias": "description"; "required": false; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; }; "closeOnOverlayClick": { "alias": "closeOnOverlayClick"; "required": false; }; }, { "close": "close"; "cancel": "cancel"; "confirm": "confirm"; }, never, ["*"], true, never>;
}
