import * as i0 from "@angular/core";
export type StepState = 'not-done' | 'current' | 'done' | 'partially-done' | 'error';
export interface StepItem {
    label: string;
    state: StepState;
    icon?: string;
}
export declare class ProgressStepperComponent {
    steps: StepItem[];
    orientation: 'horizontal' | 'vertical';
    type: 'default' | 'icon';
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressStepperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressStepperComponent, "app-progress-stepper", never, { "steps": { "alias": "steps"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
